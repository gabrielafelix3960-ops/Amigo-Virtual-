const express = require('express');
const router = express.Router();
const { createCheckoutSession, paymentWebhook } = require('../controllers/payment_controller');
const { protect } = require('../middleware/auth_middleware');

router.post('/create-session', protect, createCheckoutSession);
router.post('/webhook', paymentWebhook);

module.exports = router;
