const express = require('express');
const router = express.Router();
const { getAllUsers } = require('../controllers/admin_controller');
const { protect, admin } = require('../middleware/auth_middleware');

router.get('/users', protect, admin, getAllUsers);

module.exports = router;
