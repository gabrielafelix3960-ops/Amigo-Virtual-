export let state = {
    currentUser: null,
    authToken: null,
    friendProfile: {
        gender: null,
        personalities: [],
        avatar: 'https://r2.flowith.net/files/png/6Y5R2-avatar_ia_amigo_virtual_index_1@1024x1024.png'
    },
    chatHistory: [],
};

export function updateState(newState) {
    state = { ...state, ...newState };

}
