const mongoose = require('mongoose');

const virtualFriendProfileSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
        unique: true,
    },
    gender: {
        type: String,
        enum: ['male', 'female', 'non-binary'],
        default: 'female',
    },
    personalityTraits: [{
        type: String,
        enum: ['cheerful', 'fun', 'serious', 'professional', 'loyal', 'caring', 'attentive', 'extroverted'],
    }],
}, {
    timestamps: true,
});

const VirtualFriendProfile = mongoose.model('VirtualFriendProfile', virtualFriendProfileSchema);
module.exports = VirtualFriendProfile;
