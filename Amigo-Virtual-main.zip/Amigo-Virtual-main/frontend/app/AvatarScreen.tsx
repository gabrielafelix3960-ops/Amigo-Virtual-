import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface AvatarScreenProps {
  friend: any;
  onBack: () => void;
  onSave: (avatarData: any) => void;
  isPreview?: boolean;
}

export const AvatarScreen: React.FC<AvatarScreenProps> = ({
  friend,
  onBack,
  onSave,
  isPreview = false
}) => {
  // Avatar customization options
  const [skinTone, setSkinTone] = useState('light');
  const [hairStyle, setHairStyle] = useState('short');
  const [hairColor, setHairColor] = useState('brown');
  const [eyeColor, setEyeColor] = useState('brown');
  const [clothing, setClothing] = useState('casual');
  const [accessories, setAccessories] = useState('none');

  const skinTones = [
    { key: 'light', name: 'Claro', emoji: '👱' },
    { key: 'medium', name: 'Médio', emoji: '👨' },
    { key: 'tan', name: 'Moreno', emoji: '👨🏽' },
    { key: 'dark', name: 'Escuro', emoji: '👨🏿' },
  ];

  const hairStyles = friend?.gender === 'masculino' ? [
    { key: 'short', name: 'Curto', icon: '✂️' },
    { key: 'medium', name: 'Médio', icon: '💇‍♂️' },
    { key: 'long', name: 'Longo', icon: '🦱' },
    { key: 'bald', name: 'Careca', icon: '🥚' },
  ] : [
    { key: 'short', name: 'Curto', icon: '✂️' },
    { key: 'medium', name: 'Médio', icon: '💇‍♀️' },
    { key: 'long', name: 'Longo', icon: '👸' },
    { key: 'curly', name: 'Cacheado', icon: '🦱' },
  ];

  const hairColors = [
    { key: 'black', name: 'Preto', color: '#2C1810' },
    { key: 'brown', name: 'Castanho', color: '#8B4513' },
    { key: 'blonde', name: 'Loiro', color: '#DAA520' },
    { key: 'red', name: 'Ruivo', color: '#CD853F' },
    { key: 'gray', name: 'Grisalho', color: '#808080' },
  ];

  const eyeColors = [
    { key: 'brown', name: 'Castanho', color: '#8B4513' },
    { key: 'blue', name: 'Azul', color: '#4682B4' },
    { key: 'green', name: 'Verde', color: '#228B22' },
    { key: 'hazel', name: 'Avelã', color: '#CD853F' },
  ];

  const clothingOptions = [
    { key: 'casual', name: 'Casual', icon: '👕' },
    { key: 'formal', name: 'Formal', icon: '👔' },
    { key: 'sporty', name: 'Esportivo', icon: '🏃' },
    { key: 'elegant', name: 'Elegante', icon: friend?.gender === 'masculino' ? '🤵' : '👗' },
  ];

  const accessoryOptions = [
    { key: 'none', name: 'Nenhum', icon: '🚫' },
    { key: 'glasses', name: 'Óculos', icon: '👓' },
    { key: 'sunglasses', name: 'Óculos Escuros', icon: '🕶️' },
    { key: 'hat', name: 'Chapéu', icon: '🎩' },
  ];

  const generateAvatarPreview = () => {
    // Simplified avatar representation
    let avatarEmoji = friend?.gender === 'masculino' ? '👨' : '👩';
    
    // Modify based on skin tone
    const skinModifiers = {
      light: '',
      medium: '🏽',
      tan: '🏽',
      dark: '🏿'
    };
    
    avatarEmoji = friend?.gender === 'masculino' ? 
      `👨${skinModifiers[skinTone as keyof typeof skinModifiers]}` : 
      `👩${skinModifiers[skinTone as keyof typeof skinModifiers]}`;

    return avatarEmoji;
  };

  const handleSave = () => {
    if (isPreview) {
      Alert.alert(
        'Avatar Premium',
        'Para personalizar avatares, você precisa da versão Premium do Amigo Virtual!',
        [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Ver Planos', onPress: () => console.log('Navigate to pricing') }
        ]
      );
      return;
    }

    const avatarData = {
      skinTone,
      hairStyle,
      hairColor,
      eyeColor,
      clothing,
      accessories,
      preview: generateAvatarPreview()
    };

    onSave(avatarData);
  };

  const renderSection = (title: string, options: any[], selected: string, onSelect: (key: string) => void) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.optionsContainer}>
        {options.map((option) => (
          <TouchableOpacity
            key={option.key}
            style={[
              styles.optionButton,
              selected === option.key && styles.optionButtonSelected,
              isPreview && styles.optionButtonDisabled
            ]}
            onPress={() => !isPreview && onSelect(option.key)}
            disabled={isPreview}
          >
            {option.emoji && <Text style={styles.optionEmoji}>{option.emoji}</Text>}
            {option.icon && <Text style={styles.optionIcon}>{option.icon}</Text>}
            {option.color && (
              <View style={[styles.colorCircle, { backgroundColor: option.color }]} />
            )}
            <Text style={[
              styles.optionText,
              selected === option.key && styles.optionTextSelected,
              isPreview && styles.optionTextDisabled
            ]}>
              {option.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={30} color="#E91E63" />
        </TouchableOpacity>
        <Text style={styles.title}>
          {isPreview ? 'Preview do Avatar' : `Avatar de ${friend?.name}`}
        </Text>
      </View>

      <ScrollView style={styles.content}>
        {/* Avatar Preview */}
        <View style={styles.previewContainer}>
          <Text style={styles.previewTitle}>Preview</Text>
          <View style={styles.avatarPreview}>
            <Text style={styles.avatarEmoji}>{generateAvatarPreview()}</Text>
            <Text style={styles.avatarName}>{friend?.name}</Text>
          </View>
          
          {isPreview && (
            <View style={styles.premiumBadge}>
              <Ionicons name="lock-closed" size={16} color="#FFD700" />
              <Text style={styles.premiumText}>Premium Feature</Text>
            </View>
          )}
        </View>

        {/* Customization Options */}
        {renderSection('Tom de Pele', skinTones, skinTone, setSkinTone)}
        {renderSection('Estilo do Cabelo', hairStyles, hairStyle, setHairStyle)}
        {renderSection('Cor do Cabelo', hairColors, hairColor, setHairColor)}
        {renderSection('Cor dos Olhos', eyeColors, eyeColor, setEyeColor)}
        {renderSection('Roupa', clothingOptions, clothing, setClothing)}
        {renderSection('Acessórios', accessoryOptions, accessories, setAccessories)}

        {/* Save Button */}
        <TouchableOpacity
          style={[
            styles.saveButton,
            isPreview && styles.premiumButton
          ]}
          onPress={handleSave}
        >
          <Text style={styles.saveButtonText}>
            {isPreview ? '🔓 Desbloquear com Premium' : 'Salvar Avatar'}
          </Text>
        </TouchableOpacity>

        {isPreview && (
          <View style={styles.premiumInfo}>
            <Text style={styles.premiumInfoTitle}>🎨 Com o Premium você pode:</Text>
            <Text style={styles.premiumInfoText}>
              • Personalizar avatares únicos{'\n'}
              • Criar múltiplos amigos virtuais{'\n'}
              • Acessórios exclusivos{'\n'}
              • Roupas temáticas{'\n'}
              • Atualizações mensais de customização
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginLeft: 15,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  previewContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  previewTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  avatarPreview: {
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarEmoji: {
    fontSize: 80,
    marginBottom: 8,
  },
  avatarName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E91E63',
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFD700',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  premiumText: {
    color: '#333',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  optionButton: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    minWidth: 80,
    borderWidth: 2,
    borderColor: '#e1e5e9',
  },
  optionButtonSelected: {
    borderColor: '#E91E63',
    backgroundColor: '#fce4ec',
  },
  optionButtonDisabled: {
    opacity: 0.5,
  },
  optionEmoji: {
    fontSize: 24,
    marginBottom: 4,
  },
  optionIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  colorCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  optionText: {
    fontSize: 12,
    color: '#333',
    textAlign: 'center',
    fontWeight: '600',
  },
  optionTextSelected: {
    color: '#E91E63',
  },
  optionTextDisabled: {
    color: '#999',
  },
  saveButton: {
    backgroundColor: '#E91E63',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  premiumButton: {
    backgroundColor: '#FFD700',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  premiumInfo: {
    backgroundColor: '#FFF3E0',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  premiumInfoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F57C00',
    marginBottom: 8,
  },
  premiumInfoText: {
    fontSize: 14,
    color: '#795548',
    lineHeight: 20,
  },
});