const express = require('express');
const router = express.Router();
const {
    getAppointments,
    createAppointment,
    updateAppointment,
    deleteAppointment
} = require('../controllers/appointment_controller');
const { protect } = require('../middleware/auth_middleware');

router.route('/').get(protect, getAppointments).post(protect, createAppointment);
router.route('/:id').put(protect, updateAppointment).delete(protect, deleteAppointment);

module.exports = router;
