// Translation system for Amigo Virtual

export interface Translation {
  // Authentication
  email: string;
  password: string;
  confirmPassword: string;
  login: string;
  register: string;
  createAccount: string;
  
  // Main App
  appTitle: string;
  subtitle: string;
  virtualFriend: string;
  
  // Home Screen
  welcome: string;
  plan: string;
  trialPlan: string;
  premiumPlan: string;
  expiredPlan: string;
  noFriends: string;
  createFirstFriend: string;
  
  // Create Friend
  createVirtualFriend: string;
  friendName: string;
  friendNamePlaceholder: string;
  gender: string;
  male: string;
  female: string;
  personality: string;
  personalityPlaceholder: string;
  
  // Chat
  online: string;
  withVoice: string;
  typePlaceholder: string;
  
  // Pricing
  monthly: string;
  annual: string;
  freeTrial: string;
  conversationsPerDay: string;
  unlimitedConversations: string;
  
  // Settings
  language: string;
  currency: string;
  settings: string;
  
  // Errors & Messages
  error: string;
  success: string;
  loading: string;
  connectionError: string;
  passwordsDontMatch: string;
  passwordTooShort: string;
  trialExpired: string;
  dailyLimitReached: string;
}

export const translations: Record<string, Translation> = {
  pt: {
    // Authentication
    email: "Email",
    password: "Senha",
    confirmPassword: "Confirmar Senha",
    login: "Entrar",
    register: "Criar conta",
    createAccount: "Criar Conta",
    
    // Main App
    appTitle: "Amigo Virtual",
    subtitle: "Sua companhia inteligente 24h",
    virtualFriend: "Amigo Virtual",
    
    // Home Screen
    welcome: "Olá",
    plan: "Plano",
    trialPlan: "Teste Gratuito (10 conversas/dia - 7 dias)",
    premiumPlan: "Premium (Conversas Ilimitadas)",
    expiredPlan: "Teste Expirado - Assinar Premium",
    noFriends: "Nenhum amigo virtual ainda",
    createFirstFriend: "Crie seu primeiro amigo virtual!",
    
    // Create Friend
    createVirtualFriend: "Criar Amigo Virtual",
    friendName: "Nome do seu amigo:",
    friendNamePlaceholder: "Ex: Ana, Carlos, Maria...",
    gender: "Gênero:",
    male: "Masculino",
    female: "Feminino",
    personality: "Personalidade:",
    personalityPlaceholder: "Ex: carinhoso e encorajador, divertido e espirituoso...",
    
    // Chat
    online: "Online",
    withVoice: "Com voz ativa",
    typePlaceholder: "Digite sua mensagem...",
    
    // Pricing
    monthly: "Mensal",
    annual: "Anual",
    freeTrial: "Teste Gratuito",
    conversationsPerDay: "conversas/dia",
    unlimitedConversations: "Conversas Ilimitadas",
    
    // Settings
    language: "Idioma",
    currency: "Moeda",
    settings: "Configurações",
    
    // Errors & Messages
    error: "Erro",
    success: "Sucesso",
    loading: "Carregando...",
    connectionError: "Erro de conexão",
    passwordsDontMatch: "Senhas não coincidem",
    passwordTooShort: "Senha deve ter pelo menos 6 caracteres",
    trialExpired: "Seu período de teste expirou!",
    dailyLimitReached: "Limite de conversas diárias atingido!",
  },
  
  en: {
    // Authentication
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm Password",
    login: "Login",
    register: "Sign up",
    createAccount: "Create Account",
    
    // Main App
    appTitle: "Virtual Friend",
    subtitle: "Your intelligent companion 24/7",
    virtualFriend: "Virtual Friend",
    
    // Home Screen
    welcome: "Hello",
    plan: "Plan",
    trialPlan: "Free Trial (10 chats/day - 7 days)",
    premiumPlan: "Premium (Unlimited Conversations)",
    expiredPlan: "Trial Expired - Subscribe Premium",
    noFriends: "No virtual friends yet",
    createFirstFriend: "Create your first virtual friend!",
    
    // Create Friend
    createVirtualFriend: "Create Virtual Friend",
    friendName: "Your friend's name:",
    friendNamePlaceholder: "Ex: Anna, Carlos, Maria...",
    gender: "Gender:",
    male: "Male",
    female: "Female",
    personality: "Personality:",
    personalityPlaceholder: "Ex: caring and encouraging, fun and witty...",
    
    // Chat
    online: "Online",
    withVoice: "Voice active",
    typePlaceholder: "Type your message...",
    
    // Pricing
    monthly: "Monthly",
    annual: "Annual",
    freeTrial: "Free Trial",
    conversationsPerDay: "chats/day",
    unlimitedConversations: "Unlimited Conversations",
    
    // Settings
    language: "Language",
    currency: "Currency",
    settings: "Settings",
    
    // Errors & Messages
    error: "Error",
    success: "Success",
    loading: "Loading...",
    connectionError: "Connection error",
    passwordsDontMatch: "Passwords don't match",
    passwordTooShort: "Password must be at least 6 characters",
    trialExpired: "Your trial period has expired!",
    dailyLimitReached: "Daily conversation limit reached!",
  },
  
  es: {
    // Authentication
    email: "Email",
    password: "Contraseña",
    confirmPassword: "Confirmar Contraseña",
    login: "Iniciar sesión",
    register: "Registrarse",
    createAccount: "Crear Cuenta",
    
    // Main App
    appTitle: "Amigo Virtual",
    subtitle: "Tu compañía inteligente 24h",
    virtualFriend: "Amigo Virtual",
    
    // Home Screen
    welcome: "Hola",
    plan: "Plan",
    trialPlan: "Prueba Gratuita (10 conversaciones/día - 7 días)",
    premiumPlan: "Premium (Conversaciones Ilimitadas)",
    expiredPlan: "Prueba Expirada - Suscribir Premium",
    noFriends: "Aún no tienes amigos virtuales",
    createFirstFriend: "¡Crea tu primer amigo virtual!",
    
    // Create Friend
    createVirtualFriend: "Crear Amigo Virtual",
    friendName: "Nombre de tu amigo:",
    friendNamePlaceholder: "Ej: Ana, Carlos, María...",
    gender: "Género:",
    male: "Masculino",
    female: "Femenino",
    personality: "Personalidad:",
    personalityPlaceholder: "Ej: cariñoso y alentador, divertido y ingenioso...",
    
    // Chat
    online: "En línea",
    withVoice: "Con voz activa",
    typePlaceholder: "Escribe tu mensaje...",
    
    // Pricing
    monthly: "Mensual",
    annual: "Anual",
    freeTrial: "Prueba Gratuita",
    conversationsPerDay: "conversaciones/día",
    unlimitedConversations: "Conversaciones Ilimitadas",
    
    // Settings
    language: "Idioma",
    currency: "Moneda",
    settings: "Configuraciones",
    
    // Errors & Messages
    error: "Error",
    success: "Éxito",
    loading: "Cargando...",
    connectionError: "Error de conexión",
    passwordsDontMatch: "Las contraseñas no coinciden",
    passwordTooShort: "La contraseña debe tener al menos 6 caracteres",
    trialExpired: "¡Tu período de prueba ha expirado!",
    dailyLimitReached: "¡Límite diario de conversaciones alcanzado!",
  },
  
  fr: {
    // Authentication
    email: "Email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    login: "Connexion",
    register: "S'inscrire",
    createAccount: "Créer un compte",
    
    // Main App
    appTitle: "Ami Virtuel",
    subtitle: "Votre compagnon intelligent 24h/24",
    virtualFriend: "Ami Virtuel",
    
    // Home Screen
    welcome: "Bonjour",
    plan: "Plan",
    trialPlan: "Essai Gratuit (10 conversations/jour - 7 jours)",
    premiumPlan: "Premium (Conversations Illimitées)",
    expiredPlan: "Essai Expiré - S'abonner Premium",
    noFriends: "Aucun ami virtuel pour le moment",
    createFirstFriend: "Créez votre premier ami virtuel !",
    
    // Create Friend
    createVirtualFriend: "Créer Ami Virtuel",
    friendName: "Nom de votre ami :",
    friendNamePlaceholder: "Ex: Anne, Charles, Marie...",
    gender: "Genre :",
    male: "Masculin",
    female: "Féminin",
    personality: "Personnalité :",
    personalityPlaceholder: "Ex: attentionné et encourageant, amusant et spirituel...",
    
    // Chat
    online: "En ligne",
    withVoice: "Voix active",
    typePlaceholder: "Tapez votre message...",
    
    // Pricing
    monthly: "Mensuel",
    annual: "Annuel",
    freeTrial: "Essai Gratuit",
    conversationsPerDay: "conversations/jour",
    unlimitedConversations: "Conversations Illimitées",
    
    // Settings
    language: "Langue",
    currency: "Devise",
    settings: "Paramètres",
    
    // Errors & Messages
    error: "Erreur",
    success: "Succès",
    loading: "Chargement...",
    connectionError: "Erreur de connexion",
    passwordsDontMatch: "Les mots de passe ne correspondent pas",
    passwordTooShort: "Le mot de passe doit contenir au moins 6 caractères",
    trialExpired: "Votre période d'essai a expiré !",
    dailyLimitReached: "Limite quotidienne de conversations atteinte !",
  },
};

export const supportedLanguages = [
  { code: 'pt', name: 'Português', flag: '🇧🇷' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
];

export const supportedCurrencies = [
  { code: 'BRL', name: 'Real Brasileiro', flag: '🇧🇷', symbol: 'R$' },
  { code: 'USD', name: 'US Dollar', flag: '🇺🇸', symbol: '$' },
  { code: 'EUR', name: 'Euro', flag: '🇪🇺', symbol: '€' },
  { code: 'GBP', name: 'British Pound', flag: '🇬🇧', symbol: '£' },
  { code: 'JPY', name: 'Japanese Yen', flag: '🇯🇵', symbol: '¥' },
  { code: 'CNY', name: 'Chinese Yuan', flag: '🇨🇳', symbol: '¥' },
  { code: 'MXN', name: 'Mexican Peso', flag: '🇲🇽', symbol: '$' },
  { code: 'ARS', name: 'Argentine Peso', flag: '🇦🇷', symbol: '$' },
];

export const getTranslation = (language: string): Translation => {
  return translations[language] || translations.pt;
};