import { getAiResponse } from './api_service.js';
import { renderMessage, toggleTypingIndicator } from './ui_manager.js';

export let chatHistory = [];

export function addMessageToHistory(messageObject) {
    chatHistory.push(messageObject);
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
}

export function initChat() {
    const chatLog = document.getElementById('chat-log');
    chatLog.innerHTML = ''; 
    const storedHistory = JSON.parse(localStorage.getItem('chatHistory')) || [];
    chatHistory = [...storedHistory];


    const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
    document.getElementById('chat-header-avatar').src = friendConfig.avatar || '';
    
    const friendName = friendConfig.gender === 'male' ? 'Leo' : 'Lia';
    document.getElementById('chat-header-name').innerText = friendName;

    chatHistory.forEach(msg => {
        renderMessage(msg.content, msg.role === 'user' ? 'user' : 'ai');
    });

    if (chatHistory.length === 0) {
        const welcomeMessage = "Olá! Que bom te ver. Sobre o que vamos conversar hoje?";
        addMessageToHistory({ role: 'assistant', content: welcomeMessage });
        renderMessage(welcomeMessage, 'ai');
    }
}

export async function handleSendMessage(event) {
    event.preventDefault();
    const input = document.getElementById('chat-input');
    const messageText = input.value.trim();

    if (!messageText) return;

    renderMessage(messageText, 'user');
    addMessageToHistory({ role: 'user', content: messageText });
    input.value = '';

    toggleTypingIndicator(true);

    try {
        const aiResponse = await getAiResponse(chatHistory);
        renderMessage(aiResponse, 'ai');
        addMessageToHistory({ role: 'assistant', content: aiResponse });
    } catch (error) {
        console.error("Error getting AI response:", error);
        const errorMessage = "Desculpe, estou com um pouco de dificuldade para me conectar agora. Tente novamente mais tarde.";
        renderMessage(errorMessage, 'ai');
        addMessageToHistory({ role: 'assistant', content: errorMessage });
    } finally {
        toggleTypingIndicator(false);
    }
}
