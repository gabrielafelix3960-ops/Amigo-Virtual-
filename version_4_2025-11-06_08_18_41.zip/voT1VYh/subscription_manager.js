const TRIAL_PERIOD_DAYS = 3;

export function startTrial() {
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + TRIAL_PERIOD_DAYS);
    const subscription = {
        status: 'trial',
        trialEnds: trialEndDate.getTime(),
    };
    localStorage.setItem('subscriptionStatus', JSON.stringify(subscription));
}

export function checkSubscription() {
    const subString = localStorage.getItem('subscriptionStatus');
    if (!subString) {
        return { status: 'none' };
    }

    const subscription = JSON.parse(subString);

    if (subscription.status === 'active') {
        if (subscription.expires && new Date().getTime() > subscription.expires) {
            subscription.status = 'expired';
            localStorage.setItem('subscriptionStatus', JSON.stringify(subscription));
            return { status: 'expired' };
        }
        return { status: 'active', plan: subscription.plan };
    }

    if (subscription.status === 'trial') {
        const now = new Date().getTime();
        if (now > subscription.trialEnds) {
            subscription.status = 'expired';
            localStorage.setItem('subscriptionStatus', JSON.stringify(subscription));
            return { status: 'expired' };
        }
        return { status: 'trial', trialEnds: subscription.trialEnds };
    }

    return { status: subscription.status || 'none' };
}

export function activateSubscription(plan) {
    const now = new Date();
    let expiryDate;
    if (plan === 'annual') {
        expiryDate = new Date(now.setFullYear(now.getFullYear() + 1));
    } else {
        expiryDate = new Date(now.setMonth(now.getMonth() + 1));
    }

    const subscription = {
        status: 'active',
        plan: plan,
        startDate: new Date().getTime(),
        expires: expiryDate.getTime(),
    };
    localStorage.setItem('subscriptionStatus', JSON.stringify(subscription));
}
