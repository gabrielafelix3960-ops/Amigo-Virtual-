#!/usr/bin/env python3
"""
Teste específico do sistema de memória inteligente do Amigo Virtual
Testa se o sistema consegue lembrar e referenciar conversas anteriores
"""

import requests
import json
import time
from datetime import datetime

# Configuração
BASE_URL = "https://digital-buddy-11.preview.emergentagent.com/api"

# Dados de teste conforme especificado - usando timestamp para email único
timestamp = int(time.time())
TEST_USER = {
    "email": f"memoria{timestamp}@test.com",
    "password": "123456"
}

TEST_FRIEND = {
    "name": "Sofia",
    "gender": "feminino", 
    "personality": "empática e compreensiva"
}

# Sequência de conversas para testar memória
MEMORY_TEST_CONVERSATIONS = [
    {
        "topic": "TRABALHO",
        "message": "Estou preocupado com minha entrevista de emprego amanhã",
        "expected_keywords": ["entrevista", "emprego", "trabalho"]
    },
    {
        "topic": "ESTUDOS", 
        "message": "Preciso terminar meu trabalho da faculdade sobre química",
        "expected_keywords": ["faculdade", "química", "estudos", "trabalho acadêmico"]
    },
    {
        "topic": "FAMÍLIA",
        "message": "Brigamos eu e minha mãe ontem",
        "expected_keywords": ["mãe", "família", "briga"]
    },
    {
        "topic": "TESTE_MEMORIA_TRABALHO",
        "message": "Como está aquela situação do trabalho?",
        "expected_memory_references": ["entrevista", "emprego", "mencionou", "falou"]
    },
    {
        "topic": "TESTE_MEMORIA_ESTUDOS", 
        "message": "E os estudos?",
        "expected_memory_references": ["química", "faculdade", "trabalho", "lembra"]
    }
]

class MemoryTester:
    def __init__(self):
        self.user_id = None
        self.friend_id = None
        self.conversation_id = None
        self.session = requests.Session()
        self.results = []
        self.conversation_responses = []
        
    def log_result(self, test_name, success, details, response_data=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat(),
            "response_data": response_data
        }
        self.results.append(result)
        status = "✅ PASSOU" if success else "❌ FALHOU"
        print(f"{status} - {test_name}")
        print(f"   Detalhes: {details}")
        if response_data and isinstance(response_data, dict) and "response" in response_data:
            print(f"   Resposta da IA: {response_data['response'][:200]}{'...' if len(response_data['response']) > 200 else ''}")
        print("-" * 80)
        
    def setup_user_and_friend(self):
        """Configurar usuário e amigo virtual para os testes"""
        print("🔧 Configurando usuário e amigo virtual...")
        
        # Registrar usuário
        try:
            response = self.session.post(
                f"{BASE_URL}/register",
                json=TEST_USER,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.user_id = data["user_id"]
                print(f"✅ Usuário registrado: {self.user_id}")
            else:
                print(f"❌ Erro no registro: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Erro de conexão no registro: {str(e)}")
            return False
        
        # Criar amigo virtual
        try:
            response = self.session.post(
                f"{BASE_URL}/friends?user_id={self.user_id}",
                json=TEST_FRIEND,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.friend_id = data["friend"]["id"]
                print(f"✅ Amigo virtual criado: {self.friend_id} - {TEST_FRIEND['name']}")
                return True
            else:
                print(f"❌ Erro na criação do amigo: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Erro de conexão na criação do amigo: {str(e)}")
            return False
    
    def send_message(self, message, topic):
        """Enviar mensagem e retornar resposta da IA"""
        try:
            chat_data = {
                "friend_id": self.friend_id,
                "message": message
            }
            
            response = self.session.post(
                f"{BASE_URL}/chat?user_id={self.user_id}",
                json=chat_data,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                ai_response = data["response"]
                conversation_id = data["conversation_id"]
                
                # Armazenar para análise posterior
                self.conversation_responses.append({
                    "topic": topic,
                    "user_message": message,
                    "ai_response": ai_response,
                    "conversation_id": conversation_id
                })
                
                return ai_response, True
            else:
                return f"Erro {response.status_code}: {response.text}", False
                
        except Exception as e:
            return f"Erro de conexão: {str(e)}", False
    
    def test_memory_sequence(self):
        """Teste principal: sequência de conversas para testar memória"""
        print("🧠 Iniciando teste de sequência de memória...")
        
        for i, conv in enumerate(MEMORY_TEST_CONVERSATIONS):
            print(f"\n📝 Conversa {i+1}: {conv['topic']}")
            print(f"   Mensagem: {conv['message']}")
            
            ai_response, success = self.send_message(conv['message'], conv['topic'])
            
            if not success:
                self.log_result(
                    f"Conversa {i+1} - {conv['topic']}",
                    False,
                    f"Falha na comunicação: {ai_response}",
                    None
                )
                return False
            
            print(f"   Resposta: {ai_response[:150]}{'...' if len(ai_response) > 150 else ''}")
            
            # Verificar se é um teste de memória
            if "TESTE_MEMORIA" in conv['topic']:
                memory_found = self.analyze_memory_response(ai_response, conv)
                self.log_result(
                    f"Conversa {i+1} - {conv['topic']}",
                    memory_found,
                    f"Teste de memória: {'Referências encontradas' if memory_found else 'Nenhuma referência à conversa anterior'}",
                    {"response": ai_response}
                )
            else:
                # Para conversas normais, apenas verificar se a resposta é adequada
                is_adequate = len(ai_response) > 20 and any(word in ai_response.lower() for word in ["você", "entendo", "compreendo", "como", "que"])
                self.log_result(
                    f"Conversa {i+1} - {conv['topic']}",
                    is_adequate,
                    f"Conversa sobre {conv['topic']}: {'Resposta adequada' if is_adequate else 'Resposta inadequada'}",
                    {"response": ai_response}
                )
            
            # Pausa entre conversas para simular uso real
            time.sleep(2)
        
        return True
    
    def analyze_memory_response(self, ai_response, conversation):
        """Analisar se a resposta da IA demonstra memória das conversas anteriores"""
        response_lower = ai_response.lower()
        
        # Verificar palavras-chave que indicam referência à memória
        memory_indicators = [
            "lembra", "mencionou", "falou", "contou", "disse",
            "aquela", "aquele", "situação", "assunto", "conversa",
            "entrevista", "emprego", "química", "faculdade", "mãe"
        ]
        
        found_indicators = []
        for indicator in memory_indicators:
            if indicator in response_lower:
                found_indicators.append(indicator)
        
        # Verificar referências específicas esperadas
        expected_refs = conversation.get("expected_memory_references", [])
        found_expected = []
        for ref in expected_refs:
            if ref.lower() in response_lower:
                found_expected.append(ref)
        
        print(f"   🔍 Indicadores de memória encontrados: {found_indicators}")
        print(f"   🎯 Referências esperadas encontradas: {found_expected}")
        
        # Considerar sucesso se encontrou pelo menos 1 indicador de memória
        return len(found_indicators) > 0
    
    def test_conversation_persistence(self):
        """Verificar se as conversas estão sendo persistidas corretamente"""
        print("💾 Testando persistência das conversas...")
        
        try:
            response = self.session.get(
                f"{BASE_URL}/conversations/{self.user_id}/{self.friend_id}",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                messages = data.get("messages", [])
                
                # Deve ter pelo menos 10 mensagens (5 do usuário + 5 respostas da IA)
                expected_messages = len(MEMORY_TEST_CONVERSATIONS) * 2
                
                if len(messages) >= expected_messages:
                    self.log_result(
                        "Persistência de conversas",
                        True,
                        f"Conversas persistidas corretamente: {len(messages)} mensagens encontradas (esperado: {expected_messages})",
                        {"message_count": len(messages)}
                    )
                    return True
                else:
                    self.log_result(
                        "Persistência de conversas",
                        False,
                        f"Poucas mensagens persistidas: {len(messages)} encontradas (esperado: {expected_messages})",
                        {"message_count": len(messages), "messages": messages}
                    )
                    return False
            else:
                self.log_result(
                    "Persistência de conversas",
                    False,
                    f"Erro ao buscar conversas: {response.status_code} - {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Persistência de conversas",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def analyze_topic_organization(self):
        """Analisar se o sistema está organizando conversas por tópicos"""
        print("🏷️ Analisando organização por tópicos...")
        
        # Verificar se as respostas da IA demonstram compreensão dos tópicos
        topics_recognized = {
            "trabalho": False,
            "estudos": False, 
            "família": False
        }
        
        for conv_data in self.conversation_responses:
            response_lower = conv_data["ai_response"].lower()
            
            if "trabalho" in conv_data["topic"]:
                if any(word in response_lower for word in ["entrevista", "emprego", "trabalho"]):
                    topics_recognized["trabalho"] = True
            elif "estudos" in conv_data["topic"]:
                if any(word in response_lower for word in ["estudo", "faculdade", "química"]):
                    topics_recognized["estudos"] = True
            elif "família" in conv_data["topic"]:
                if any(word in response_lower for word in ["família", "mãe", "briga"]):
                    topics_recognized["família"] = True
        
        recognized_count = sum(topics_recognized.values())
        success = recognized_count >= 2  # Pelo menos 2 dos 3 tópicos reconhecidos
        
        self.log_result(
            "Organização por tópicos",
            success,
            f"Tópicos reconhecidos: {recognized_count}/3 - {topics_recognized}",
            {"topics_recognized": topics_recognized}
        )
        
        return success
    
    def run_memory_tests(self):
        """Executar todos os testes de memória"""
        print("=" * 80)
        print("TESTE ESPECÍFICO DE MEMÓRIA INTELIGENTE - AMIGO VIRTUAL")
        print("=" * 80)
        print(f"URL Base: {BASE_URL}")
        print(f"Usuário de teste: {TEST_USER['email']}")
        print(f"Amigo virtual: {TEST_FRIEND['name']} ({TEST_FRIEND['personality']})")
        print("=" * 80)
        
        # Setup inicial
        if not self.setup_user_and_friend():
            print("❌ Falha na configuração inicial. Abortando testes.")
            return 0, 1
        
        tests = [
            ("Sequência de conversas com memória", self.test_memory_sequence),
            ("Persistência de conversas", self.test_conversation_persistence),
            ("Organização por tópicos", self.analyze_topic_organization)
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            print(f"\n🧪 Executando: {test_name}")
            if test_func():
                passed += 1
            else:
                failed += 1
        
        print("\n" + "=" * 80)
        print("RESUMO DOS TESTES DE MEMÓRIA")
        print("=" * 80)
        print(f"✅ Testes aprovados: {passed}")
        print(f"❌ Testes falharam: {failed}")
        print(f"📊 Total de testes: {passed + failed}")
        print(f"📈 Taxa de sucesso: {(passed/(passed+failed)*100):.1f}%")
        
        # Análise detalhada das conversas
        print("\n🔍 ANÁLISE DETALHADA DAS CONVERSAS:")
        for i, conv_data in enumerate(self.conversation_responses):
            print(f"\n{i+1}. {conv_data['topic']}:")
            print(f"   Usuário: {conv_data['user_message']}")
            print(f"   IA: {conv_data['ai_response'][:200]}{'...' if len(conv_data['ai_response']) > 200 else ''}")
        
        if failed > 0:
            print("\n🔍 TESTES QUE FALHARAM:")
            for result in self.results:
                if not result["success"]:
                    print(f"   ❌ {result['test']}: {result['details']}")
        
        print("=" * 80)
        
        return passed, failed

if __name__ == "__main__":
    tester = MemoryTester()
    passed, failed = tester.run_memory_tests()
    
    # Salvar resultados detalhados
    with open("/app/memory_test_results.json", "w", encoding="utf-8") as f:
        json.dump({
            "results": tester.results,
            "conversations": tester.conversation_responses,
            "summary": {
                "passed": passed,
                "failed": failed,
                "success_rate": (passed/(passed+failed)*100) if (passed+failed) > 0 else 0
            }
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Resultados detalhados salvos em: /app/memory_test_results.json")
    
    # Exit code baseado nos resultados
    exit(0 if failed == 0 else 1)