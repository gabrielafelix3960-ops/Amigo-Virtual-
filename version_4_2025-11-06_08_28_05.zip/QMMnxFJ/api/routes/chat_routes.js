const express = require('express');
const router = express.Router();
const { postMessage } = require('../controllers/chat_controller');
const { protect } = require('../middleware/auth_middleware');

router.post('/', protect, postMessage);

module.exports = router;
