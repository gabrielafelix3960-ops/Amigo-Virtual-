import { getAiResponse } from './api_service.js';
import { renderMessage, toggleTypingIndicator } from './ui_manager.js';

let chatHistory = [];

export function initChat() {
    const chatLog = document.getElementById('chat-log');
    chatLog.innerHTML = ''; 
    chatHistory = JSON.parse(localStorage.getItem('chatHistory')) || [];

    const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
    document.getElementById('chat-header-avatar').src = friendConfig.avatar || '';
    
    const friendName = friendConfig.gender === 'male' ? 'Leo' : 'Lia';
    document.getElementById('chat-header-name').innerText = friendName;

    chatHistory.forEach(msg => {
        renderMessage(msg.content, msg.role === 'user' ? 'user' : 'ai');
    });

    if (chatHistory.length === 0) {
        const welcomeMessage = "Olá! Que bom te ver. Sobre o que vamos conversar hoje?";
        chatHistory.push({ role: 'assistant', content: welcomeMessage });
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
        renderMessage(welcomeMessage, 'ai');
    }
}

export async function handleSendMessage(event) {
    event.preventDefault();
    const input = document.getElementById('chat-input');
    const messageText = input.value.trim();

    if (!messageText) return;

    renderMessage(messageText, 'user');
    chatHistory.push({ role: 'user', content: messageText });
    input.value = '';

    toggleTypingIndicator(true);

    try {
        const aiResponse = await getAiResponse(chatHistory);
        renderMessage(aiResponse, 'ai');
        chatHistory.push({ role: 'assistant', content: aiResponse });
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    } catch (error) {
        console.error("Error getting AI response:", error);
        renderMessage("Desculpe, estou com um pouco de dificuldade para me conectar agora. Tente novamente mais tarde.", 'ai');
    } finally {
        toggleTypingIndicator(false);
    }
}
