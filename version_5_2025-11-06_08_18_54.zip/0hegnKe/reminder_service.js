import { renderMessage } from './ui_manager.js';
import { addMessageToHistory } from './chat_manager.js';

export function startReminderService() {
    console.log('Reminder service started. Checking for appointments every minute.');

    setInterval(async () => {
        const userData = JSON.parse(localStorage.getItem('userData'));
        if (!userData) {
            return; 
        }

        const allAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
        const userAppointments = allAppointments.filter(app => app.user === userData.email);

        const now = new Date();
        const oneHourFromNow = new Date(now.getTime() + 60 * 60 * 1000);

        let appointmentsModified = false;

        for (const app of userAppointments) {
            if (app.reminderSent) {
                continue;
            }

            const [hours, minutes] = app.time.split(':');
            const appDateTime = new Date(app.date);
            appDateTime.setHours(hours, minutes, 0, 0);
            
            
            if (appDateTime > now && appDateTime <= oneHourFromNow) {
                const reminderText = `Lembrete, meu amigo(a)! 😊 Você tem um compromisso agendado: "${app.title}" hoje às ${app.time}.`;
                
                const messageObject = {
                    role: 'assistant',
                    content: reminderText,
                };

                addMessageToHistory(messageObject);
                
                const currentScreen = document.querySelector('.screen:not(.hidden)');
                if (currentScreen && currentScreen.id === 'chat-screen') {
                   renderMessage(reminderText, 'ai');
                }

                app.reminderSent = true;
                appointmentsModified = true;
                console.log(`Reminder sent for appointment ${app._id}`);
            }
        }

        if (appointmentsModified) {
            localStorage.setItem('appointments', JSON.stringify(allAppointments));
        }

    }, 60000); 
}
