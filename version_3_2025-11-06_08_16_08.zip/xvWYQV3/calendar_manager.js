import { addEvent, getEvents, deleteEvent } from './api_service.js';

let currentDate = new Date();
let selectedEventId = null;

export function initCalendar() {
    document.getElementById('prev-month-btn').addEventListener('click', () => changeMonth(-1));
    document.getElementById('next-month-btn').addEventListener('click', () => changeMonth(1));
    document.getElementById('add-event-btn').addEventListener('click', () => openEventModal(new Date()));
    document.getElementById('event-form').addEventListener('submit', handleEventFormSubmit);
    document.getElementById('cancel-event-btn').addEventListener('click', closeEventModal);
    document.getElementById('delete-event-btn').addEventListener('click', handleDeleteEvent);
    
    document.getElementById('calendar-days-grid').addEventListener('click', (e) => {
        const dayCell = e.target.closest('.calendar-day');
        if (!dayCell) return;

        const eventEl = e.target.closest('[data-event-id]');
        if (eventEl) {
            e.stopPropagation();
            const eventId = parseInt(eventEl.dataset.eventId, 10);
            handleEventClick(eventId);
        } else if (!dayCell.classList.contains('other-month')) {
            const dateStr = dayCell.dataset.date;
            openEventModal(new Date(dateStr + 'T00:00:00'));
        }
    });

    renderCalendar();
}

function changeMonth(direction) {
    currentDate.setDate(1); 
    currentDate.setMonth(currentDate.getMonth() + direction);
    renderCalendar();
}

async function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const headerText = new Date(year, month).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
    document.getElementById('month-year-header').textContent = headerText.charAt(0).toUpperCase() + headerText.slice(1);

    const calendarGrid = document.getElementById('calendar-days-grid');
    calendarGrid.innerHTML = '';
    
    const firstDayOfMonth = new Date(year, month, 1);
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(startDate.getDate() - firstDayOfMonth.getDay());

    const events = await getEvents(year, month);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; i < 42; i++) {
        const day = new Date(startDate);
        day.setDate(startDate.getDate() + i);
        
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';
        dayCell.dataset.date = day.toISOString().split('T')[0];

        const dayNumber = document.createElement('span');
        dayNumber.textContent = day.getDate();
        dayNumber.className = 'w-6 h-6 flex items-center justify-center rounded-full mb-1';
        dayCell.appendChild(dayNumber);

        if (day.getMonth() !== month) {
            dayCell.classList.add('other-month');
        } else {
            const dayEvents = events.filter(e => e.date === dayCell.dataset.date);
            if (dayEvents.length > 0) {
                 const eventsContainer = document.createElement('div');
                 eventsContainer.className = 'w-full space-y-1';
                 dayEvents.sort((a,b) => a.time.localeCompare(b.time)).slice(0, 2).forEach(ev => {
                    const eventEl = document.createElement('div');
                    eventEl.textContent = ev.title;
                    eventEl.dataset.eventId = ev.id;
                    eventEl.className = 'event-details';
                    eventsContainer.appendChild(eventEl);
                 });
                 if (dayEvents.length > 2) {
                     const moreEventsEl = document.createElement('div');
                     moreEventsEl.textContent = `+${dayEvents.length - 2} mais`;
                     moreEventsEl.className = 'text-xs text-gray-500 text-center font-medium';
                     eventsContainer.appendChild(moreEventsEl);
                 }
                 dayCell.appendChild(eventsContainer);
            }
        }
        
        if (day.toDateString() === today.toDateString()) {
            dayNumber.classList.add('today');
        }

        calendarGrid.appendChild(dayCell);
    }
}

function formatDateForInput(date) {
    const d = new Date(date);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().split('T')[0];
}

async function handleEventClick(eventId) {
    const allEvents = await getEvents();
    const event = allEvents.find(e => e.id === eventId);
    if (event) {
        selectedEventId = eventId;
        openEventModal(new Date(event.date + 'T00:00:00'), event);
    }
}

function openEventModal(date, event = null) {
    const modal = document.getElementById('event-modal');
    const form = document.getElementById('event-form');
    form.reset();
    
    document.getElementById('event-date').value = formatDateForInput(date);

    if (event) {
        document.getElementById('event-modal-title').textContent = 'Detalhes do Evento';
        document.getElementById('event-id').value = event.id;
        document.getElementById('event-title').value = event.title;
        document.getElementById('event-time').value = event.time;
        document.getElementById('event-type').value = event.type;
        document.getElementById('delete-event-btn').classList.remove('hidden');
    } else {
        selectedEventId = null;
        document.getElementById('event-modal-title').textContent = 'Adicionar Evento';
        document.getElementById('event-id').value = '';
        document.getElementById('delete-event-btn').classList.add('hidden');
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        document.getElementById('event-time').value = `${hours}:${minutes}`;
    }
    
    modal.classList.remove('hidden');
}

function closeEventModal() {
    document.getElementById('event-modal').classList.add('hidden');
    selectedEventId = null;
}

async function handleEventFormSubmit(e) {
    e.preventDefault();
    const eventData = {
        title: document.getElementById('event-title').value,
        date: document.getElementById('event-date').value,
        time: document.getElementById('event-time').value,
        type: document.getElementById('event-type').value,
    };
    
    if (selectedEventId) {
        await deleteEvent(selectedEventId);
        await addEvent({ ...eventData, id: selectedEventId });
    } else {
        await addEvent(eventData);
    }

    closeEventModal();
    renderCalendar();
}

async function handleDeleteEvent() {
    if (selectedEventId) {
        await deleteEvent(selectedEventId);
        closeEventModal();
        renderCalendar();
    }
}
