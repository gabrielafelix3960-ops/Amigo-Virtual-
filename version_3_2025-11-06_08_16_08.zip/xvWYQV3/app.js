import { showScreen, initializeUI, setupQuestionnaire, setupFriendSelection, showAppView } from './ui_manager.js';
import { handleLogin, handleRegister, checkAuth, handleLogout } from './auth_manager.js';
import { initChat, handleSendMessage } from './chat_manager.js';
import { initCalendar } from './calendar_manager.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    initializeUI();
    setupEventListeners();
    checkInitialAuth();
});

function setupEventListeners() {
    document.getElementById('go-to-login-btn').addEventListener('click', () => showScreen('login-screen'));
    document.getElementById('go-to-register-btn').addEventListener('click', () => showScreen('register-screen'));
    
    document.querySelectorAll('.nav-back-btn').forEach(btn => {
        btn.addEventListener('click', () => showScreen('welcome-screen'));
    });

    document.getElementById('register-form').addEventListener('submit', handleRegister);
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    document.getElementById('finish-questionnaire-btn').addEventListener('click', () => {
        setupQuestionnaire(); 
        showScreen('friend-setup-screen');
    });

    document.getElementById('finish-setup-btn').addEventListener('click', () => {
        setupFriendSelection();
        initChat();
        initCalendar();
        showScreen('chat-screen');
        showAppView('chat-view');
    });

    document.getElementById('chat-form').addEventListener('submit', handleSendMessage);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    document.getElementById('nav-chat-btn').addEventListener('click', () => showAppView('chat-view'));
    document.getElementById('nav-calendar-btn').addEventListener('click', () => showAppView('calendar-view'));
}

function checkInitialAuth() {
    const user = checkAuth();
    if (user) {
        const friendConfig = JSON.parse(localStorage.getItem('friendConfig'));
        if (friendConfig) {
            initChat();
            initCalendar();
            showScreen('chat-screen');
            showAppView('chat-view');
        } else {
            const questionnaireData = JSON.parse(localStorage.getItem('questionnaireData'));
            if(questionnaireData) {
                 showScreen('friend-setup-screen');
            } else {
                 showScreen('questionnaire-screen');
            }
        }
    } else {
        showScreen('welcome-screen');
    }
}
