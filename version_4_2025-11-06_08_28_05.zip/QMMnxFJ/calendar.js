const AUTH_TOKEN = 'YOUR_JWT_TOKEN_HERE';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const calendarGrid = document.getElementById('calendar-grid');
    const currentMonthEl = document.getElementById('current-month');
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    const appointmentForm = document.getElementById('appointment-form');
    const appointmentsListEl = document.getElementById('appointments-list');
    const appointmentsHeader = document.getElementById('appointments-header');
    const appointmentsPlaceholder = document.getElementById('appointments-placeholder');
    const titleInput = document.getElementById('title');
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    let currentDate = new Date();
    let appointments = [];
    let selectedDate = null;

    const toISODateString = (date) => {
        return new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().split('T')[0];
    };

    const fetchAppointments = async () => {
        if (AUTH_TOKEN === 'YOUR_JWT_TOKEN_HERE') {
            appointmentsListEl.innerHTML = `<p class="text-red-500 font-semibold">Erro: Token de autenticação não configurado. Por favor, edite o arquivo calendar.js e substitua 'YOUR_JWT_TOKEN_HERE' por um token válido.</p>`;
            return;
        }
        try {
            const response = await fetch('/api/appointments', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${AUTH_TOKEN}`
                }
            });
            if (!response.ok) {
                if (response.status === 401) {
                     appointmentsListEl.innerHTML = `<p class="text-red-500 font-semibold">Erro de autenticação (401). Verifique se o seu token JWT é válido e não expirou.</p>`;
                }
                throw new Error(`Failed to fetch appointments. Status: ${response.status}`);
            }
            appointments = await response.json();
            renderCalendar();
            renderAppointmentsForDate(selectedDate);
        } catch (error) {
            console.error('Error fetching appointments:', error);
        }
    };

    const renderCalendar = () => {
        calendarGrid.innerHTML = '';
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        currentMonthEl.textContent = `${currentDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).toUpperCase()}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const today = new Date();

        for (let i = 0; i < firstDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'calendar-day other-month';
            calendarGrid.appendChild(emptyCell);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'calendar-day';
            const date = new Date(year, month, day);
            const dateStr = toISODateString(date);

            if (date.toDateString() === today.toDateString()) {
                dayCell.classList.add('today');
            }
            if (selectedDate && date.toDateString() === selectedDate.toDateString()) {
                dayCell.classList.add('selected');
            }

            const dayNumber = document.createElement('span');
            dayNumber.className = 'day-number';
            dayNumber.textContent = day;
            dayCell.appendChild(dayNumber);

            const dayAppointments = appointments.filter(app => app.date === dateStr);
            if (dayAppointments.length > 0) {
                const dotContainer = document.createElement('div');
                dotContainer.className = 'appointment-dot-container';
                dayAppointments.slice(0, 4).forEach(() => {
                    const dot = document.createElement('div');
                    dot.className = 'appointment-dot';
                    dotContainer.appendChild(dot);
                });
                dayCell.appendChild(dotContainer);
            }

            dayCell.addEventListener('click', () => {
                selectedDate = date;
                dateInput.value = toISODateString(date);
                renderCalendar();
                renderAppointmentsForDate(date);
            });
            calendarGrid.appendChild(dayCell);
        }
    };

    const renderAppointmentsForDate = (date) => {
        if (!date) {
            appointmentsHeader.textContent = 'Compromissos';
            appointmentsPlaceholder.style.display = 'block';
            appointmentsListEl.innerHTML = '';
            appointmentsListEl.appendChild(appointmentsPlaceholder);
            return;
        }

        const dateStr = toISODateString(date);
        const dayAppointments = appointments.filter(app => app.date === dateStr);
        appointmentsHeader.textContent = `Compromissos de ${date.toLocaleDateString('pt-BR')}`;
        
        appointmentsListEl.innerHTML = '';
        if (dayAppointments.length === 0) {
            appointmentsPlaceholder.textContent = 'Nenhum compromisso para este dia.';
            appointmentsListEl.appendChild(appointmentsPlaceholder);
        } else {
            dayAppointments.forEach(app => {
                const appEl = document.createElement('div');
                appEl.className = 'p-2 border rounded-md bg-violet-50 flex justify-between items-center';
                appEl.innerHTML = `
                    <div>
                        <p class="font-semibold">${app.title}</p>
                        <p class="text-sm text-gray-600">${app.time}</p>
                    </div>
                `;
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'p-1 text-red-500 hover:text-red-700 hover:bg-red-100 rounded-full';
                const trashIcon = document.createElement('i');
                trashIcon.setAttribute('data-lucide', 'trash-2');
                trashIcon.className = 'w-4 h-4';
                deleteBtn.appendChild(trashIcon);

                deleteBtn.addEventListener('click', () => handleDeleteAppointment(app._id));
                appEl.appendChild(deleteBtn);
                appointmentsListEl.appendChild(appEl);
            });
            lucide.createIcons();
        }
    };

    const handleAddAppointment = async (e) => {
        e.preventDefault();
        const title = titleInput.value;
        const date = dateInput.value;
        const time = timeInput.value;

        if (!title || !date || !time) return;

        try {
            const response = await fetch('/api/appointments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${AUTH_TOKEN}`
                },
                body: JSON.stringify({ title, date, time })
            });
            if (!response.ok) {
                throw new Error('Failed to create appointment');
            }
            appointmentForm.reset();
            if (selectedDate) {
                 dateInput.value = toISODateString(selectedDate);
            }
            await fetchAppointments();
        } catch (error) {
            console.error('Error creating appointment:', error);
        }
    };
    
    const handleDeleteAppointment = async (appointmentId) => {
        if (!confirm('Tem certeza que deseja excluir este compromisso?')) return;
        
        try {
            const response = await fetch(`/api/appointments/${appointmentId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${AUTH_TOKEN}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to delete appointment');
            }
            
            await fetchAppointments();
        } catch (error) {
            console.error('Error deleting appointment:', error);
        }
    };

    prevMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    nextMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    appointmentForm.addEventListener('submit', handleAddAppointment);

    fetchAppointments();
});
