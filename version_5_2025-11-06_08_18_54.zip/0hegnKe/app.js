import { showScreen, initializeUI, setupQuestionnaire, setupFriendSelection, renderAppointments } from './ui_manager.js';
import { handleLogin, handleRegister, checkAuth, handleLogout } from './auth_manager.js';
import { initChat, handleSendMessage } from './chat_manager.js';
import { getAppointments } from './api_service.js';
import { startReminderService } from './reminder_service.js';

let reminderServiceStarted = false;

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    initializeUI();
    setupEventListeners();
    checkInitialAuth();
});

function setupEventListeners() {
    document.getElementById('go-to-login-btn').addEventListener('click', () => showScreen('login-screen'));
    document.getElementById('go-to-register-btn').addEventListener('click', () => showScreen('register-screen'));
    
    document.querySelectorAll('.nav-back-btn').forEach(btn => {
        btn.addEventListener('click', () => showScreen('welcome-screen'));
    });

    document.getElementById('register-form').addEventListener('submit', handleRegister);
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        const loggedIn = await handleLogin(e);
        if (loggedIn && !reminderServiceStarted) {
            startReminderService();
            reminderServiceStarted = true;
        }
    });
    
    document.getElementById('finish-questionnaire-btn').addEventListener('click', () => {
        setupQuestionnaire(); 
        showScreen('friend-setup-screen');
    });

    document.getElementById('finish-setup-btn').addEventListener('click', () => {
        setupFriendSelection();
        initChat();
        showScreen('chat-screen');
    });

    document.getElementById('chat-form').addEventListener('submit', handleSendMessage);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    document.getElementById('go-to-calendar').addEventListener('click', async () => {
        try {
            const appointments = await getAppointments();
            renderAppointments(appointments);
            showScreen('calendar-screen');
        } catch (error) {
            console.error('Could not load appointments', error);
            alert('Não foi possível carregar os compromissos.');
        }
    });

    document.getElementById('back-to-chat-from-calendar').addEventListener('click', () => {
        showScreen('chat-screen');
    });
}

function checkInitialAuth() {
    const user = checkAuth();
    if (user) {
        if (!reminderServiceStarted) {
            startReminderService();
            reminderServiceStarted = true;
        }
        const friendConfig = JSON.parse(localStorage.getItem('friendConfig'));
        if (friendConfig) {
            initChat();
            showScreen('chat-screen');
        } else {
            showScreen('friend-setup-screen');
        }
    } else {
        showScreen('welcome-screen');
    }
}
