#!/usr/bin/env python3
"""
Teste específico do novo modelo de negócio de 7 dias de teste
Testa todos os cenários prioritários conforme solicitado
"""

import requests
import json
import time
from datetime import datetime, timedelta
from motor.motor_asyncio import AsyncIOMotorClient
import asyncio
import os
from dotenv import load_dotenv
from pathlib import Path

# Carregar variáveis de ambiente
ROOT_DIR = Path(__file__).parent / "backend"
load_dotenv(ROOT_DIR / '.env')

# Configuração
BASE_URL = "https://digital-buddy-11.preview.emergentagent.com/api"

class TrialBusinessModelTester:
    def __init__(self):
        self.session = requests.Session()
        self.results = []
        self.mongo_client = None
        self.db = None
        
    async def setup_db_connection(self):
        """Configurar conexão com MongoDB para testes diretos"""
        try:
            mongo_url = os.environ['MONGO_URL'].strip('"')
            self.mongo_client = AsyncIOMotorClient(mongo_url)
            self.db = self.mongo_client[os.environ['DB_NAME'].strip('"')]
            print("✅ Conexão com MongoDB estabelecida")
        except Exception as e:
            print(f"❌ Erro ao conectar com MongoDB: {str(e)}")
            
    async def cleanup_db_connection(self):
        """Fechar conexão com MongoDB"""
        if self.mongo_client:
            self.mongo_client.close()
        
    def log_result(self, test_name, success, details, response_data=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat(),
            "response_data": response_data
        }
        self.results.append(result)
        status = "✅ PASSOU" if success else "❌ FALHOU"
        print(f"{status} - {test_name}")
        print(f"   Detalhes: {details}")
        if response_data:
            print(f"   Resposta: {json.dumps(response_data, indent=2, ensure_ascii=False)}")
        print("-" * 80)
        
    def test_new_user_trial_setup(self):
        """CENÁRIO 1: Novo usuário - período de teste ativo"""
        print("\n🔍 TESTANDO CENÁRIO 1: Novo usuário - período de teste ativo")
        
        # Criar usuário único com timestamp
        timestamp = int(time.time())
        test_user = {
            "email": f"trial_test_{timestamp}@test.com",
            "password": "123456"
        }
        
        try:
            # 1. Registrar novo usuário
            response = self.session.post(
                f"{BASE_URL}/register",
                json=test_user,
                timeout=10
            )
            
            if response.status_code != 200:
                self.log_result(
                    "Registro de usuário trial",
                    False,
                    f"Falha no registro: Status {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False, None, None
                
            user_data = response.json()
            user_id = user_data.get("user_id")
            
            if not user_id:
                self.log_result(
                    "Registro de usuário trial",
                    False,
                    "User ID não retornado no registro",
                    user_data
                )
                return False, None, None
            
            # 2. Verificar se usuário foi criado com subscription_type="trial" e trial_end_date correto
            # Isso será verificado indiretamente através do comportamento da API
            
            # 3. Criar amigo virtual para testes
            friend_data = {
                "name": "Carlos",
                "gender": "masculino",
                "personality": "motivador"
            }
            
            response = self.session.post(
                f"{BASE_URL}/friends?user_id={user_id}",
                json=friend_data,
                timeout=10
            )
            
            if response.status_code != 200:
                self.log_result(
                    "Criação de amigo para teste trial",
                    False,
                    f"Falha na criação do amigo: Status {response.status_code}",
                    None
                )
                return False, user_id, None
                
            friend_response = response.json()
            friend_id = friend_response.get("friend", {}).get("id")
            
            if not friend_id:
                self.log_result(
                    "Criação de amigo para teste trial",
                    False,
                    "Friend ID não retornado",
                    friend_response
                )
                return False, user_id, None
            
            self.log_result(
                "Setup inicial do usuário trial",
                True,
                f"Usuário trial criado com sucesso. User ID: {user_id}, Friend ID: {friend_id}",
                {"user_id": user_id, "friend_id": friend_id}
            )
            
            return True, user_id, friend_id
            
        except Exception as e:
            self.log_result(
                "Setup inicial do usuário trial",
                False,
                f"Erro durante setup: {str(e)}",
                None
            )
            return False, None, None
    
    def test_trial_daily_limit(self, user_id, friend_id):
        """Testar limite de 10 conversas diárias durante trial"""
        print("\n🔍 TESTANDO: Limite de 10 conversas diárias no trial")
        
        if not user_id or not friend_id:
            self.log_result(
                "Teste de limite diário trial",
                False,
                "User ID ou Friend ID não disponível",
                None
            )
            return False
        
        try:
            successful_chats = 0
            limit_reached = False
            limit_error_message = None
            
            # Tentar fazer 11 conversas para testar o limite
            for i in range(11):
                chat_data = {
                    "friend_id": friend_id,
                    "message": f"Mensagem de teste trial {i+1}"
                }
                
                response = self.session.post(
                    f"{BASE_URL}/chat?user_id={user_id}",
                    json=chat_data,
                    timeout=30
                )
                
                if response.status_code == 200:
                    successful_chats += 1
                    print(f"   ✅ Conversa {i+1}: Sucesso")
                elif response.status_code == 429:
                    # Limite diário atingido
                    limit_reached = True
                    limit_error_message = response.json().get("detail", response.text)
                    print(f"   🚫 Conversa {i+1}: Limite atingido - {limit_error_message}")
                    break
                else:
                    print(f"   ❌ Conversa {i+1}: Erro {response.status_code} - {response.text}")
                    break
                
                time.sleep(0.5)  # Pequena pausa entre requests
            
            # Verificar se o comportamento está correto
            if successful_chats == 10 and limit_reached:
                # Verificar se a mensagem de erro está correta
                expected_message = "Limite de 10 conversas diárias atingido! Você ainda tem acesso até o fim do período de teste."
                if expected_message in limit_error_message:
                    self.log_result(
                        "Limite diário trial (10 conversas)",
                        True,
                        f"Limite funcionando corretamente: {successful_chats} conversas permitidas, 11ª bloqueada com mensagem correta",
                        {"successful_chats": successful_chats, "limit_message": limit_error_message}
                    )
                    return True
                else:
                    self.log_result(
                        "Limite diário trial (mensagem de erro)",
                        False,
                        f"Limite funcionando mas mensagem incorreta. Esperado: '{expected_message}', Recebido: '{limit_error_message}'",
                        {"successful_chats": successful_chats, "limit_message": limit_error_message}
                    )
                    return False
            else:
                self.log_result(
                    "Limite diário trial",
                    False,
                    f"Comportamento incorreto: {successful_chats} conversas realizadas, limite atingido: {limit_reached}",
                    {"successful_chats": successful_chats, "limit_reached": limit_reached, "limit_message": limit_error_message}
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Limite diário trial",
                False,
                f"Erro durante teste de limite: {str(e)}",
                None
            )
            return False
    
    async def test_trial_expiration(self):
        """CENÁRIO 2: Teste de expiração do trial (simular)"""
        print("\n🔍 TESTANDO CENÁRIO 2: Expiração do trial")
        
        if self.db is None:
            self.log_result(
                "Teste de expiração trial",
                False,
                "Conexão com MongoDB não disponível",
                None
            )
            return False, None, None
        
        try:
            # 1. Criar usuário para teste de expiração
            timestamp = int(time.time())
            test_user = {
                "email": f"expired_trial_{timestamp}@test.com",
                "password": "123456"
            }
            
            response = self.session.post(
                f"{BASE_URL}/register",
                json=test_user,
                timeout=10
            )
            
            if response.status_code != 200:
                self.log_result(
                    "Registro usuário para teste expiração",
                    False,
                    f"Falha no registro: {response.status_code}",
                    None
                )
                return False, None, None
                
            user_data = response.json()
            user_id = user_data.get("user_id")
            
            # 2. Criar amigo virtual
            friend_data = {
                "name": "Carlos",
                "gender": "masculino", 
                "personality": "motivador"
            }
            
            response = self.session.post(
                f"{BASE_URL}/friends?user_id={user_id}",
                json=friend_data,
                timeout=10
            )
            
            friend_response = response.json()
            friend_id = friend_response.get("friend", {}).get("id")
            
            # 3. Alterar manualmente trial_end_date para data passada
            past_date = datetime.utcnow() - timedelta(days=1)  # 1 dia no passado
            
            result = await self.db.users.update_one(
                {"id": user_id},
                {"$set": {"trial_end_date": past_date}}
            )
            
            if result.modified_count == 0:
                self.log_result(
                    "Alteração trial_end_date",
                    False,
                    "Não foi possível alterar trial_end_date no banco",
                    None
                )
                return False, user_id, friend_id
            
            print(f"   ✅ trial_end_date alterado para: {past_date}")
            
            # 4. Tentar conversar (deve dar erro 402)
            chat_data = {
                "friend_id": friend_id,
                "message": "Teste após expiração do trial"
            }
            
            response = self.session.post(
                f"{BASE_URL}/chat?user_id={user_id}",
                json=chat_data,
                timeout=30
            )
            
            if response.status_code == 402:
                error_message = response.json().get("detail", response.text)
                expected_message = "Seu período de teste de 7 dias expirou! Para continuar conversando"
                
                if expected_message in error_message:
                    self.log_result(
                        "Bloqueio por trial expirado",
                        True,
                        f"Trial expirado bloqueado corretamente com mensagem adequada: {error_message}",
                        {"status_code": response.status_code, "error_message": error_message}
                    )
                    
                    # 5. Verificar se usuário foi atualizado para "expired"
                    user_doc = await self.db.users.find_one({"id": user_id})
                    if user_doc and user_doc.get("subscription_type") == "expired":
                        self.log_result(
                            "Atualização status para expired",
                            True,
                            "Usuário foi automaticamente atualizado para subscription_type='expired'",
                            {"subscription_type": user_doc.get("subscription_type")}
                        )
                        return True, user_id, friend_id
                    else:
                        self.log_result(
                            "Atualização status para expired",
                            False,
                            f"Usuário não foi atualizado para 'expired'. Status atual: {user_doc.get('subscription_type') if user_doc else 'usuário não encontrado'}",
                            {"subscription_type": user_doc.get("subscription_type") if user_doc else None}
                        )
                        return False, user_id, friend_id
                else:
                    self.log_result(
                        "Mensagem de erro trial expirado",
                        False,
                        f"Mensagem de erro incorreta. Esperado: '{expected_message}...', Recebido: '{error_message}'",
                        {"error_message": error_message}
                    )
                    return False, user_id, friend_id
            else:
                self.log_result(
                    "Bloqueio por trial expirado",
                    False,
                    f"Trial expirado não foi bloqueado. Status: {response.status_code}, Resposta: {response.text}",
                    {"status_code": response.status_code, "response": response.text}
                )
                return False, user_id, friend_id
                
        except Exception as e:
            self.log_result(
                "Teste de expiração trial",
                False,
                f"Erro durante teste: {str(e)}",
                None
            )
            return False, None, None
    
    async def test_expired_user_access(self, user_id, friend_id):
        """Testar acesso de usuário com status expired"""
        print("\n🔍 TESTANDO: Acesso de usuário expired")
        
        if not user_id or not friend_id:
            self.log_result(
                "Teste usuário expired",
                False,
                "User ID ou Friend ID não disponível",
                None
            )
            return False
        
        try:
            # Tentar conversar com usuário expired
            chat_data = {
                "friend_id": friend_id,
                "message": "Teste com usuário expired"
            }
            
            response = self.session.post(
                f"{BASE_URL}/chat?user_id={user_id}",
                json=chat_data,
                timeout=30
            )
            
            if response.status_code == 402:
                error_message = response.json().get("detail", response.text)
                expected_phrases = [
                    "período de teste expirou",
                    "Assine o plano premium"
                ]
                
                message_correct = all(phrase in error_message for phrase in expected_phrases)
                
                if message_correct:
                    self.log_result(
                        "Bloqueio usuário expired",
                        True,
                        f"Usuário expired bloqueado corretamente: {error_message}",
                        {"error_message": error_message}
                    )
                    return True
                else:
                    self.log_result(
                        "Mensagem erro usuário expired",
                        False,
                        f"Mensagem de erro inadequada para usuário expired: {error_message}",
                        {"error_message": error_message}
                    )
                    return False
            else:
                self.log_result(
                    "Bloqueio usuário expired",
                    False,
                    f"Usuário expired não foi bloqueado. Status: {response.status_code}",
                    {"status_code": response.status_code, "response": response.text}
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Teste usuário expired",
                False,
                f"Erro durante teste: {str(e)}",
                None
            )
            return False
    
    async def verify_trial_setup_in_db(self, user_id):
        """Verificar se o usuário foi criado corretamente no banco"""
        print("\n🔍 VERIFICANDO: Setup do trial no banco de dados")
        
        if self.db is None or not user_id:
            self.log_result(
                "Verificação trial no DB",
                False,
                "Conexão DB ou User ID não disponível",
                None
            )
            return False
        
        try:
            user_doc = await self.db.users.find_one({"id": user_id})
            
            if not user_doc:
                self.log_result(
                    "Verificação usuário no DB",
                    False,
                    "Usuário não encontrado no banco de dados",
                    None
                )
                return False
            
            checks = []
            all_checks_passed = True
            
            # Verificar subscription_type
            if user_doc.get("subscription_type") == "trial":
                checks.append("✅ subscription_type = 'trial'")
            else:
                checks.append(f"❌ subscription_type = '{user_doc.get('subscription_type')}' (esperado: 'trial')")
                all_checks_passed = False
            
            # Verificar trial_end_date
            trial_end = user_doc.get("trial_end_date")
            if trial_end:
                if isinstance(trial_end, str):
                    trial_end = datetime.fromisoformat(trial_end.replace('Z', '+00:00'))
                
                now = datetime.utcnow()
                days_diff = (trial_end - now).days
                
                if 6 <= days_diff <= 7:  # Deve estar entre 6 e 7 dias no futuro
                    checks.append(f"✅ trial_end_date em {days_diff} dias ({trial_end.strftime('%Y-%m-%d %H:%M')})")
                else:
                    checks.append(f"❌ trial_end_date em {days_diff} dias (esperado: ~7 dias)")
                    all_checks_passed = False
            else:
                checks.append("❌ trial_end_date não definido")
                all_checks_passed = False
            
            # Verificar conversations_today
            conversations_today = user_doc.get("conversations_today", 0)
            checks.append(f"ℹ️ conversations_today = {conversations_today}")
            
            self.log_result(
                "Verificação trial no DB",
                all_checks_passed,
                f"Verificações do usuário trial: {'; '.join(checks)}",
                {
                    "subscription_type": user_doc.get("subscription_type"),
                    "trial_end_date": str(trial_end) if trial_end else None,
                    "conversations_today": conversations_today
                }
            )
            
            return all_checks_passed
            
        except Exception as e:
            self.log_result(
                "Verificação trial no DB",
                False,
                f"Erro durante verificação: {str(e)}",
                None
            )
            return False
    
    async def run_all_trial_tests(self):
        """Executar todos os testes do modelo de negócio trial"""
        print("=" * 80)
        print("TESTANDO NOVO MODELO DE NEGÓCIO - 7 DIAS DE TESTE")
        print("=" * 80)
        print(f"URL Base: {BASE_URL}")
        print("Cenários prioritários:")
        print("1. Novo usuário - período de teste ativo")
        print("2. Teste de expiração do trial (simular)")
        print("3. Verificar mensagens de erro específicas")
        print("=" * 80)
        
        await self.setup_db_connection()
        
        passed = 0
        failed = 0
        
        try:
            # CENÁRIO 1: Novo usuário - período de teste ativo
            success, user_id, friend_id = self.test_new_user_trial_setup()
            if success:
                passed += 1
                
                # Verificar setup no banco de dados
                if await self.verify_trial_setup_in_db(user_id):
                    passed += 1
                else:
                    failed += 1
                
                # Testar limite de 10 conversas diárias
                if self.test_trial_daily_limit(user_id, friend_id):
                    passed += 1
                else:
                    failed += 1
            else:
                failed += 3  # Falhou setup, verificação DB e limite diário
            
            # CENÁRIO 2: Teste de expiração do trial
            success, expired_user_id, expired_friend_id = await self.test_trial_expiration()
            if success:
                passed += 2  # Expiração + atualização status
                
                # Testar acesso contínuo de usuário expired
                if await self.test_expired_user_access(expired_user_id, expired_friend_id):
                    passed += 1
                else:
                    failed += 1
            else:
                failed += 3  # Falhou expiração, atualização status e acesso expired
            
        except Exception as e:
            print(f"❌ Erro geral durante testes: {str(e)}")
            failed += 6  # Todos os testes falharam
        
        finally:
            await self.cleanup_db_connection()
        
        # Resumo final
        print("\n" + "=" * 80)
        print("RESUMO DOS TESTES DO MODELO DE NEGÓCIO TRIAL")
        print("=" * 80)
        print(f"✅ Testes aprovados: {passed}")
        print(f"❌ Testes falharam: {failed}")
        print(f"📊 Total de testes: {passed + failed}")
        if passed + failed > 0:
            print(f"📈 Taxa de sucesso: {(passed/(passed+failed)*100):.1f}%")
        
        if failed > 0:
            print("\n🔍 TESTES QUE FALHARAM:")
            for result in self.results:
                if not result["success"]:
                    print(f"   ❌ {result['test']}: {result['details']}")
        
        # Avaliação final para Google Play
        print("\n" + "=" * 80)
        print("AVALIAÇÃO PARA GOOGLE PLAY")
        print("=" * 80)
        
        if failed == 0:
            print("🎉 SISTEMA PRONTO PARA VENDA!")
            print("✅ Todos os cenários do modelo de negócio funcionando corretamente")
            print("✅ Mensagens de erro comerciais adequadas")
            print("✅ Limites e expiração funcionando como esperado")
        elif failed <= 2:
            print("⚠️ SISTEMA QUASE PRONTO - PEQUENOS AJUSTES NECESSÁRIOS")
            print("🔧 Alguns detalhes precisam ser refinados antes da publicação")
        else:
            print("🚫 SISTEMA NÃO PRONTO PARA VENDA")
            print("❌ Problemas críticos no modelo de negócio precisam ser corrigidos")
        
        print("=" * 80)
        
        return passed, failed

async def main():
    tester = TrialBusinessModelTester()
    passed, failed = await tester.run_all_trial_tests()
    
    # Salvar resultados detalhados
    with open("/app/trial_business_test_results.json", "w", encoding="utf-8") as f:
        json.dump(tester.results, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Resultados detalhados salvos em: /app/trial_business_test_results.json")
    
    # Exit code baseado nos resultados
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)