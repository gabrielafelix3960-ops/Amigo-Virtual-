const Appointment = require('../models/appointment_model.js');

const getAppointments = async (req, res) => {
    try {
        const appointments = await Appointment.find({ user: req.user.id }).sort({ date: 1, time: 1 });
        res.status(200).json(appointments);
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
};

const createAppointment = async (req, res) => {
    try {
        const { title, date, time } = req.body;

        if (!title || !date || !time) {
            return res.status(400).json({ success: false, message: 'Please provide title, date, and time.' });
        }

        const appointment = new Appointment({
            user: req.user.id,
            title,
            date,
            time,
        });

        const createdAppointment = await appointment.save();
        res.status(201).json(createdAppointment);
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
};

const updateAppointment = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

const deleteAppointment = async (req, res) => {
    try {
        const appointment = await Appointment.findById(req.params.id);

        if (!appointment) {
            return res.status(404).json({ success: false, message: 'Appointment not found.' });
        }

        if (appointment.user.toString() !== req.user.id) {
            return res.status(401).json({ success: false, message: 'Not authorized to delete this appointment.' });
        }

        await appointment.deleteOne();

        res.status(200).json({ success: true, message: 'Appointment removed.' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
};

module.exports = {
    getAppointments,
    createAppointment,
    updateAppointment,
    deleteAppointment,
};
