import { showScreen, initializeUI, setupQuestionnaire, setupFriendSelection, setupPaywall } from './ui_manager.js';
import { handleLogin, handleRegister, checkAuth, handleLogout } from './auth_manager.js';
import { initChat, handleSendMessage } from './chat_manager.js';
import { checkSubscription, activateSubscription } from './subscription_manager.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    initializeUI();
    setupPaywall();
    setupEventListeners();
    checkInitialAuth();
});

function setupEventListeners() {
    document.getElementById('go-to-login-btn').addEventListener('click', () => showScreen('login-screen'));
    document.getElementById('go-to-register-btn').addEventListener('click', () => showScreen('register-screen'));
    
    document.querySelectorAll('.nav-back-btn').forEach(btn => {
        btn.addEventListener('click', () => showScreen('welcome-screen'));
    });

    document.getElementById('register-form').addEventListener('submit', handleRegister);
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    document.getElementById('finish-questionnaire-btn').addEventListener('click', () => {
        setupQuestionnaire(); 
        showScreen('friend-setup-screen');
    });

    document.getElementById('finish-setup-btn').addEventListener('click', () => {
        setupFriendSelection();
        initChat();
        showScreen('chat-screen');
    });

    document.getElementById('chat-form').addEventListener('submit', handleSendMessage);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    document.getElementById('pay-stripe-btn').addEventListener('click', () => handlePayment('stripe'));
    document.getElementById('pay-paypal-btn').addEventListener('click', () => handlePayment('paypal'));
    document.getElementById('go-to-chat-btn').addEventListener('click', () => {
        initChat();
        showScreen('chat-screen');
    });
}

function handlePayment(provider) {
    const selectedPlanEl = document.querySelector('.plan-card.selected');
    if (!selectedPlanEl) {
        alert('Por favor, selecione um plano.');
        return;
    }
    const plan = selectedPlanEl.dataset.plan;
    activateSubscription(plan);
    showScreen('confirmation-screen');
}


function checkInitialAuth() {
    const user = checkAuth();
    if (user) {
        const sub = checkSubscription();
        
        if (sub.status === 'active' || sub.status === 'trial') {
            const friendConfig = JSON.parse(localStorage.getItem('friendConfig'));
            const questionnaireComplete = localStorage.getItem('questionnaireComplete');

            if (friendConfig) {
                initChat();
                showScreen('chat-screen');
            } else if (questionnaireComplete) {
                showScreen('friend-setup-screen');
            } else {
                showScreen('questionnaire-screen');
            }
        } else { 
            showScreen('paywall-screen');
        }

    } else {
        showScreen('welcome-screen');
    }
}
