const createCheckoutSession = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

const paymentWebhook = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

module.exports = {
    createCheckoutSession,
    paymentWebhook,
};
