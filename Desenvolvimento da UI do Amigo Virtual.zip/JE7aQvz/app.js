import { navigateTo } from './router.js';
import { initializeUI } from './ui_controller.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    initializeUI();

    const splashScreen = document.getElementById('splash-screen');
    
    setTimeout(() => {
        splashScreen.classList.add('hidden');
        
        const session = localStorage.getItem('amigo_virtual_session');
        if (session) {


            navigateTo('chat-screen');
        } else {
            navigateTo('login-screen');
        }

    }, 2000); 
});
