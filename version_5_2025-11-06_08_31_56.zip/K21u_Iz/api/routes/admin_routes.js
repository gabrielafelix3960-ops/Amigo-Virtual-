const express = require('express');
const router = express.Router();
const {
    loginAdmin,
    getDashboardMetrics,
    getAllUsers,
    getUserById,
    updateUserStatus,
    getUserConversations
} = require('../controllers/admin_controller.js');
const { protect, admin } = require('../middleware/auth_middleware.js');

router.post('/login', loginAdmin);

router.get('/metrics', protect, admin, getDashboardMetrics);

router.get('/users', protect, admin, getAllUsers);
router.get('/users/:userId', protect, admin, getUserById);
router.put('/users/:userId/status', protect, admin, updateUserStatus);
router.get('/users/:userId/conversations', protect, admin, getUserConversations);

module.exports = router;
