import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface ProfileScreenProps {
  user: any;
  onComplete: (profileData: any) => void;
  onSkip: () => void;
  loading: boolean;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onComplete,
  onSkip,
  loading
}) => {
  // Basic Info
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [profession, setProfession] = useState('');
  
  // Work/Study Schedule
  const [workDays, setWorkDays] = useState<string[]>([]);
  const [workStartTime, setWorkStartTime] = useState('09:00');
  const [workEndTime, setWorkEndTime] = useState('17:00');
  const [studyDays, setStudyDays] = useState<string[]>([]);
  const [studySchedule, setStudySchedule] = useState('');
  
  // Health & Routine
  const [takesMedication, setTakesMedication] = useState(false);
  const [medicationTimes, setMedicationTimes] = useState('');
  const [medicationNames, setMedicationNames] = useState('');
  const [exerciseRoutine, setExerciseRoutine] = useState('');
  const [exerciseDays, setExerciseDays] = useState<string[]>([]);
  
  // Lifestyle
  const [hobbies, setHobbies] = useState('');
  const [favoriteActivities, setFavoriteActivities] = useState('');
  const [livingSituation, setLivingSituation] = useState('');
  const [pets, setPets] = useState('');
  
  // Daily Routine
  const [wakeUpTime, setWakeUpTime] = useState('07:00');
  const [sleepTime, setSleepTime] = useState('23:00');
  
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const days = [
    { key: 'monday', label: 'Segunda' },
    { key: 'tuesday', label: 'Terça' },
    { key: 'wednesday', label: 'Quarta' },
    { key: 'thursday', label: 'Quinta' },
    { key: 'friday', label: 'Sexta' },
    { key: 'saturday', label: 'Sábado' },
    { key: 'sunday', label: 'Domingo' },
  ];

  const professions = [
    { key: 'student', label: 'Estudante' },
    { key: 'worker', label: 'Trabalho' },
    { key: 'retired', label: 'Aposentado(a)' },
    { key: 'unemployed', label: 'Desempregado(a)' },
    { key: 'other', label: 'Outro' },
  ];

  const livingSituations = [
    { key: 'alone', label: 'Sozinho(a)' },
    { key: 'family', label: 'Com família' },
    { key: 'roommates', label: 'Com colegas' },
    { key: 'couple', label: 'Com parceiro(a)' },
  ];

  const toggleDay = (dayKey: string, isWork: boolean) => {
    if (isWork) {
      setWorkDays(prev => 
        prev.includes(dayKey) 
          ? prev.filter(d => d !== dayKey)
          : [...prev, dayKey]
      );
    } else {
      setExerciseDays(prev => 
        prev.includes(dayKey) 
          ? prev.filter(d => d !== dayKey)
          : [...prev, dayKey]
      );
    }
  };

  const handleSubmit = () => {
    if (!name.trim()) {
      Alert.alert('Erro', 'Por favor, digite seu nome');
      return;
    }

    const profileData = {
      name: name.trim(),
      age: parseInt(age) || 25,
      profession,
      work_days: workDays,
      work_start_time: workStartTime,
      work_end_time: workEndTime,
      study_days: studyDays,
      study_schedule: studySchedule.trim(),
      takes_medication: takesMedication,
      medication_times: medicationTimes.split(',').map(t => t.trim()).filter(t => t),
      medication_names: medicationNames.split(',').map(n => n.trim()).filter(n => n),
      exercise_routine: exerciseRoutine.trim(),
      exercise_days: exerciseDays,
      hobbies: hobbies.split(',').map(h => h.trim()).filter(h => h),
      favorite_activities: favoriteActivities.split(',').map(a => a.trim()).filter(a => a),
      living_situation: livingSituation,
      pets: pets.split(',').map(p => p.trim()).filter(p => p),
      wake_up_time: wakeUpTime,
      sleep_time: sleepTime,
    };

    onComplete(profileData);
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <View>
            <Text style={styles.stepTitle}>Informações Básicas</Text>
            
            <Text style={styles.label}>Como você gostaria de ser chamado? *</Text>
            <TextInput
              style={styles.input}
              placeholder="Seu nome..."
              value={name}
              onChangeText={setName}
              placeholderTextColor="#666"
            />

            <Text style={styles.label}>Idade</Text>
            <TextInput
              style={styles.input}
              placeholder="Ex: 25"
              value={age}
              onChangeText={setAge}
              keyboardType="numeric"
              placeholderTextColor="#666"
            />

            <Text style={styles.label}>Situação Atual</Text>
            <View style={styles.buttonGroup}>
              {professions.map((prof) => (
                <TouchableOpacity
                  key={prof.key}
                  style={[
                    styles.optionButton,
                    profession === prof.key && styles.optionButtonSelected
                  ]}
                  onPress={() => setProfession(prof.key)}
                >
                  <Text style={[
                    styles.optionButtonText,
                    profession === prof.key && styles.optionButtonTextSelected
                  ]}>
                    {prof.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.label}>Situação de Moradia</Text>
            <View style={styles.buttonGroup}>
              {livingSituations.map((living) => (
                <TouchableOpacity
                  key={living.key}
                  style={[
                    styles.optionButton,
                    livingSituation === living.key && styles.optionButtonSelected
                  ]}
                  onPress={() => setLivingSituation(living.key)}
                >
                  <Text style={[
                    styles.optionButtonText,
                    livingSituation === living.key && styles.optionButtonTextSelected
                  ]}>
                    {living.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );

      case 2:
        return (
          <View>
            <Text style={styles.stepTitle}>Rotina de Trabalho/Estudo</Text>
            
            {(profession === 'worker' || profession === 'student') && (
              <>
                <Text style={styles.label}>
                  Dias da semana que você {profession === 'worker' ? 'trabalha' : 'estuda'}:
                </Text>
                <View style={styles.daysContainer}>
                  {days.map((day) => (
                    <TouchableOpacity
                      key={day.key}
                      style={[
                        styles.dayButton,
                        (profession === 'worker' ? workDays : studyDays).includes(day.key) && styles.dayButtonSelected
                      ]}
                      onPress={() => {
                        if (profession === 'worker') {
                          toggleDay(day.key, true);
                        } else {
                          setStudyDays(prev => 
                            prev.includes(day.key) 
                              ? prev.filter(d => d !== day.key)
                              : [...prev, day.key]
                          );
                        }
                      }}
                    >
                      <Text style={[
                        styles.dayButtonText,
                        (profession === 'worker' ? workDays : studyDays).includes(day.key) && styles.dayButtonTextSelected
                      ]}>
                        {day.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {profession === 'worker' && (
                  <>
                    <Text style={styles.label}>Horário de Trabalho</Text>
                    <View style={styles.timeContainer}>
                      <TextInput
                        style={[styles.input, styles.timeInput]}
                        placeholder="09:00"
                        value={workStartTime}
                        onChangeText={setWorkStartTime}
                        placeholderTextColor="#666"
                      />
                      <Text style={styles.timeLabel}>às</Text>
                      <TextInput
                        style={[styles.input, styles.timeInput]}
                        placeholder="17:00"
                        value={workEndTime}
                        onChangeText={setWorkEndTime}
                        placeholderTextColor="#666"
                      />
                    </View>
                  </>
                )}

                {profession === 'student' && (
                  <>
                    <Text style={styles.label}>Detalhes dos Estudos</Text>
                    <TextInput
                      style={[styles.input, { height: 80 }]}
                      placeholder="Ex: Faculdade de Engenharia, aulas das 19h às 22h..."
                      value={studySchedule}
                      onChangeText={setStudySchedule}
                      multiline
                      placeholderTextColor="#666"
                    />
                  </>
                )}
              </>
            )}

            <Text style={styles.label}>Horário de Acordar</Text>
            <TextInput
              style={styles.input}
              placeholder="07:00"
              value={wakeUpTime}
              onChangeText={setWakeUpTime}
              placeholderTextColor="#666"
            />

            <Text style={styles.label}>Horário de Dormir</Text>
            <TextInput
              style={styles.input}
              placeholder="23:00"
              value={sleepTime}
              onChangeText={setSleepTime}
              placeholderTextColor="#666"
            />
          </View>
        );

      case 3:
        return (
          <View>
            <Text style={styles.stepTitle}>Saúde e Exercícios</Text>
            
            <TouchableOpacity
              style={styles.checkboxContainer}
              onPress={() => setTakesMedication(!takesMedication)}
            >
              <Ionicons 
                name={takesMedication ? "checkbox" : "square-outline"} 
                size={24} 
                color="#E91E63" 
              />
              <Text style={styles.checkboxText}>Tomo medicamentos regularmente</Text>
            </TouchableOpacity>

            {takesMedication && (
              <>
                <Text style={styles.label}>Horários dos Medicamentos</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Ex: 08:00, 14:00, 20:00"
                  value={medicationTimes}
                  onChangeText={setMedicationTimes}
                  placeholderTextColor="#666"
                />

                <Text style={styles.label}>Nomes dos Medicamentos</Text>
                <TextInput
                  style={[styles.input, { height: 60 }]}
                  placeholder="Ex: Vitamina C, Pressão arterial..."
                  value={medicationNames}
                  onChangeText={setMedicationNames}
                  multiline
                  placeholderTextColor="#666"
                />
              </>
            )}

            <Text style={styles.label}>Rotina de Exercícios</Text>
            <TextInput
              style={styles.input}
              placeholder="Ex: Caminhada, Academia, Yoga..."
              value={exerciseRoutine}
              onChangeText={setExerciseRoutine}
              placeholderTextColor="#666"
            />

            {exerciseRoutine && (
              <>
                <Text style={styles.label}>Dias de Exercício</Text>
                <View style={styles.daysContainer}>
                  {days.map((day) => (
                    <TouchableOpacity
                      key={day.key}
                      style={[
                        styles.dayButton,
                        exerciseDays.includes(day.key) && styles.dayButtonSelected
                      ]}
                      onPress={() => toggleDay(day.key, false)}
                    >
                      <Text style={[
                        styles.dayButtonText,
                        exerciseDays.includes(day.key) && styles.dayButtonTextSelected
                      ]}>
                        {day.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </>
            )}
          </View>
        );

      case 4:
        return (
          <View>
            <Text style={styles.stepTitle}>Interesses e Hobbies</Text>
            
            <Text style={styles.label}>Hobbies e Interesses</Text>
            <TextInput
              style={[styles.input, { height: 80 }]}
              placeholder="Ex: música, filmes, leitura, culinária, viagens..."
              value={hobbies}
              onChangeText={setHobbies}
              multiline
              placeholderTextColor="#666"
            />

            <Text style={styles.label}>Atividades Favoritas</Text>
            <TextInput
              style={[styles.input, { height: 80 }]}
              placeholder="Ex: assistir Netflix, sair com amigos, jogar videogame..."
              value={favoriteActivities}
              onChangeText={setFavoriteActivities}
              multiline
              placeholderTextColor="#666"
            />

            <Text style={styles.label}>Animais de Estimação</Text>
            <TextInput
              style={styles.input}
              placeholder="Ex: cachorro, gato, pássaro... (deixe vazio se não tiver)"
              value={pets}
              onChangeText={setPets}
              placeholderTextColor="#666"
            />
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Configure seu Perfil</Text>
          <Text style={styles.subtitle}>
            Este questionário ajuda seu amigo virtual a conhecer sua rotina e personalidade para oferecer conversas mais naturais e ajuda personalizada
          </Text>
          <Text style={styles.benefitsText}>
            💬 Conversas contextuais sobre seu dia
            📚 Ajuda com trabalhos e pesquisas
            🏠 Suporte em tarefas domésticas
            ⏰ Lembretes de rotina importantes
            🤝 Um verdadeiro companheiro digital
          </Text>
          
          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${(currentStep / totalSteps) * 100}%` }
                ]} 
              />
            </View>
            <Text style={styles.progressText}>{currentStep} de {totalSteps}</Text>
          </View>
        </View>

        <ScrollView style={styles.content}>
          {renderStep()}
        </ScrollView>

        <View style={styles.buttonContainer}>
          {currentStep > 1 && (
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => setCurrentStep(currentStep - 1)}
            >
              <Text style={styles.backButtonText}>Voltar</Text>
            </TouchableOpacity>
          )}

          {currentStep < totalSteps ? (
            <TouchableOpacity
              style={styles.nextButton}
              onPress={() => setCurrentStep(currentStep + 1)}
            >
              <Text style={styles.nextButtonText}>Próximo</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.nextButton, loading && styles.buttonDisabled]}
              onPress={handleSubmit}
              disabled={loading || !name.trim()}
            >
              <Text style={styles.nextButtonText}>
                {loading ? 'Salvando...' : 'Concluir'}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity style={styles.skipButton} onPress={onSkip}>
          <Text style={styles.skipButtonText}>Pular por agora (usuários existentes)</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  flex: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 22,
  },
  benefitsText: {
    fontSize: 14,
    color: '#E91E63',
    textAlign: 'left',
    marginTop: 16,
    backgroundColor: '#fce4ec',
    padding: 12,
    borderRadius: 8,
    lineHeight: 20,
  },
  progressContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 6,
    backgroundColor: '#e1e5e9',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#E91E63',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  stepTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
    marginTop: 16,
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#e1e5e9',
  },
  buttonGroup: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  optionButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#E91E63',
    backgroundColor: 'white',
  },
  optionButtonSelected: {
    backgroundColor: '#E91E63',
  },
  optionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#E91E63',
  },
  optionButtonTextSelected: {
    color: 'white',
  },
  daysContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  dayButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: '#E91E63',
    backgroundColor: 'white',
  },
  dayButtonSelected: {
    backgroundColor: '#E91E63',
  },
  dayButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#E91E63',
  },
  dayButtonTextSelected: {
    color: 'white',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  timeInput: {
    flex: 1,
    marginBottom: 0,
  },
  timeLabel: {
    fontSize: 16,
    color: '#666',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  checkboxText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  backButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E91E63',
    backgroundColor: 'white',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E91E63',
  },
  nextButton: {
    flex: 2,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#E91E63',
    alignItems: 'center',
  },
  nextButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  skipButton: {
    alignItems: 'center',
    paddingBottom: 20,
  },
  skipButtonText: {
    fontSize: 14,
    color: '#666',
    textDecorationLine: 'underline',
  },
});