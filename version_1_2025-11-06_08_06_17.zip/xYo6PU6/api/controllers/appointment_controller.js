const Appointment = require('../models/appointment_model.js');

const getAppointments = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

const createAppointment = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

const updateAppointment = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

const deleteAppointment = async (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint not implemented yet.' });
};

module.exports = {
    getAppointments,
    createAppointment,
    updateAppointment,
    deleteAppointment,
};
