const mongoose = require('mongoose');

const conversationSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
    },
    messageText: {
        type: String,
        required: true,
    },
    sender: {
        type: String,
        required: true,
        enum: ['user', 'ai'],
    },
    emotionAnalysisTag: {
        type: String,
    },
}, {
    timestamps: true,
});

const Conversation = mongoose.model('Conversation', conversationSchema);
module.exports = Conversation;
