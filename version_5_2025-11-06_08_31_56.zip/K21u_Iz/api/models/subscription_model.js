const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
        unique: true,
    },
    plan: {
        type: String,
        enum: ['monthly', 'annual', 'none'],
        default: 'none',
    },
    status: {
        type: String,
        enum: ['trial', 'active', 'cancelled', 'expired'],
        default: 'trial',
    },
    trialEndsAt: {
        type: Date,
    },
    currentPeriodEndsAt: {
        type: Date,
    },
    stripeCustomerId: {
        type: String,
    },
    paypalPayerId: {
        type: String,
    }
}, {
    timestamps: true,
});

const Subscription = mongoose.model('Subscription', subscriptionSchema);
module.exports = Subscription;
