import { saveQuestionnaire, saveFriendConfig, createAppointment, deleteAppointment } from './api_service.js';

let currentQuestionStep = 1;
const totalQuestionSteps = 3;

export function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.add('hidden');
    });
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
        targetScreen.classList.remove('hidden');
    }
}

export function initializeUI() {
    setupQuestionnaireNavigation();
    setupFriendSelectionUI();
    initCalendarScreen();
}

function setupQuestionnaireNavigation() {
    document.querySelectorAll('.question-next-btn').forEach(button => {
        button.addEventListener('click', () => {
            const currentStepEl = document.getElementById(`question-step-${currentQuestionStep}`);
            if (currentStepEl) currentStepEl.classList.add('hidden');
            
            currentQuestionStep++;
            
            if (currentQuestionStep <= totalQuestionSteps) {
                const nextStepEl = document.getElementById(`question-step-${currentQuestionStep}`);
                if (nextStepEl) nextStepEl.classList.remove('hidden');
            }
        });
    });
}

export function setupQuestionnaire() {
    const data = {};
    document.querySelectorAll('#questionnaire-screen input').forEach(input => {
        if (input.value) {
            data[input.dataset.field] = input.value;
        }
    });
    saveQuestionnaire(data);
}

function setupFriendSelectionUI() {
    const genderChoices = document.querySelectorAll('.gender-choice');
    genderChoices.forEach(choice => {
        choice.addEventListener('click', () => {
            genderChoices.forEach(c => c.querySelector('img').classList.remove('selected'));
            choice.querySelector('img').classList.add('selected');
            const gender = choice.dataset.gender;
            
            const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
            friendConfig.gender = gender;
            friendConfig.avatar = choice.querySelector('img').src;
            localStorage.setItem('friendConfig', JSON.stringify(friendConfig));

            document.getElementById('gender-selection').classList.add('hidden');
            document.getElementById('personality-selection').classList.remove('hidden');
        });
    });

    const personalities = ['Alegre', 'Divertido', 'Sério', 'Leal', 'Carinhoso', 'Atencioso', 'Extrovertido', 'Engraçado', 'Profissional'];
    const personalityList = document.getElementById('personality-list');
    personalities.forEach(p => {
        const option = document.createElement('div');
        option.textContent = p;
        option.dataset.personality = p.toLowerCase();
        option.className = 'personality-option p-4 bg-gray-100 rounded-lg text-center font-medium text-gray-700 ring-1 ring-gray-200';
        option.addEventListener('click', () => {
            option.classList.toggle('selected');
            option.classList.toggle('bg-indigo-100');
            option.classList.toggle('text-indigo-700');
        });
        personalityList.appendChild(option);
    });
}

export function setupFriendSelection() {
    const selectedPersonalities = [];
    document.querySelectorAll('.personality-option.selected').forEach(p => {
        selectedPersonalities.push(p.dataset.personality);
    });
    
    const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
    friendConfig.personalities = selectedPersonalities;
    saveFriendConfig(friendConfig);
}

export function renderMessage(message, sender) {
    const chatLog = document.getElementById('chat-log');
    const messageEl = document.createElement('div');
    messageEl.textContent = message;
    messageEl.className = `chat-bubble ${sender}`;
    chatLog.appendChild(messageEl);
    chatLog.scrollTop = chatLog.scrollHeight;
}

export function toggleTypingIndicator(show) {
    const indicator = document.getElementById('typing-indicator');
    if (show) {
        indicator.classList.remove('hidden');
    } else {
        indicator.classList.add('hidden');
    }
}


function initCalendarScreen() {
    const form = document.getElementById('add-appointment-form');
    const showFormBtn = document.getElementById('show-add-appointment-form');
    const cancelBtn = document.getElementById('cancel-add-appointment');
    const listContainer = document.getElementById('appointments-list');

    showFormBtn.addEventListener('click', () => {
        form.classList.remove('hidden');
        showFormBtn.classList.add('hidden');
    });

    cancelBtn.addEventListener('click', () => {
        form.classList.add('hidden');
        form.reset();
        showFormBtn.classList.remove('hidden');
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const appointmentData = {
            title: document.getElementById('appointment-title').value,
            date: document.getElementById('appointment-date').value,
            time: document.getElementById('appointment-time').value,
        };

        try {
            const newAppointment = await createAppointment(appointmentData);
            const currentAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
            renderAppointments(currentAppointments);
            form.reset();
            form.classList.add('hidden');
            showFormBtn.classList.remove('hidden');
        } catch (error) {
            alert('Erro ao criar compromisso: ' + error.message);
        }
    });

    listContainer.addEventListener('click', async (e) => {
        if (e.target.closest('.delete-appointment-btn')) {
            const button = e.target.closest('.delete-appointment-btn');
            const id = button.dataset.id;
            if (confirm('Tem certeza que deseja apagar este compromisso?')) {
                try {
                    await deleteAppointment(id);
                    const updatedAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
                    renderAppointments(updatedAppointments.filter(a => a._id !== id));
                } catch (error) {
                    alert('Erro ao apagar compromisso: ' + error.message);
                }
            }
        }
    });
}

export function renderAppointments(appointments) {
    const listContainer = document.getElementById('appointments-list');
    listContainer.innerHTML = '';
    
    const sortedAppointments = appointments.sort((a,b) => new Date(a.date + 'T' + a.time) - new Date(b.date + 'T' + b.time));

    if (sortedAppointments.length === 0) {
        listContainer.innerHTML = '<p class="text-center text-gray-500 mt-10">Você ainda não tem compromissos agendados.</p>';
        return;
    }

    sortedAppointments.forEach(app => {
        const appDate = new Date(app.date);
        const formattedDate = appDate.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', timeZone: 'UTC' });
        
        const element = document.createElement('div');
        element.className = 'bg-white p-4 rounded-lg shadow flex items-center justify-between';
        element.innerHTML = `
            <div>
                <p class="font-bold text-gray-800">${app.title}</p>
                <p class="text-sm text-gray-600">${formattedDate} às ${app.time}</p>
            </div>
            <button class="delete-appointment-btn text-red-500 hover:text-red-700" data-id="${app._id}">
                <i data-lucide="trash-2" class="w-5 h-5 pointer-events-none"></i>
            </button>
        `;
        listContainer.appendChild(element);
    });
    lucide.createIcons();
}
