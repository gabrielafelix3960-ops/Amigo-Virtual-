const AUTH_TOKEN = 'YOUR_JWT_TOKEN_HERE';

document.addEventListener('DOMContentLoaded', () => {
    const planButtons = document.querySelectorAll('.plan-button');
    const paymentPlaceholder = document.getElementById('payment-placeholder');
    const errorMessage = document.getElementById('error-message');

    if (AUTH_TOKEN === 'YOUR_JWT_TOKEN_HERE') {
        errorMessage.innerHTML = `<p class="font-semibold">Erro de Configuração:</p><p>Token de autenticação não configurado. Por favor, edite o arquivo subscription.js e substitua 'YOUR_JWT_TOKEN_HERE' por um token de usuário válido para testar a funcionalidade.</p>`;
        errorMessage.classList.remove('hidden');
        planButtons.forEach(button => button.disabled = true);
        return;
    }

    planButtons.forEach(button => {
        button.addEventListener('click', async (e) => {
            const plan = e.target.dataset.plan;
            
            paymentPlaceholder.classList.remove('hidden');
            errorMessage.classList.add('hidden');
            
            try {
                const response = await fetch('/api/payments/create-session', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${AUTH_TOKEN}`
                    },
                    body: JSON.stringify({ plan })
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.success) {
                    window.location.href = 'payment_success.html';
                } else {
                    throw new Error(data.message || 'Failed to process subscription.');
                }

            } catch (error) {
                console.error('Subscription error:', error);
                errorMessage.innerHTML = `<p>${error.message}</p>`;
                errorMessage.classList.remove('hidden');
                paymentPlaceholder.classList.add('hidden');
                setTimeout(() => {
                    window.location.href = 'payment_cancel.html';
                }, 2000);
            }
        });
    });
});
