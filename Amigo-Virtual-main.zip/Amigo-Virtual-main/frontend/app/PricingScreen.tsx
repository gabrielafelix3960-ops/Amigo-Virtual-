import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface PricingScreenProps {
  user: any;
  currentCurrency: string;
  onBack: () => void;
  onSubscribe: (plan: string) => void;
}

export const PricingScreen: React.FC<PricingScreenProps> = ({
  user,
  currentCurrency,
  onBack,
  onSubscribe
}) => {
  const [pricing, setPricing] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Preços por moeda (valores que definimos antes)
  const globalPricing = {
    "BRL": { monthly: 39.90, annual: 299.90, symbol: "R$" },
    "USD": { monthly: 7.99, annual: 59.99, symbol: "$" },
    "EUR": { monthly: 7.49, annual: 54.99, symbol: "€" },
    "GBP": { monthly: 6.49, annual: 47.99, symbol: "£" },
    "JPY": { monthly: 1180, annual: 8900, symbol: "¥" },
    "CNY": { monthly: 58, annual: 428, symbol: "¥" },
    "MXN": { monthly: 159, annual: 1199, symbol: "$" },
    "ARS": { monthly: 7999, annual: 59999, symbol: "$" },
  };

  useEffect(() => {
    const currentPricing = globalPricing[currentCurrency as keyof typeof globalPricing] || globalPricing.BRL;
    setPricing(currentPricing);
    setLoading(false);
  }, [currentCurrency]);

  const calculateDiscount = () => {
    if (!pricing) return 0;
    return Math.round((1 - pricing.annual / (pricing.monthly * 12)) * 100);
  };

  const handleSubscribe = (planType: 'monthly' | 'annual') => {
    Alert.alert(
      'Assinar Premium',
      `Você será redirecionado para o Google Play para completar a assinatura ${planType === 'monthly' ? 'mensal' : 'anual'}.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Continuar', onPress: () => onSubscribe(planType) }
      ]
    );
  };

  if (loading || !pricing) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.loadingText}>Carregando preços...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={30} color="#E91E63" />
        </TouchableOpacity>
        <Text style={styles.title}>Planos Premium</Text>
      </View>

      <ScrollView style={styles.content}>
        {/* Trial Info */}
        <View style={styles.trialCard}>
          <Ionicons name="time" size={24} color="#FF9800" />
          <Text style={styles.trialTitle}>Período de Teste</Text>
          <Text style={styles.trialText}>
            Você tem 7 dias de teste gratuito com 10 conversas por dia. 
            Depois disso, precisa assinar para continuar.
          </Text>
        </View>

        {/* Premium Benefits */}
        <View style={styles.benefitsCard}>
          <Text style={styles.benefitsTitle}>🎉 Com o Premium você terá:</Text>
          
          <View style={styles.benefitItem}>
            <Ionicons name="infinite" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Conversas ilimitadas</Text>
          </View>
          
          <View style={styles.benefitItem}>
            <Ionicons name="person" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Avatares personalizados</Text>
          </View>
          
          <View style={styles.benefitItem}>
            <Ionicons name="brain" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Memória avançada</Text>
          </View>
          
          <View style={styles.benefitItem}>
            <Ionicons name="heart" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Múltiplos amigos virtuais</Text>
          </View>
          
          <View style={styles.benefitItem}>
            <Ionicons name="globe" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Suporte em vários idiomas</Text>
          </View>
          
          <View style={styles.benefitItem}>
            <Ionicons name="headset" size={20} color="#4CAF50" />
            <Text style={styles.benefitText}>Suporte prioritário</Text>
          </View>
        </View>

        {/* Pricing Plans */}
        <Text style={styles.sectionTitle}>Escolha seu Plano</Text>

        {/* Annual Plan - Recommended */}
        <TouchableOpacity 
          style={[styles.planCard, styles.recommendedPlan]}
          onPress={() => handleSubscribe('annual')}
        >
          <View style={styles.recommendedBadge}>
            <Text style={styles.recommendedText}>MAIS POPULAR</Text>
          </View>
          
          <Text style={styles.planTitle}>Plano Anual</Text>
          <Text style={styles.planPrice}>
            {pricing.symbol}{pricing.annual.toFixed(2)}
          </Text>
          <Text style={styles.planPeriod}>por ano</Text>
          
          <View style={styles.savingsContainer}>
            <Text style={styles.savingsText}>
              Economize {calculateDiscount()}%
            </Text>
            <Text style={styles.monthlyEquivalent}>
              ({pricing.symbol}{(pricing.annual / 12).toFixed(2)}/mês)
            </Text>
          </View>

          <View style={styles.planFeatures}>
            <Text style={styles.featureText}>✅ Tudo do Premium</Text>
            <Text style={styles.featureText}>🎁 2 meses grátis</Text>
            <Text style={styles.featureText}>💰 Melhor custo-benefício</Text>
          </View>
        </TouchableOpacity>

        {/* Monthly Plan */}
        <TouchableOpacity 
          style={styles.planCard}
          onPress={() => handleSubscribe('monthly')}
        >
          <Text style={styles.planTitle}>Plano Mensal</Text>
          <Text style={styles.planPrice}>
            {pricing.symbol}{pricing.monthly.toFixed(2)}
          </Text>
          <Text style={styles.planPeriod}>por mês</Text>
          
          <View style={styles.planFeatures}>
            <Text style={styles.featureText}>✅ Tudo do Premium</Text>
            <Text style={styles.featureText}>🔄 Flexibilidade mensal</Text>
            <Text style={styles.featureText}>⚡ Acesso imediato</Text>
          </View>
        </TouchableOpacity>

        {/* Payment Info */}
        <View style={styles.paymentInfo}>
          <Text style={styles.paymentTitle}>💳 Informações de Pagamento</Text>
          <Text style={styles.paymentText}>
            • Pagamento processado pelo Google Play{'\n'}
            • Renovação automática{'\n'}
            • Cancele a qualquer momento{'\n'}
            • Política de reembolso do Google Play
          </Text>
        </View>

        {/* Restore Purchases */}
        <TouchableOpacity style={styles.restoreButton}>
          <Text style={styles.restoreText}>Restaurar Compras</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginLeft: 15,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  loadingText: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
    color: '#666',
  },
  trialCard: {
    backgroundColor: '#FFF3E0',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800',
  },
  trialTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F57C00',
    marginTop: 8,
    marginBottom: 8,
  },
  trialText: {
    fontSize: 14,
    color: '#795548',
    textAlign: 'center',
    lineHeight: 20,
  },
  benefitsCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  benefitsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  benefitText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 12,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  planCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  recommendedPlan: {
    borderColor: '#E91E63',
    backgroundColor: '#fce4ec',
  },
  recommendedBadge: {
    position: 'absolute',
    top: -8,
    right: 20,
    backgroundColor: '#E91E63',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  recommendedText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  planTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  planPrice: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E91E63',
    textAlign: 'center',
  },
  planPeriod: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },
  savingsContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  savingsText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    backgroundColor: '#E8F5E8',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  monthlyEquivalent: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  planFeatures: {
    alignItems: 'center',
  },
  featureText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
    textAlign: 'center',
  },
  paymentInfo: {
    backgroundColor: '#E3F2FD',
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    marginBottom: 20,
  },
  paymentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1976D2',
    marginBottom: 8,
  },
  paymentText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
  },
  restoreButton: {
    alignItems: 'center',
    paddingVertical: 12,
    marginBottom: 20,
  },
  restoreText: {
    fontSize: 16,
    color: '#E91E63',
    textDecorationLine: 'underline',
  },
});