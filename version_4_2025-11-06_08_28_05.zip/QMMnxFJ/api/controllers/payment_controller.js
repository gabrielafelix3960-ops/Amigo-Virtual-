const Subscription = require('../models/subscription_model');
const User = require('../models/user_model');

const createCheckoutSession = async (req, res) => {
    const { plan } = req.body;
    const userId = req.user.id;

    if (!plan || (plan !== 'monthly' && plan !== 'annual')) {
        return res.status(400).json({ success: false, message: 'Invalid plan selected.' });
    }

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        const now = new Date();
        let endDate;

        if (plan === 'monthly') {
            endDate = new Date(now.setMonth(now.getMonth() + 1));
        } else {
            endDate = new Date(now.setFullYear(now.getFullYear() + 1));
        }

        const subscription = await Subscription.findOneAndUpdate(
            { user: userId },
            {
                plan: plan,
                status: 'active',
                currentPeriodEndsAt: endDate,
            },
            { new: true, upsert: true }
        );

        res.status(200).json({
            success: true,
            message: `Subscription for ${plan} plan activated successfully.`,
            sessionId: `mock_session_${Date.now()}`,
            subscription,
        });

    } catch (error) {
        console.error('Error creating checkout session:', error);
        res.status(500).json({ success: false, message: 'Server error while creating session.' });
    }
};

const paymentWebhook = async (req, res) => {
    res.status(501).json({ success: false, message: 'Webhook endpoint not implemented. This would be used by payment providers like Stripe to confirm payment success.' });
};

module.exports = {
    createCheckoutSession,
    paymentWebhook,
};
