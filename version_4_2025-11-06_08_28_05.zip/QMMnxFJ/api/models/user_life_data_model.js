const mongoose = require('mongoose');

const userLifeDataSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
        unique: true,
    },
    hobbies: [String],
    pets: [{
        animal: String,
        name: String,
    }],
    children: [{
        name: String,
    }],
    maritalStatus: {
        type: String,
        enum: ['single', 'in a relationship', 'married', 'divorced', 'widowed'],
    },
    work: {
        occupation: String,
        company: String,
    },
    studies: {
        field: String,
        year: Number,
        subjects: [String],
    },
    dailyMedication: [{
        name: String,
        time: String,
    }],
    gym: {
        name: String,
        location: String,
        frequency: String,
    }
}, {
    timestamps: true,
});

const UserLifeData = mongoose.model('UserLifeData', userLifeDataSchema);
module.exports = UserLifeData;
