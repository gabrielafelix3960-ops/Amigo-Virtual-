const Appointment = require('../api/models/appointment_model');

const checkUpcomingAppointments = async () => {
    console.log('Checking for upcoming appointments...');
    const now = new Date();
    
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const endOfToday = new Date();
    endOfToday.setHours(23, 59, 59, 999);

    try {
        const potentialAppointments = await Appointment.find({
            date: { $gte: startOfToday, $lte: endOfToday },
            reminderSent: false
        });

        for (const appt of potentialAppointments) {
            const dateStr = appt.date.toISOString().substring(0, 10);
            const timeStr = appt.time;
            const appointmentDateTime = new Date(`${dateStr}T${timeStr}:00`);

            const notificationWindow = new Date(now.getTime() + 5 * 60 * 1000);

            if (appointmentDateTime > now && appointmentDateTime <= notificationWindow) {
                console.log(`SIMULATING NOTIFICATION: Sending reminder for appointment "${appt.title}" to user ${appt.user}.`);

                appt.reminderSent = true;
                await appt.save();
            }
        }

    } catch (error) {
        console.error('Error checking for upcoming appointments:', error);
    }
};

const startNotificationScheduler = () => {
    console.log('Notification scheduler started. Will check for appointments every minute.');
    checkUpcomingAppointments(); 
    setInterval(checkUpcomingAppointments, 60 * 1000);
};

module.exports = { startNotificationScheduler };
