const User = require('../models/user_model.js');
const Subscription = require('../models/subscription_model.js');
const Appointment = require('../models/appointment_model.js');
const Conversation = require('../models/conversation_model.js');
const VirtualFriendProfile = require('../models/virtual_friend_profile_model.js');
const jwt = require('jsonwebtoken');

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d',
    });
};

const loginAdmin = async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });

        if (user && (await user.matchPassword(password))) {
            if (user.isAdmin) {
                res.json({
                    _id: user._id,
                    email: user.email,
                    isAdmin: user.isAdmin,
                    token: generateToken(user._id),
                });
            } else {
                res.status(403).json({ success: false, error: 'Not authorized as an admin' });
            }
        } else {
            res.status(401).json({ success: false, error: 'Invalid email or password' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const getDashboardMetrics = async (req, res) => {
    try {
        const totalUsers = await User.countDocuments({ isAdmin: false });
        
        const activeSubscriptions = await Subscription.aggregate([
            { $match: { status: 'active' } },
            { $group: { _id: '$plan', count: { $sum: 1 } } }
        ]);
        
        const subscribers = {
            totalActive: activeSubscriptions.reduce((acc, curr) => acc + curr.count, 0),
            monthly: activeSubscriptions.find(s => s._id === 'monthly')?.count || 0,
            annual: activeSubscriptions.find(s => s._id === 'annual')?.count || 0,
        };
        
        const totalAppointments = await Appointment.countDocuments({});
        
        res.json({
            totalUsers,
            activeSubscribers: subscribers,
            totalAppointments
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const getAllUsers = async (req, res) => {
    try {
        const users = await User.aggregate([
            {
                $match: { isAdmin: false }
            },
            {
                $lookup: {
                    from: 'subscriptions',
                    localField: '_id',
                    foreignField: 'user',
                    as: 'subscriptionInfo'
                }
            },
            {
                $unwind: {
                    path: '$subscriptionInfo',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $project: {
                    _id: 1,
                    email: 1,
                    createdAt: 1,
                    subscriptionStatus: { $ifNull: ['$subscriptionInfo.status', 'none'] }
                }
            },
            {
                $sort: { createdAt: -1 }
            }
        ]);
        res.json(users);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).select('-password');
        if (user) {
            const subscription = await Subscription.findOne({ user: req.params.userId });
            const profile = await VirtualFriendProfile.findOne({ user: req.params.userId });
            
            res.json({
                user,
                subscription: subscription || null,
                profile: profile || null
            });
        } else {
            res.status(404).json({ success: false, error: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const updateUserStatus = async (req, res) => {
    const { status } = req.body;
    const allowedStatuses = ['trial', 'active', 'cancelled', 'expired'];
    
    if (!status || !allowedStatuses.includes(status)) {
        return res.status(400).json({ success: false, error: `Invalid status. Must be one of: ${allowedStatuses.join(', ')}` });
    }

    try {
        const subscription = await Subscription.findOne({ user: req.params.userId });
        
        if (subscription) {
            subscription.status = status;
            await subscription.save();
            res.json({ success: true, message: 'User subscription status updated successfully.', subscription });
        } else {
            res.status(404).json({ success: false, error: 'Subscription for user not found. Cannot update status.' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const getUserConversations = async (req, res) => {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const skip = (page - 1) * limit;

    try {
        const userExists = await User.findById(req.params.userId);
        if(!userExists) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        const conversations = await Conversation.find({ user: req.params.userId })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        const total = await Conversation.countDocuments({ user: req.params.userId });

        res.json({
            conversations,
            currentPage: page,
            totalPages: Math.ceil(total / limit),
            totalConversations: total
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

module.exports = { 
    loginAdmin,
    getDashboardMetrics,
    getAllUsers,
    getUserById,
    updateUserStatus,
    getUserConversations
};
