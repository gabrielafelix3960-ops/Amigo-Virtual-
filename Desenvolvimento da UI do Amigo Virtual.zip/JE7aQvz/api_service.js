import { getSystemPrompt } from './persona.js';

const OPENROUTER_API_KEY = "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";
const API_URL = "https://openrouter.ai/api/v1/chat/completions";

const api = {

    login: async (email, password) => {
        console.log(`Attempting login for: ${email}`);
        if (!email || !password) {
            throw new Error("Email and password are required.");
        }

        await new Promise(res => setTimeout(res, 500));



        if (password === 'password') { // Dummy check
            const mockUser = { id: '123', email: email };
            const mockToken = 'fake-jwt-token';
            return { user: mockUser, token: mockToken };
        } else {
            throw new Error("Invalid credentials.");
        }
    },


    register: async (email, password, currency, language) => {
        console.log(`Registering new user: ${email}`);
        if (!email || !password || !currency || !language) {
            throw new Error("All fields are required for registration.");
        }
        await new Promise(res => setTimeout(res, 500));
        
        const mockUser = { id: '124', email: email };
        const mockToken = 'new-fake-jwt-token';
        return { user: mockUser, token: mockToken };
    },

    sendMessageToAI: async (userMessage, history, friendProfile) => {
        const systemPrompt = getSystemPrompt(friendProfile);
        
        const messages = [
            { role: 'system', content: systemPrompt },

            ...history.map(msg => ({
                role: msg.sender === 'ai' ? 'assistant' : 'user',
                content: msg.text
            })),
            { role: 'user', content: userMessage }
        ];

        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: "deepseek/deepseek-chat-v3-0324:free",
                    messages: messages,
                })
            });

            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(`API error: ${response.status} ${response.statusText} - ${errorBody}`);
            }

            const data = await response.json();
            if (data.choices && data.choices.length > 0) {
                return data.choices[0].message.content;
            } else {
                throw new Error("No response from AI.");
            }
        } catch (error) {
            console.error("Error calling OpenRouter API:", error);
            throw error;
        }
    }
};

export { api };
