import { mockUsers, mockConversations } from './mock_data.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const loginScreen = document.getElementById('admin-login-screen');
    const adminPanel = document.getElementById('admin-panel');
    const loginForm = document.getElementById('admin-login-form');
    const logoutBtn = document.getElementById('admin-logout-btn');
    const loginError = document.getElementById('login-error');

    function showAdminPanel() {
        loginScreen.classList.add('hidden');
        adminPanel.classList.remove('hidden');
        adminPanel.classList.add('flex');
        populateDashboard();
        populateUserTable();
        populateConversationViewer();
    }

    function showLoginScreen() {
        adminPanel.classList.add('hidden');
        adminPanel.classList.remove('flex');
        loginScreen.classList.remove('hidden');
    }

    function handleLogin(event) {
        event.preventDefault();
        const user = document.getElementById('admin-user').value;
        const pass = document.getElementById('admin-password').value;

        if (user === 'admin' && pass === 'admin_password') {
            sessionStorage.setItem('adminAuthenticated', 'true');
            loginError.classList.add('hidden');
            showAdminPanel();
        } else {
            loginError.classList.remove('hidden');
        }
    }

    function handleLogout() {
        sessionStorage.removeItem('adminAuthenticated');
        showLoginScreen();
    }

    function populateDashboard() {
        const totalUsers = mockUsers.length;
        const activeUsers = mockUsers.filter(u => u.subscription.status === 'active' || u.subscription.status === 'trial').length;
        const activeSubs = mockUsers.filter(u => u.subscription.status === 'active').length;
        
        const monthlyRevenue = mockUsers.reduce((total, user) => {
            if (user.subscription.status === 'active') {
                if (user.subscription.plan === 'monthly') {
                    total += 10.50;
                } else if (user.subscription.plan === 'annual') {
                    total += 88.20 / 12;
                }
            }
            return total;
        }, 0);

        document.getElementById('metric-total-users').textContent = totalUsers;
        document.getElementById('metric-active-users').textContent = activeUsers;
        document.getElementById('metric-active-subs').textContent = activeSubs;
        document.getElementById('metric-mrr').textContent = `€${monthlyRevenue.toFixed(2)}`;
    }

    function getStatusBadge(status) {
        switch (status) {
            case 'active':
                return '<span class="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Ativo</span>';
            case 'trial':
                return '<span class="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Trial</span>';
            case 'expired':
                return '<span class="bg-yellow-100 text-yellow-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Expirado</span>';
            case 'suspended':
                return '<span class="bg-red-100 text-red-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Suspenso</span>';
            default:
                return `<span class="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">${status}</span>`;
        }
    }

    function populateUserTable() {
        const tableBody = document.getElementById('user-table-body');
        tableBody.innerHTML = '';
        mockUsers.forEach(user => {
            const row = document.createElement('tr');
            row.id = `user-row-${user.id}`;
            row.innerHTML = `
                <td class="font-medium">${user.email}</td>
                <td>${new Date(user.registeredAt).toLocaleDateString('pt-BR')}</td>
                <td class="status-cell">${getStatusBadge(user.subscription.status)}</td>
                <td class="space-x-2">
                    <button data-user-id="${user.id}" class="suspend-btn text-yellow-600 hover:text-yellow-900 font-semibold">Suspender</button>
                    <button data-user-id="${user.id}" class="reactivate-btn text-green-600 hover:text-green-900 font-semibold">Reativar</button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        document.querySelectorAll('.suspend-btn').forEach(btn => btn.addEventListener('click', (e) => {
            const userId = e.target.dataset.userId;
            const user = mockUsers.find(u => u.id == userId);
            user.subscription.status = 'suspended';
            const statusCell = document.querySelector(`#user-row-${userId} .status-cell`);
            statusCell.innerHTML = getStatusBadge('suspended');
            alert(`Usuário ${user.email} suspenso.`);
        }));

        document.querySelectorAll('.reactivate-btn').forEach(btn => btn.addEventListener('click', (e) => {
            const userId = e.target.dataset.userId;
            const user = mockUsers.find(u => u.id == userId);
            user.subscription.status = 'active'; 
            const statusCell = document.querySelector(`#user-row-${userId} .status-cell`);
            statusCell.innerHTML = getStatusBadge('active');
            alert(`Usuário ${user.email} reativado.`);
        }));
    }

    function populateConversationViewer() {
        const userSelect = document.getElementById('user-select-log');
        userSelect.innerHTML = '<option value="">Selecione...</option>';
        mockUsers.forEach(user => {
            const option = document.createElement('option');
            option.value = user.id;
            option.textContent = user.email;
            userSelect.appendChild(option);
        });

        userSelect.addEventListener('change', (e) => {
            const userId = e.target.value;
            displayUserConversation(userId);
        });
    }

    function displayUserConversation(userId) {
        const logViewer = document.getElementById('log-viewer');
        if (!userId) {
            logViewer.innerHTML = '<p class="text-gray-500">Selecione um usuário para ver as conversas.</p>';
            return;
        }

        const conversation = mockConversations[userId];
        if (!conversation || conversation.length === 0) {
            logViewer.innerHTML = '<p class="text-gray-500">Nenhuma conversa encontrada para este usuário.</p>';
            return;
        }

        logViewer.innerHTML = conversation.map(msg => {
            const isUser = msg.role === 'user';
            const bubbleClass = isUser ? 'bg-indigo-500 text-white self-end rounded-br-none' : 'bg-white text-gray-800 self-start rounded-bl-none';
            const containerClass = isUser ? 'flex justify-end' : 'flex justify-start';
            return `
                <div class="${containerClass}">
                    <div class="max-w-md w-auto p-3 rounded-xl shadow ${bubbleClass}">
                        <p>${msg.content}</p>
                    </div>
                </div>
            `;
        }).join('');
    }

    
    if (sessionStorage.getItem('adminAuthenticated') === 'true') {
        showAdminPanel();
    } else {
        showLoginScreen();
    }
    
    loginForm.addEventListener('submit', handleLogin);
    logoutBtn.addEventListener('click', handleLogout);
});
