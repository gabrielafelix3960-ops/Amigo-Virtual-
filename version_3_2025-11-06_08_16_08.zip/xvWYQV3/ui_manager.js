import { saveQuestionnaire, saveFriendConfig } from './api_service.js';

let currentQuestionStep = 1;
const totalQuestionSteps = 3;

export function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.add('hidden');
    });
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
        targetScreen.classList.remove('hidden');
    }
}

export function showAppView(viewId) {
    document.querySelectorAll('.app-view').forEach(view => {
        view.classList.add('hidden');
    });
    const targetView = document.getElementById(viewId);
    if (targetView) {
        targetView.classList.remove('hidden');
    }

    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('text-indigo-600');
        item.classList.add('text-gray-500');
    });

    const activeNavId = `nav-${viewId.replace('-view', '')}-btn`;
    const activeNav = document.getElementById(activeNavId);
    if(activeNav) {
        activeNav.classList.remove('text-gray-500');
        activeNav.classList.add('text-indigo-600');
    }
}


export function initializeUI() {
    setupQuestionnaireNavigation();
    setupFriendSelectionUI();
}

function setupQuestionnaireNavigation() {
    document.querySelectorAll('.question-next-btn').forEach(button => {
        button.addEventListener('click', () => {
            const currentStepEl = document.getElementById(`question-step-${currentQuestionStep}`);
            if (currentStepEl) currentStepEl.classList.add('hidden');
            
            currentQuestionStep++;
            
            if (currentQuestionStep <= totalQuestionSteps) {
                const nextStepEl = document.getElementById(`question-step-${currentQuestionStep}`);
                if (nextStepEl) nextStepEl.classList.remove('hidden');
            }
        });
    });
}

export function setupQuestionnaire() {
    const data = {};
    document.querySelectorAll('#questionnaire-screen input').forEach(input => {
        if (input.value) {
            data[input.dataset.field] = input.value;
        }
    });
    saveQuestionnaire(data);
}

function setupFriendSelectionUI() {
    const genderChoices = document.querySelectorAll('.gender-choice');
    genderChoices.forEach(choice => {
        choice.addEventListener('click', () => {
            genderChoices.forEach(c => c.querySelector('img').classList.remove('selected'));
            choice.querySelector('img').classList.add('selected');
            const gender = choice.dataset.gender;
            
            const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
            friendConfig.gender = gender;
            friendConfig.avatar = choice.querySelector('img').src;
            localStorage.setItem('friendConfig', JSON.stringify(friendConfig));

            document.getElementById('gender-selection').classList.add('hidden');
            document.getElementById('personality-selection').classList.remove('hidden');
        });
    });

    const personalities = ['Alegre', 'Divertido', 'Sério', 'Leal', 'Carinhoso', 'Atencioso', 'Extrovertido', 'Engraçado', 'Profissional'];
    const personalityList = document.getElementById('personality-list');
    personalityList.innerHTML = '';
    personalities.forEach(p => {
        const option = document.createElement('div');
        option.textContent = p;
        option.dataset.personality = p.toLowerCase();
        option.className = 'personality-option p-4 bg-gray-100 rounded-lg text-center font-medium text-gray-700 ring-1 ring-gray-200';
        option.addEventListener('click', () => {
            option.classList.toggle('selected');
            option.classList.toggle('bg-indigo-100');
            option.classList.toggle('text-indigo-700');
        });
        personalityList.appendChild(option);
    });
}

export function setupFriendSelection() {
    const selectedPersonalities = [];
    document.querySelectorAll('.personality-option.selected').forEach(p => {
        selectedPersonalities.push(p.dataset.personality);
    });
    
    const friendConfig = JSON.parse(localStorage.getItem('friendConfig')) || {};
    friendConfig.personalities = selectedPersonalities;
    saveFriendConfig(friendConfig);
}

export function renderMessage(message, sender) {
    const chatLog = document.getElementById('chat-log');
    const messageEl = document.createElement('div');
    messageEl.textContent = message;
    messageEl.className = `chat-bubble ${sender}`;
    chatLog.appendChild(messageEl);
    chatLog.scrollTop = chatLog.scrollHeight;
}

export function toggleTypingIndicator(show) {
    const indicator = document.getElementById('typing-indicator');
    if (show) {
        indicator.classList.remove('hidden');
    } else {
        indicator.classList.add('hidden');
    }
}
