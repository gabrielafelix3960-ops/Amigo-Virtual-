const Conversation = require('../models/conversation_model.js');

const generateAIResponse = (history) => {
    const lastUserMessage = history.filter(m => m.sender === 'user').pop();
    
    if (history.length < 2) {
        return "Hello! It's great to meet you. Tell me a little about your day.";
    }

    if (lastUserMessage && lastUserMessage.messageText.toLowerCase().includes('about my pet')) {
        return "You mentioned a pet before, right? Tell me more about them!";
    }

    return `This is a placeholder AI response. You said: "${lastUserMessage.messageText}". The conversation history has ${history.length} messages.`;
};

const postMessage = async (req, res) => {
    const { message } = req.body;
    const userId = req.user._id;

    if (!message) {
        return res.status(400).json({ success: false, error: 'Message text is required' });
    }

    try {
        await Conversation.create({
            user: userId,
            messageText: message,
            sender: 'user',
        });

        const conversationHistory = await Conversation.find({ user: userId }).sort({ createdAt: 1 }).limit(50);
        
        const aiResponseText = generateAIResponse(conversationHistory);

        const aiMessage = await Conversation.create({
            user: userId,
            messageText: aiResponseText,
            sender: 'ai',
        });

        res.status(201).json(aiMessage);

    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

module.exports = { postMessage };
