const UserLifeData = require('../models/user_life_data_model.js');

const getUserLifeData = async (req, res) => {
    try {
        const lifeData = await UserLifeData.findOne({ user: req.user._id });
        if (lifeData) {
            res.json(lifeData);
        } else {
            res.status(404).json({ success: false, error: 'User life data not found. Please complete the initial questionnaire.' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const updateUserLifeData = async (req, res) => {
    try {
        const lifeData = await UserLifeData.findOneAndUpdate(
            { user: req.user._id },
            req.body,
            { new: true, upsert: true, runValidators: true }
        );
        res.json(lifeData);
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};

module.exports = { getUserLifeData, updateUserLifeData };
