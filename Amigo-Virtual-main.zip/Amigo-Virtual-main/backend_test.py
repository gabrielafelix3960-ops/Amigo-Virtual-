#!/usr/bin/env python3
"""
Teste completo do backend do Amigo Virtual
Testa todos os endpoints na sequência lógica de uso do app
"""

import requests
import json
import time
from datetime import datetime

# Configuração
BASE_URL = "https://digital-buddy-11.preview.emergentagent.com/api"

# Dados de teste conforme especificado - usando timestamp para email único
import time
timestamp = int(time.time())
TEST_USER = {
    "email": f"test{timestamp}@test.com",
    "password": "123456"
}

TEST_FRIEND = {
    "name": "Ana",
    "gender": "feminino", 
    "personality": "carinhosa e encorajadora"
}

TEST_MESSAGE = "Olá! Como você está hoje?"

class BackendTester:
    def __init__(self):
        self.user_id = None
        self.friend_id = None
        self.conversation_id = None
        self.session = requests.Session()
        self.results = []
        
    def log_result(self, test_name, success, details, response_data=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat(),
            "response_data": response_data
        }
        self.results.append(result)
        status = "✅ PASSOU" if success else "❌ FALHOU"
        print(f"{status} - {test_name}")
        print(f"   Detalhes: {details}")
        if response_data:
            print(f"   Resposta: {json.dumps(response_data, indent=2, ensure_ascii=False)}")
        print("-" * 80)
        
    def test_register(self):
        """Teste 1: Registro de usuário"""
        try:
            response = self.session.post(
                f"{BASE_URL}/register",
                json=TEST_USER,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "user_id" in data:
                    self.user_id = data["user_id"]
                    self.log_result(
                        "Registro de usuário",
                        True,
                        f"Usuário registrado com sucesso. User ID: {self.user_id}",
                        data
                    )
                    return True
                else:
                    self.log_result(
                        "Registro de usuário",
                        False,
                        "Resposta não contém user_id",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Registro de usuário",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Registro de usuário",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_login(self):
        """Teste 2: Login de usuário"""
        try:
            response = self.session.post(
                f"{BASE_URL}/login",
                json=TEST_USER,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "user_id" in data:
                    # Verificar se o user_id retornado é o mesmo do registro
                    if self.user_id and data["user_id"] != self.user_id:
                        self.log_result(
                            "Login de usuário",
                            False,
                            f"User ID do login ({data['user_id']}) diferente do registro ({self.user_id})",
                            data
                        )
                        return False
                    
                    self.user_id = data["user_id"]  # Garantir que temos o user_id
                    self.log_result(
                        "Login de usuário",
                        True,
                        f"Login realizado com sucesso. User ID: {self.user_id}",
                        data
                    )
                    return True
                else:
                    self.log_result(
                        "Login de usuário",
                        False,
                        "Resposta não contém user_id",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Login de usuário",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Login de usuário",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_create_friend(self):
        """Teste 3: Criação de amigo virtual"""
        if not self.user_id:
            self.log_result(
                "Criação de amigo virtual",
                False,
                "Não foi possível criar amigo - user_id não disponível",
                None
            )
            return False
            
        try:
            response = self.session.post(
                f"{BASE_URL}/friends?user_id={self.user_id}",
                json=TEST_FRIEND,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "friend" in data and "id" in data["friend"]:
                    self.friend_id = data["friend"]["id"]
                    friend_data = data["friend"]
                    
                    # Verificar se os dados do amigo estão corretos
                    checks = []
                    if friend_data.get("name") == TEST_FRIEND["name"]:
                        checks.append("✓ Nome correto")
                    else:
                        checks.append(f"✗ Nome incorreto: esperado '{TEST_FRIEND['name']}', recebido '{friend_data.get('name')}'")
                    
                    if friend_data.get("gender") == TEST_FRIEND["gender"]:
                        checks.append("✓ Gênero correto")
                    else:
                        checks.append(f"✗ Gênero incorreto: esperado '{TEST_FRIEND['gender']}', recebido '{friend_data.get('gender')}'")
                    
                    if friend_data.get("personality") == TEST_FRIEND["personality"]:
                        checks.append("✓ Personalidade correta")
                    else:
                        checks.append(f"✗ Personalidade incorreta: esperado '{TEST_FRIEND['personality']}', recebido '{friend_data.get('personality')}'")
                    
                    self.log_result(
                        "Criação de amigo virtual",
                        True,
                        f"Amigo virtual criado com sucesso. Friend ID: {self.friend_id}. Verificações: {'; '.join(checks)}",
                        data
                    )
                    return True
                else:
                    self.log_result(
                        "Criação de amigo virtual",
                        False,
                        "Resposta não contém dados do amigo ou ID",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Criação de amigo virtual",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Criação de amigo virtual",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_list_friends(self):
        """Teste 4: Listagem de amigos"""
        if not self.user_id:
            self.log_result(
                "Listagem de amigos",
                False,
                "Não foi possível listar amigos - user_id não disponível",
                None
            )
            return False
            
        try:
            response = self.session.get(
                f"{BASE_URL}/friends/{self.user_id}",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "friends" in data:
                    friends = data["friends"]
                    
                    if len(friends) > 0:
                        # Verificar se o amigo criado está na lista
                        friend_found = False
                        for friend in friends:
                            if friend.get("id") == self.friend_id:
                                friend_found = True
                                break
                        
                        if friend_found:
                            self.log_result(
                                "Listagem de amigos",
                                True,
                                f"Lista de amigos retornada com sucesso. Total: {len(friends)} amigos. Amigo criado encontrado na lista.",
                                data
                            )
                        else:
                            self.log_result(
                                "Listagem de amigos",
                                False,
                                f"Lista retornada mas amigo criado não encontrado. Total: {len(friends)} amigos.",
                                data
                            )
                            return False
                    else:
                        self.log_result(
                            "Listagem de amigos",
                            False,
                            "Lista de amigos vazia",
                            data
                        )
                        return False
                    
                    return True
                else:
                    self.log_result(
                        "Listagem de amigos",
                        False,
                        "Resposta não contém lista de amigos",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Listagem de amigos",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Listagem de amigos",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_chat_with_ai(self):
        """Teste 5: Chat com IA"""
        if not self.user_id or not self.friend_id:
            self.log_result(
                "Chat com IA",
                False,
                "Não foi possível testar chat - user_id ou friend_id não disponível",
                None
            )
            return False
            
        try:
            chat_data = {
                "friend_id": self.friend_id,
                "message": TEST_MESSAGE
            }
            
            response = self.session.post(
                f"{BASE_URL}/chat?user_id={self.user_id}",
                json=chat_data,
                timeout=30  # Timeout maior para LLM
            )
            
            if response.status_code == 200:
                data = response.json()
                if "response" in data and "conversation_id" in data:
                    ai_response = data["response"]
                    self.conversation_id = data["conversation_id"]
                    
                    # Verificações da resposta da IA
                    checks = []
                    
                    # Verificar se a resposta não está vazia
                    if ai_response and len(ai_response.strip()) > 0:
                        checks.append("✓ Resposta não vazia")
                    else:
                        checks.append("✗ Resposta vazia")
                    
                    # Verificar se a resposta parece estar em português
                    portuguese_indicators = ["você", "está", "como", "olá", "oi", "bem", "obrigad", "por favor"]
                    has_portuguese = any(indicator in ai_response.lower() for indicator in portuguese_indicators)
                    if has_portuguese:
                        checks.append("✓ Resposta em português")
                    else:
                        checks.append("✗ Resposta pode não estar em português")
                    
                    # Verificar se a resposta tem tamanho razoável (não muito curta)
                    if len(ai_response) > 10:
                        checks.append("✓ Resposta com tamanho adequado")
                    else:
                        checks.append("✗ Resposta muito curta")
                    
                    self.log_result(
                        "Chat com IA",
                        True,
                        f"Chat realizado com sucesso. Conversation ID: {self.conversation_id}. Verificações: {'; '.join(checks)}. Resposta da IA: '{ai_response[:100]}{'...' if len(ai_response) > 100 else ''}'",
                        data
                    )
                    return True
                else:
                    self.log_result(
                        "Chat com IA",
                        False,
                        "Resposta não contém response ou conversation_id",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Chat com IA",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Chat com IA",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_conversation_history(self):
        """Teste 6: Histórico de conversas"""
        if not self.user_id or not self.friend_id:
            self.log_result(
                "Histórico de conversas",
                False,
                "Não foi possível testar histórico - user_id ou friend_id não disponível",
                None
            )
            return False
            
        try:
            response = self.session.get(
                f"{BASE_URL}/conversations/{self.user_id}/{self.friend_id}",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "messages" in data:
                    messages = data["messages"]
                    
                    if len(messages) >= 2:  # Deve ter pelo menos a mensagem do usuário e a resposta da IA
                        # Verificar se as mensagens estão corretas
                        checks = []
                        
                        # Procurar pela mensagem do usuário
                        user_message_found = False
                        ai_message_found = False
                        
                        for message in messages:
                            if message.get("sender") == "user" and message.get("content") == TEST_MESSAGE:
                                user_message_found = True
                                checks.append("✓ Mensagem do usuário encontrada")
                            elif message.get("sender") == "friend" and message.get("content"):
                                ai_message_found = True
                                checks.append("✓ Resposta da IA encontrada")
                        
                        if not user_message_found:
                            checks.append("✗ Mensagem do usuário não encontrada")
                        if not ai_message_found:
                            checks.append("✗ Resposta da IA não encontrada")
                        
                        success = user_message_found and ai_message_found
                        
                        self.log_result(
                            "Histórico de conversas",
                            success,
                            f"Histórico retornado com {len(messages)} mensagens. Verificações: {'; '.join(checks)}",
                            data
                        )
                        return success
                    else:
                        self.log_result(
                            "Histórico de conversas",
                            False,
                            f"Histórico com poucas mensagens: {len(messages)}. Esperado pelo menos 2.",
                            data
                        )
                        return False
                else:
                    self.log_result(
                        "Histórico de conversas",
                        False,
                        "Resposta não contém messages",
                        data
                    )
                    return False
            else:
                self.log_result(
                    "Histórico de conversas",
                    False,
                    f"Status code: {response.status_code}, Resposta: {response.text}",
                    None
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Histórico de conversas",
                False,
                f"Erro de conexão: {str(e)}",
                None
            )
            return False
    
    def test_freemium_limits(self):
        """Teste 7: Sistema de limite freemium"""
        if not self.user_id or not self.friend_id:
            self.log_result(
                "Sistema de limite freemium",
                False,
                "Não foi possível testar limites - user_id ou friend_id não disponível",
                None
            )
            return False
        
        print("Testando sistema de limite freemium (pode demorar um pouco)...")
        
        try:
            # Fazer várias conversas para testar o limite
            successful_chats = 0
            limit_reached = False
            last_error = None
            
            # Já fizemos 1 conversa no teste anterior, então vamos fazer mais 10 para testar o limite
            for i in range(10):  # Tentar mais 10 conversas (total seria 11)
                chat_data = {
                    "friend_id": self.friend_id,
                    "message": f"Mensagem de teste {i+2}"  # +2 porque já fizemos 1 conversa
                }
                
                response = self.session.post(
                    f"{BASE_URL}/chat?user_id={self.user_id}",
                    json=chat_data,
                    timeout=30
                )
                
                if response.status_code == 200:
                    successful_chats += 1
                elif response.status_code == 403:
                    # Limite atingido
                    limit_reached = True
                    last_error = response.text
                    break
                else:
                    # Outro erro
                    last_error = f"Status {response.status_code}: {response.text}"
                    break
                
                time.sleep(1)  # Pequena pausa entre requests
            
            # Total de conversas = 1 (do teste anterior) + successful_chats
            total_conversations = 1 + successful_chats
            
            if limit_reached and total_conversations == 10:
                self.log_result(
                    "Sistema de limite freemium",
                    True,
                    f"Sistema de limite funcionando corretamente. {total_conversations} conversas realizadas antes do limite ser atingido.",
                    {"total_conversations": total_conversations, "limit_reached": limit_reached, "last_error": last_error}
                )
                return True
            elif limit_reached and total_conversations < 10:
                self.log_result(
                    "Sistema de limite freemium",
                    False,
                    f"Limite atingido muito cedo. Apenas {total_conversations} conversas realizadas. Erro: {last_error}",
                    {"total_conversations": total_conversations, "limit_reached": limit_reached, "last_error": last_error}
                )
                return False
            elif not limit_reached:
                self.log_result(
                    "Sistema de limite freemium",
                    False,
                    f"Limite não foi aplicado. {total_conversations} conversas realizadas sem bloqueio.",
                    {"total_conversations": total_conversations, "limit_reached": limit_reached}
                )
                return False
            else:
                self.log_result(
                    "Sistema de limite freemium",
                    False,
                    f"Comportamento inesperado. {total_conversations} conversas realizadas, limite atingido: {limit_reached}",
                    {"total_conversations": total_conversations, "limit_reached": limit_reached, "last_error": last_error}
                )
                return False
                
        except Exception as e:
            self.log_result(
                "Sistema de limite freemium",
                False,
                f"Erro durante teste de limite: {str(e)}",
                None
            )
            return False
    
    def run_all_tests(self):
        """Executar todos os testes na sequência"""
        print("=" * 80)
        print("INICIANDO TESTES DO BACKEND - AMIGO VIRTUAL")
        print("=" * 80)
        print(f"URL Base: {BASE_URL}")
        print(f"Dados de teste: {TEST_USER}")
        print(f"Amigo virtual: {TEST_FRIEND}")
        print("=" * 80)
        
        tests = [
            ("Registro de usuário", self.test_register),
            ("Login de usuário", self.test_login),
            ("Criação de amigo virtual", self.test_create_friend),
            ("Listagem de amigos", self.test_list_friends),
            ("Chat com IA", self.test_chat_with_ai),
            ("Histórico de conversas", self.test_conversation_history),
            ("Sistema de limite freemium", self.test_freemium_limits)
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            print(f"\nExecutando: {test_name}")
            if test_func():
                passed += 1
            else:
                failed += 1
        
        print("\n" + "=" * 80)
        print("RESUMO DOS TESTES")
        print("=" * 80)
        print(f"✅ Testes aprovados: {passed}")
        print(f"❌ Testes falharam: {failed}")
        print(f"📊 Total de testes: {passed + failed}")
        print(f"📈 Taxa de sucesso: {(passed/(passed+failed)*100):.1f}%")
        
        if failed > 0:
            print("\n🔍 TESTES QUE FALHARAM:")
            for result in self.results:
                if not result["success"]:
                    print(f"   ❌ {result['test']}: {result['details']}")
        
        print("=" * 80)
        
        return passed, failed

if __name__ == "__main__":
    tester = BackendTester()
    passed, failed = tester.run_all_tests()
    
    # Salvar resultados detalhados
    with open("/app/backend_test_results.json", "w", encoding="utf-8") as f:
        json.dump(tester.results, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Resultados detalhados salvos em: /app/backend_test_results.json")
    
    # Exit code baseado nos resultados
    exit(0 if failed == 0 else 1)