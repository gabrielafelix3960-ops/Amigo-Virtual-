const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
const User = require('./api/models/user_model');
const bcrypt = require('bcryptjs');
const { startNotificationScheduler } = require('./services/notification_service');

dotenv.config();

connectDB();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const authRoutes = require('./api/routes/auth_routes');
const userRoutes = require('./api/routes/user_routes');
const chatRoutes = require('./api/routes/chat_routes');
const appointmentRoutes = require('./api/routes/appointment_routes');
const paymentRoutes = require('./api/routes/payment_routes');
const adminRoutes = require('./api/routes/admin_routes');

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});
app.get('/subscription', (req, res) => {
    res.sendFile(__dirname + '/subscription.html');
});
app.get('/payment-success', (req, res) => {
    res.sendFile(__dirname + '/payment_success.html');
});
app.get('/payment-cancel', (req, res) => {
    res.sendFile(__dirname + '/payment_cancel.html');
});

const createAdminAccount = async () => {
    try {
        const adminExists = await User.findOne({ email: process.env.ADMIN_EMAIL });
        if (!adminExists) {
            await User.create({
                email: process.env.ADMIN_EMAIL,
                password: process.env.ADMIN_PASSWORD,
                language: 'en',
                currency: 'USD',
                isAdmin: true,
            });
            console.log('Admin account created successfully.');
        } else {
            console.log('Admin account already exists.');
        }
    } catch (error) {
        console.error('Error creating admin account:', error);
    }
};

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    createAdminAccount();
    startNotificationScheduler();
});
