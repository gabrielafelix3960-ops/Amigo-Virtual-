import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  SafeAreaView, 
  TouchableOpacity, 
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Dimensions,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getTranslation, supportedLanguages, supportedCurrencies } from './translations';
import { ProfileScreen } from './ProfileScreen';
import { PricingScreen } from './PricingScreen';
import { AvatarScreen } from './AvatarScreen';

const { height: screenHeight } = Dimensions.get('window');

// Types
interface User {
  id: string;
  email: string;
  subscription_type: string;
}

interface VirtualFriend {
  id: string;
  name: string;
  gender: string;
  personality: string;
  avatar_base64?: string;
}

// Chat Screen Component (moved outside main component to prevent re-renders)
const ChatScreen = React.memo(({ 
  selectedFriend, 
  messages, 
  setMessages,
  inputMessage, 
  setInputMessage,
  loading,
  setLoading,
  onBack,
  sendMessage
}: {
  selectedFriend: VirtualFriend | null;
  messages: any[];
  setMessages: (messages: any[]) => void;
  inputMessage: string;
  setInputMessage: (message: string) => void;
  loading: boolean;
  setLoading: (loading: boolean) => void;
  onBack: () => void;
  sendMessage: () => void;
}) => {
  const scrollViewRef = useRef<ScrollView>(null);
  const textInputRef = useRef<TextInput>(null);

  useEffect(() => {
    // Scroll to bottom when messages change
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, [messages]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.chatHeader}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={30} color="#E91E63" />
        </TouchableOpacity>
        <View style={styles.chatHeaderInfo}>
          <Text style={styles.chatTitle}>{selectedFriend?.name}</Text>
          <Text style={styles.chatSubtitle}>Online</Text>
        </View>
        <View style={styles.chatHeaderButtons}>
          <View style={styles.avatarContainer}>
            <Ionicons 
              name={selectedFriend?.gender === 'masculino' ? 'man' : 'woman'} 
              size={30} 
              color="#E91E63" 
            />
          </View>
        </View>
      </View>

      <ScrollView 
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        showsVerticalScrollIndicator={false}
      >
        {messages.length === 0 ? (
          <View style={styles.emptyChat}>
            <Text style={styles.emptyChatText}>
              Olá! Sou {selectedFriend?.name}. Como posso te ajudar hoje?
            </Text>
          </View>
        ) : (
          messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageContainer,
                message.sender === 'user' ? styles.userMessage : styles.friendMessage
              ]}
            >
              <Text style={[
                styles.messageText,
                message.sender === 'user' ? styles.userMessageText : styles.friendMessageText
              ]}>
                {message.content}
              </Text>
              <Text style={styles.messageTime}>
                {new Date(message.timestamp).toLocaleTimeString('pt-BR', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </Text>
            </View>
          ))
        )}
      </ScrollView>

      <View style={styles.inputContainer}>
        <View style={styles.inputRow}>
          <TextInput
            ref={textInputRef}
            style={styles.messageInput}
            placeholder="Digite sua mensagem..."
            value={inputMessage}
            onChangeText={setInputMessage}
            multiline
            placeholderTextColor="#666"
            maxLength={500}
            autoFocus={false}
            blurOnSubmit={false}
          />
          <TouchableOpacity
            style={[styles.sendButton, loading && styles.buttonDisabled]}
            onPress={sendMessage}
            disabled={loading || !inputMessage.trim()}
          >
            <Ionicons name="send" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
});

export default function AmigoVirtualApp() {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'register' | 'home' | 'chat' | 'createFriend' | 'settings' | 'profile' | 'pricing' | 'avatar'>('login');
  const [user, setUser] = useState<User | null>(null);
  const [friends, setFriends] = useState<VirtualFriend[]>([]);
  const [selectedFriend, setSelectedFriend] = useState<VirtualFriend | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const textInputRef = useRef<TextInput>(null);
  
  // Login/Register form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Profile states
  const [hasProfile, setHasProfile] = useState(false);
  const [userProfile, setUserProfile] = useState<any>(null);
  
  // Internationalization
  const [currentLanguage, setCurrentLanguage] = useState('pt');
  const [currentCurrency, setCurrentCurrency] = useState('BRL');
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [showCurrencyModal, setShowCurrencyModal] = useState(false);
  const t = getTranslation(currentLanguage);

  // API base URL
  const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

  // Update user preferences
  const updateUserPreferences = async (language?: string, currency?: string) => {
    try {
      // Update local state immediately for instant UI change
      if (language) setCurrentLanguage(language);
      if (currency) setCurrentCurrency(currency);
      
      // Update backend if user is logged in
      if (user) {
        const response = await fetch(`${API_URL}/api/user/${user.id}/preferences`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            language: language || currentLanguage,
            currency: currency || currentCurrency,
          }),
        });

        if (!response.ok) {
          console.log('Erro ao salvar preferências no backend');
        }
      }
    } catch (error) {
      console.log('Erro ao atualizar preferências:', error);
    }
  };

  // Language and Currency Modal Components
  const LanguageModal = () => (
    <Modal
      visible={showLanguageModal}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowLanguageModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>{t.language}</Text>
          {supportedLanguages.map((lang) => (
            <TouchableOpacity
              key={lang.code}
              style={[
                styles.modalOption,
                currentLanguage === lang.code && styles.modalOptionSelected
              ]}
              onPress={() => {
                updateUserPreferences(lang.code);
                setShowLanguageModal(false);
              }}
            >
              <Text style={styles.modalOptionFlag}>{lang.flag}</Text>
              <Text style={[
                styles.modalOptionText,
                currentLanguage === lang.code && styles.modalOptionTextSelected
              ]}>
                {lang.name}
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={styles.modalCloseButton}
            onPress={() => setShowLanguageModal(false)}
          >
            <Text style={styles.modalCloseText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  const CurrencyModal = () => (
    <Modal
      visible={showCurrencyModal}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowCurrencyModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>{t.currency}</Text>
          {supportedCurrencies.map((curr) => (
            <TouchableOpacity
              key={curr.code}
              style={[
                styles.modalOption,
                currentCurrency === curr.code && styles.modalOptionSelected
              ]}
              onPress={() => {
                updateUserPreferences(undefined, curr.code);
                setShowCurrencyModal(false);
              }}
            >
              <Text style={styles.modalOptionFlag}>{curr.flag}</Text>
              <Text style={[
                styles.modalOptionText,
                currentCurrency === curr.code && styles.modalOptionTextSelected
              ]}>
                {curr.name} ({curr.symbol})
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={styles.modalCloseButton}
            onPress={() => setShowCurrencyModal(false)}
          >
            <Text style={styles.modalCloseText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  // Voice functions
  const startListening = async () => {
    Alert.alert(
      'Reconhecimento de Voz',
      'Funcionalidade de reconhecimento de voz em desenvolvimento. Por enquanto, use o teclado para digitar sua mensagem.',
      [{ text: 'OK' }]
    );
  };

  const speakMessage = async (message: string, gender: string) => {
    try {
      // Parar qualquer fala anterior
      Speech.stop();
      
      setIsSpeaking(true);
      
      // Configuração de voz MUITO mais expressiva e natural
      const voiceOptions = {
        language: currentLanguage === 'pt' ? 'pt-BR' : 
                  currentLanguage === 'en' ? 'en-US' :
                  currentLanguage === 'es' ? 'es-ES' : 
                  currentLanguage === 'fr' ? 'fr-FR' : 'pt-BR',
        pitch: gender === 'feminino' ? 1.2 : 0.8, // Menos extremo
        rate: 1.1, // MAIS RÁPIDO para soar natural
        voice: undefined as string | undefined,
      };

      console.log(`🎤 Configurando voz ${gender} - Rate: ${voiceOptions.rate}, Pitch: ${voiceOptions.pitch}`);

      // Obter vozes disponíveis
      const allVoices = await Speech.getAvailableVoicesAsync();
      
      // Filtrar vozes por idioma
      const languageCode = voiceOptions.language.split('-')[0];
      let languageVoices = allVoices.filter(voice => 
        voice.language.toLowerCase().includes(languageCode.toLowerCase())
      );

      // Fallback para inglês se não encontrar vozes do idioma
      if (languageVoices.length === 0) {
        languageVoices = allVoices.filter(voice => 
          voice.language.toLowerCase().includes('en')
        );
      }

      if (languageVoices.length > 0) {
        let selectedVoice = null;

        if (gender === 'masculino') {
          // Para masculino: procurar vozes mais graves e naturais
          selectedVoice = languageVoices.find(voice => {
            const name = voice.name.toLowerCase();
            return name.includes('male') || 
                   name.includes('man') ||
                   name.includes('daniel') ||
                   name.includes('alex') ||
                   name.includes('david') ||
                   name.includes('john') ||
                   name.includes('carlos');
          });

          // Se não encontrar, pegar última voz (geralmente masculina)
          if (!selectedVoice && languageVoices.length > 1) {
            selectedVoice = languageVoices[languageVoices.length - 1];
          }
        } else {
          // Para feminino: procurar vozes mais agudas
          selectedVoice = languageVoices.find(voice => {
            const name = voice.name.toLowerCase();
            return name.includes('female') || 
                   name.includes('woman') ||
                   name.includes('ana') ||
                   name.includes('maria') ||
                   name.includes('sarah');
          });

          // Se não encontrar, pegar primeira voz
          if (!selectedVoice) {
            selectedVoice = languageVoices[0];
          }
        }
        
        if (selectedVoice) {
          voiceOptions.voice = selectedVoice.identifier;
          console.log(`✅ Voz selecionada: ${selectedVoice.name}`);
        }
      }

      await Speech.speak(message, {
        ...voiceOptions,
        onDone: () => {
          console.log('🔇 Fala concluída');
          setIsSpeaking(false);
        },
        onStopped: () => {
          setIsSpeaking(false);
        },
        onError: (error) => {
          console.log('❌ Erro na fala:', error);
          setIsSpeaking(false);
        },
      });
    } catch (error) {
      setIsSpeaking(false);
      console.log('💥 Erro na síntese de voz:', error);
    }
  };

  // Authentication functions
  const handleLogin = async (email: string, password: string) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      
      if (response.ok) {
        const userData = { 
          id: data.user_id, 
          email, 
          subscription_type: 'trial',
          language: currentLanguage,
          currency: currentCurrency
        };
        setUser(userData);
        
        // Update user preferences in backend after successful login
        await updateUserPreferences(currentLanguage, currentCurrency);
        
        // Check if user has profile
        await checkUserProfile(data.user_id);
        
      } else {
        Alert.alert('Erro', data.detail || 'Erro ao fazer login');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de conexão');
    } finally {
      setLoading(false);
    }
  };

  const checkUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${API_URL}/api/profile/${userId}`);
      const data = await response.json();
      
      if (data.has_profile) {
        setHasProfile(true);
        setUserProfile(data.profile);
        setCurrentScreen('home');
        loadUserFriends(userId);
      } else {
        setHasProfile(false);
        setCurrentScreen('profile');
      }
    } catch (error) {
      // If profile check fails, go to home anyway
      setCurrentScreen('home');
      loadUserFriends(userId);
    }
  };

  const handleRegister = async (email: string, password: string) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      
      if (response.ok) {
        Alert.alert('Sucesso', 'Conta criada com sucesso! Faça login.');
        setCurrentScreen('login');
      } else {
        Alert.alert('Erro', data.detail || 'Erro ao criar conta');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de conexão');
    } finally {
      setLoading(false);
    }
  };

  const loadUserFriends = async (userId: string) => {
    try {
      const response = await fetch(`${API_URL}/api/friends/${userId}`);
      const data = await response.json();
      setFriends(data.friends || []);
    } catch (error) {
      console.log('Erro ao carregar amigos:', error);
    }
  };

  const createVirtualFriend = async (friendData: any) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/friends?user_id=${user?.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(friendData),
      });

      const data = await response.json();
      
      if (response.ok) {
        setFriends([...friends, data.friend]);
        setCurrentScreen('home');
        Alert.alert('Sucesso', 'Amigo virtual criado com sucesso!');
      } else {
        Alert.alert('Erro', data.detail || 'Erro ao criar amigo virtual');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de conexão');
    } finally {
      setLoading(false);
    }
  };

  const createUserProfile = async (profileData: any) => {
    if (!user) return;
    
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/profile?user_id=${user.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(profileData),
      });

      const data = await response.json();
      
      if (response.ok) {
        setHasProfile(true);
        setUserProfile(data.profile);
        setCurrentScreen('home');
        loadUserFriends(user.id);
        Alert.alert(t.success, 'Perfil criado com sucesso!');
      } else {
        Alert.alert(t.error, data.detail || 'Erro ao criar perfil');
      }
    } catch (error) {
      Alert.alert(t.error, t.connectionError);
    } finally {
      setLoading(false);
    }
  };

  const skipProfile = () => {
    setCurrentScreen('home');
    if (user) {
      loadUserFriends(user.id);
    }
  };

  const loadConversationHistory = async (friendId: string) => {
    try {
      const response = await fetch(`${API_URL}/api/conversations/${user?.id}/${friendId}`);
      const data = await response.json();
      setMessages(data.messages || []);
    } catch (error) {
      console.log('Erro ao carregar histórico:', error);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !selectedFriend || !user) return;

    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/chat?user_id=${user.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          friend_id: selectedFriend.id,
          message: inputMessage.trim(),
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        const newUserMessage = {
          id: Date.now().toString(),
          sender: 'user',
          content: inputMessage.trim(),
          timestamp: new Date().toISOString(),
        };
        
        const newFriendMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'friend',
          content: data.response,
          timestamp: new Date().toISOString(),
        };

        setMessages(prev => [...prev, newUserMessage, newFriendMessage]);
        setInputMessage('');
        
      } else {
        // Handle specific premium upgrade errors
        if (response.status === 429 || response.status === 402) {
          Alert.alert(
            'Limite Atingido',
            `${data.detail}\n\nQuer continuar conversando com ${selectedFriend?.name}? Assine o Premium agora!`,
            [
              { text: 'Cancelar', style: 'cancel' },
              { 
                text: 'Ver Planos Premium', 
                onPress: () => setCurrentScreen('pricing') 
              }
            ]
          );
        } else {
          Alert.alert('Erro', data.detail || 'Erro ao enviar mensagem');
        }
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de conexão');
    } finally {
      setLoading(false);
    }
  };

  const handleChatBack = () => {
    setCurrentScreen('home');
  };

  // Screen Components
  const LoginScreen = () => {
    return (
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.flex}
        >
          <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.headerContainer}>
              <Ionicons name="heart" size={80} color="#E91E63" />
              <Text style={styles.appTitle}>{t.appTitle}</Text>
              <Text style={styles.subtitle}>{t.subtitle}</Text>
              
              {/* Language/Currency Selectors */}
              <View style={styles.languageCurrencyContainer}>
                <TouchableOpacity 
                  style={styles.languageButton}
                  onPress={() => setShowLanguageModal(true)}
                >
                  <Text style={styles.languageButtonText}>
                    {supportedLanguages.find(l => l.code === currentLanguage)?.flag} {t.language}
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.currencyButton}
                  onPress={() => setShowCurrencyModal(true)}
                >
                  <Text style={styles.currencyButtonText}>
                    {supportedCurrencies.find(c => c.code === currentCurrency)?.symbol} {currentCurrency}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.formContainer}>
              <TextInput
                style={styles.input}
                placeholder={t.email}
                value={loginEmail}
                onChangeText={setLoginEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="#666"
              />
              
              <TextInput
                style={styles.input}
                placeholder={t.password}
                value={loginPassword}
                onChangeText={setLoginPassword}
                secureTextEntry
                placeholderTextColor="#666"
              />

              <TouchableOpacity 
                style={[styles.primaryButton, loading && styles.buttonDisabled]}
                onPress={() => handleLogin(loginEmail, loginPassword)}
                disabled={loading}
              >
                <Text style={styles.primaryButtonText}>
                  {loading ? t.loading : t.login}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.secondaryButton}
                onPress={() => setCurrentScreen('register')}
              >
                <Text style={styles.secondaryButtonText}>{t.register}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
        <LanguageModal />
        <CurrencyModal />
      </SafeAreaView>
    );
  };

  const RegisterScreen = () => {
    const handleSubmit = () => {
      if (registerPassword !== confirmPassword) {
        Alert.alert(t.error, t.passwordsDontMatch);
        return;
      }
      if (registerPassword.length < 6) {
        Alert.alert(t.error, t.passwordTooShort);
        return;
      }
      handleRegister(registerEmail, registerPassword);
    };

    return (
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.flex}
        >
          <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.headerContainer}>
              <TouchableOpacity onPress={() => setCurrentScreen('login')}>
                <Ionicons name="arrow-back" size={30} color="#E91E63" />
              </TouchableOpacity>
              <Text style={styles.screenTitle}>{t.createAccount}</Text>
            </View>

            <View style={styles.formContainer}>
              <TextInput
                style={styles.input}
                placeholder={t.email}
                value={registerEmail}
                onChangeText={setRegisterEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="#666"
              />
              
              <TextInput
                style={styles.input}
                placeholder={t.password}
                value={registerPassword}
                onChangeText={setRegisterPassword}
                secureTextEntry
                placeholderTextColor="#666"
              />

              <TextInput
                style={styles.input}
                placeholder={t.confirmPassword}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
                placeholderTextColor="#666"
              />

              <TouchableOpacity 
                style={[styles.primaryButton, loading && styles.buttonDisabled]}
                onPress={handleSubmit}
                disabled={loading}
              >
                <Text style={styles.primaryButtonText}>
                  {loading ? t.loading : t.createAccount}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  };

  const HomeScreen = () => {
    const getSubscriptionText = () => {
      if (user?.subscription_type === 'trial') {
        return t.trialPlan;
      } else if (user?.subscription_type === 'premium') {
        return t.premiumPlan;
      } else if (user?.subscription_type === 'expired') {
        return t.expiredPlan;
      }
      return t.freeTrial;
    };

    const showUpgradePrompt = () => {
      return user?.subscription_type === 'trial' || user?.subscription_type === 'expired';
    };

    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.welcomeText}>{t.welcome}, {user?.email}</Text>
          <Text style={styles.planText}>
            {t.plan}: {getSubscriptionText()}
          </Text>
        </View>

        {/* Upgrade Banner */}
        {showUpgradePrompt() && (
          <TouchableOpacity 
            style={styles.upgradeBanner}
            onPress={() => setCurrentScreen('pricing')}
          >
            <View style={styles.upgradeBannerContent}>
              <Ionicons name="diamond" size={24} color="#FFD700" />
              <View style={styles.upgradeBannerText}>
                <Text style={styles.upgradeBannerTitle}>
                  {user?.subscription_type === 'expired' ? 
                    '⏰ Período de teste expirado!' : 
                    '🎁 Aproveite seu teste grátis!'
                  }
                </Text>
                <Text style={styles.upgradeBannerSubtitle}>
                  {user?.subscription_type === 'expired' ? 
                    'Assine agora para continuar conversando' :
                    'Restam poucos dias - garante já seu Premium!'
                  }
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#FFD700" />
            </View>
          </TouchableOpacity>
        )}

        <ScrollView style={styles.friendsList}>
          {friends.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="person-add" size={80} color="#ccc" />
              <Text style={styles.emptyText}>{t.noFriends}</Text>
              <Text style={styles.emptySubtext}>{t.createFirstFriend}</Text>
            </View>
          ) : (
            friends.map((friend) => (
              <TouchableOpacity
                key={friend.id}
                style={styles.friendCard}
                onPress={() => {
                  setSelectedFriend(friend);
                  loadConversationHistory(friend.id);
                  setCurrentScreen('chat');
                }}
              >
                <View style={styles.avatarContainer}>
                  <Ionicons 
                    name={friend.gender === 'masculino' ? 'man' : 'woman'} 
                    size={40} 
                    color="#E91E63" 
                  />
                </View>
                <View style={styles.friendInfo}>
                  <Text style={styles.friendName}>{friend.name}</Text>
                  <Text style={styles.friendDetails}>
                    {friend.gender === 'masculino' ? t.male : t.female} • {friend.personality}
                  </Text>
                  {showUpgradePrompt() && (
                    <Text style={styles.friendUpgradeHint}>
                      💎 Conversas ilimitadas com Premium
                    </Text>
                  )}
                </View>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </TouchableOpacity>
            ))
          )}
        </ScrollView>

        <TouchableOpacity
          style={styles.fab}
          onPress={() => setCurrentScreen('createFriend')}
        >
          <Ionicons name="add" size={30} color="white" />
        </TouchableOpacity>
      </SafeAreaView>
    );
  };

  const CreateFriendScreen = () => {
    const [name, setName] = useState('');
    const [gender, setGender] = useState('masculino');
    const [personality, setPersonality] = useState('amigável e prestativo');

    const handleCreate = () => {
      if (!name.trim()) {
        Alert.alert('Erro', 'Digite um nome para seu amigo virtual');
        return;
      }

      createVirtualFriend({
        name: name.trim(),
        gender,
        personality,
      });
    };

    return (
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.flex}
        >
          <ScrollView>
            <View style={styles.header}>
              <TouchableOpacity onPress={() => setCurrentScreen('home')}>
                <Ionicons name="arrow-back" size={30} color="#E91E63" />
              </TouchableOpacity>
              <Text style={styles.screenTitle}>Criar Amigo Virtual</Text>
            </View>

            <View style={styles.formContainer}>
              <Text style={styles.label}>Nome do seu amigo:</Text>
              <TextInput
                style={styles.input}
                placeholder="Ex: Ana, Carlos, Maria..."
                value={name}
                onChangeText={setName}
                placeholderTextColor="#666"
              />

              <Text style={styles.label}>Gênero:</Text>
              <View style={styles.genderContainer}>
                <TouchableOpacity
                  style={[styles.genderButton, gender === 'masculino' && styles.genderButtonSelected]}
                  onPress={() => setGender('masculino')}
                >
                  <Ionicons name="man" size={24} color={gender === 'masculino' ? 'white' : '#E91E63'} />
                  <Text style={[styles.genderText, gender === 'masculino' && styles.genderTextSelected]}>
                    Masculino
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.genderButton, gender === 'feminino' && styles.genderButtonSelected]}
                  onPress={() => setGender('feminino')}
                >
                  <Ionicons name="woman" size={24} color={gender === 'feminino' ? 'white' : '#E91E63'} />
                  <Text style={[styles.genderText, gender === 'feminino' && styles.genderTextSelected]}>
                    Feminino
                  </Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.label}>Personalidade:</Text>
              <TextInput
                style={[styles.input, { height: 80 }]}
                placeholder="Ex: carinhoso e encorajador, divertido e espirituoso..."
                value={personality}
                onChangeText={setPersonality}
                multiline
                placeholderTextColor="#666"
              />

              <TouchableOpacity 
                style={[styles.primaryButton, loading && styles.buttonDisabled]}
                onPress={handleCreate}
                disabled={loading}
              >
                <Text style={styles.primaryButtonText}>
                  {loading ? 'Criando...' : 'Criar Amigo Virtual'}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  };

  // Render current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <LoginScreen />;
      case 'register':
        return <RegisterScreen />;
      case 'home':
        return <HomeScreen />;
      case 'createFriend':
        return <CreateFriendScreen />;
      case 'profile':
        return (
          <ProfileScreen
            user={user}
            onComplete={createUserProfile}
            onSkip={skipProfile}
            loading={loading}
          />
        );
      case 'chat':
        return (
          <ChatScreen
            selectedFriend={selectedFriend}
            messages={messages}
            setMessages={setMessages}
            inputMessage={inputMessage}
            setInputMessage={setInputMessage}
            loading={loading}
            setLoading={setLoading}
            onBack={handleChatBack}
            sendMessage={sendMessage}
          />
        );
      case 'pricing':
        return (
          <PricingScreen
            user={user}
            currentCurrency={currentCurrency}
            onBack={() => setCurrentScreen('home')}
            onSubscribe={(plan) => {
              Alert.alert(
                'Redirecionamento',
                'Você será redirecionado para o Google Play Store para completar sua assinatura.',
                [{ text: 'OK' }]
              );
            }}
          />
        );
      case 'avatar':
        return (
          <AvatarScreen
            friend={selectedFriend}
            onBack={() => setCurrentScreen('home')}
            onSave={(avatarData) => {
              Alert.alert('Avatar Salvo', 'Avatar personalizado salvo com sucesso!');
              setCurrentScreen('home');
            }}
            isPreview={user?.subscription_type !== 'premium'}
          />
        );
      default:
        return <LoginScreen />;
    }
  };

  return renderScreen();
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  flex: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  headerContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  appTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#E91E63',
    marginTop: 20,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginLeft: 15,
  },
  formContainer: {
    width: '100%',
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#e1e5e9',
  },
  primaryButton: {
    backgroundColor: '#E91E63',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 10,
  },
  primaryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  secondaryButton: {
    marginTop: 16,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#E91E63',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  header: {
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  planText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  friendsList: {
    flex: 1,
    padding: 20,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
  friendCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  avatarContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#fce4ec',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  friendInfo: {
    flex: 1,
  },
  friendName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  friendDetails: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  fab: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#E91E63',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
    marginTop: 16,
  },
  genderContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  genderButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    marginHorizontal: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E91E63',
    backgroundColor: 'white',
  },
  genderButtonSelected: {
    backgroundColor: '#E91E63',
  },
  genderText: {
    marginLeft: 8,
    fontSize: 16,
    fontWeight: '600',
    color: '#E91E63',
  },
  genderTextSelected: {
    color: 'white',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  chatHeaderInfo: {
    flex: 1,
    marginLeft: 16,
  },
  chatHeaderButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  speakButton: {
    marginRight: 12,
    padding: 8,
  },
  chatTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  chatSubtitle: {
    fontSize: 14,
    color: '#4CAF50',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    paddingBottom: 20,
  },
  emptyChat: {
    padding: 20,
    alignItems: 'center',
  },
  emptyChatText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  messageContainer: {
    marginBottom: 12,
    maxWidth: '80%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#E91E63',
    borderRadius: 18,
    borderBottomRightRadius: 4,
    padding: 12,
  },
  friendMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'white',
    borderRadius: 18,
    borderBottomLeftRadius: 4,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  userMessageText: {
    color: 'white',
  },
  friendMessageText: {
    color: '#333',
  },
  messageTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
    textAlign: 'right',
  },
  inputContainer: {
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#e1e5e9',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  messageInput: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 8,
    maxHeight: 100,
    fontSize: 16,
  },
  voiceButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#f8f9fa',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
    borderWidth: 2,
    borderColor: '#E91E63',
  },
  voiceButtonActive: {
    backgroundColor: '#E91E63',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#E91E63',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  // Language and Currency Selector Styles
  languageCurrencyContainer: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 10,
  },
  languageButton: {
    backgroundColor: 'rgba(233, 30, 99, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E91E63',
  },
  languageButtonText: {
    color: '#E91E63',
    fontSize: 12,
    fontWeight: '600',
  },
  currencyButton: {
    backgroundColor: 'rgba(233, 30, 99, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E91E63',
  },
  currencyButtonText: {
    color: '#E91E63',
    fontSize: 12,
    fontWeight: '600',
  },
  
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    width: '80%',
    maxHeight: '70%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  modalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  modalOptionSelected: {
    backgroundColor: '#E91E63',
  },
  modalOptionFlag: {
    fontSize: 24,
    marginRight: 12,
  },
  modalOptionText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  modalOptionTextSelected: {
    color: 'white',
    fontWeight: 'bold',
  },
  modalCloseButton: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
    marginTop: 10,
    alignItems: 'center',
  },
  modalCloseText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '600',
  },
  
  // Upgrade Banner Styles
  upgradeBanner: {
    backgroundColor: '#E91E63',
    marginHorizontal: 20,
    marginVertical: 10,
    borderRadius: 16,
    shadowColor: '#E91E63',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  upgradeBannerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  upgradeBannerText: {
    flex: 1,
    marginLeft: 12,
  },
  upgradeBannerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  upgradeBannerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  friendUpgradeHint: {
    fontSize: 12,
    color: '#FFD700',
    marginTop: 4,
    fontWeight: '600',
  },
});