const express = require('express');
const router = express.Router();
const { getUserLifeData, updateUserLifeData } = require('../controllers/user_controller');
const { protect } = require('../middleware/auth_middleware');

router.route('/life-data').get(protect, getUserLifeData).put(protect, updateUserLifeData);

module.exports = router;
