import { login, register } from './api_service.js';
import { showScreen } from './ui_manager.js';
import { initChat } from './chat_manager.js';

export async function handleRegister(event) {
    event.preventDefault();
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const currency = document.getElementById('register-currency').value;
    const language = document.getElementById('register-language').value;

    try {
        const result = await register(email, password, currency, language);
        if (result.success) {
            localStorage.setItem('userToken', result.token);
            localStorage.setItem('userData', JSON.stringify(result.user));
            showScreen('questionnaire-screen');
        } else {
            alert(result.error || 'Falha no registro.');
        }
    } catch (error) {
        alert('Erro: ' + error.message);
    }
}

export async function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const result = await login(email, password);
        if (result.success) {
            localStorage.setItem('userToken', result.token);
            localStorage.setItem('userData', JSON.stringify(result.user));
            
            const friendConfig = JSON.parse(localStorage.getItem('friendConfig'));
            if (friendConfig) {
                 initChat();
                 showScreen('chat-screen');
            } else {
                 showScreen('friend-setup-screen');
            }
        } else {
            alert(result.error || 'Falha no login.');
        }
    } catch (error) {
        alert('Erro: ' + error.message);
    }
}

export function handleLogout() {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userData');
    localStorage.removeItem('friendConfig');
    localStorage.removeItem('chatHistory');
    showScreen('welcome-screen');
}

export function checkAuth() {
    const token = localStorage.getItem('userToken');
    return token ? JSON.parse(localStorage.getItem('userData')) : null;
}
