#!/usr/bin/env python3
"""
Teste simplificado do modelo de negócio de 7 dias de teste
Foca na funcionalidade principal sem se preocupar com códigos HTTP específicos
"""

import requests
import json
import time
from datetime import datetime

# Configuração
BASE_URL = "https://digital-buddy-11.preview.emergentagent.com/api"

def test_trial_business_model():
    """Teste principal do modelo de negócio trial"""
    print("=" * 80)
    print("TESTE SIMPLIFICADO - MODELO DE NEGÓCIO 7 DIAS TRIAL")
    print("=" * 80)
    
    results = []
    
    # 1. CENÁRIO: Novo usuário - período de teste ativo
    print("\n🔍 CENÁRIO 1: Novo usuário com trial ativo")
    
    timestamp = int(time.time())
    test_user = {
        "email": f"trial_simple_{timestamp}@test.com",
        "password": "123456"
    }
    
    # Registrar usuário
    response = requests.post(f"{BASE_URL}/register", json=test_user, timeout=10)
    if response.status_code == 200:
        user_data = response.json()
        user_id = user_data.get("user_id")
        print(f"✅ Usuário registrado: {user_id}")
        results.append("✅ Registro de usuário trial")
        
        # Criar amigo virtual
        friend_data = {
            "name": "Carlos",
            "gender": "masculino",
            "personality": "motivador"
        }
        
        response = requests.post(f"{BASE_URL}/friends?user_id={user_id}", json=friend_data, timeout=10)
        if response.status_code == 200:
            friend_response = response.json()
            friend_id = friend_response.get("friend", {}).get("id")
            print(f"✅ Amigo criado: {friend_id}")
            results.append("✅ Criação de amigo virtual")
            
            # 2. Testar 10 conversas permitidas
            print("\n🔍 TESTANDO: 10 conversas diárias permitidas")
            successful_chats = 0
            
            for i in range(10):
                chat_data = {
                    "friend_id": friend_id,
                    "message": f"Mensagem de teste {i+1}"
                }
                
                response = requests.post(f"{BASE_URL}/chat?user_id={user_id}", json=chat_data, timeout=30)
                if response.status_code == 200:
                    successful_chats += 1
                    print(f"   ✅ Conversa {i+1}: Sucesso")
                else:
                    print(f"   ❌ Conversa {i+1}: Erro {response.status_code}")
                    break
                
                time.sleep(0.3)  # Pequena pausa
            
            if successful_chats == 10:
                print(f"✅ 10 conversas realizadas com sucesso no trial")
                results.append("✅ 10 conversas diárias permitidas")
            else:
                print(f"❌ Apenas {successful_chats} conversas realizadas")
                results.append(f"❌ Apenas {successful_chats}/10 conversas funcionaram")
            
            # 3. Testar 11ª conversa (deve ser bloqueada)
            print("\n🔍 TESTANDO: 11ª conversa deve ser bloqueada")
            chat_data = {
                "friend_id": friend_id,
                "message": "Esta é a 11ª conversa - deve ser bloqueada"
            }
            
            response = requests.post(f"{BASE_URL}/chat?user_id={user_id}", json=chat_data, timeout=30)
            if response.status_code != 200:
                # Verificar se a mensagem de erro contém o texto esperado
                try:
                    error_data = response.json()
                    error_message = error_data.get("detail", "")
                    if "Limite de 10 conversas diárias atingido" in error_message and "período de teste" in error_message:
                        print("✅ 11ª conversa bloqueada com mensagem correta")
                        results.append("✅ Limite diário funcionando com mensagem adequada")
                    else:
                        print(f"⚠️ 11ª conversa bloqueada mas mensagem inadequada: {error_message}")
                        results.append("⚠️ Limite funcionando mas mensagem inadequada")
                except:
                    print(f"⚠️ 11ª conversa bloqueada (status {response.status_code}) mas erro ao ler mensagem")
                    results.append("⚠️ Limite funcionando mas erro na mensagem")
            else:
                print("❌ 11ª conversa NÃO foi bloqueada - PROBLEMA CRÍTICO")
                results.append("❌ Limite diário NÃO funcionando")
        else:
            print(f"❌ Erro ao criar amigo: {response.status_code}")
            results.append("❌ Falha na criação de amigo")
    else:
        print(f"❌ Erro no registro: {response.status_code}")
        results.append("❌ Falha no registro")
    
    # Resumo final
    print("\n" + "=" * 80)
    print("RESUMO DO TESTE")
    print("=" * 80)
    
    passed = sum(1 for r in results if r.startswith("✅"))
    warnings = sum(1 for r in results if r.startswith("⚠️"))
    failed = sum(1 for r in results if r.startswith("❌"))
    
    for result in results:
        print(result)
    
    print(f"\n📊 ESTATÍSTICAS:")
    print(f"✅ Aprovados: {passed}")
    print(f"⚠️ Avisos: {warnings}")
    print(f"❌ Falharam: {failed}")
    print(f"📈 Taxa de sucesso: {(passed/(passed+warnings+failed)*100):.1f}%")
    
    # Avaliação para Google Play
    print("\n" + "=" * 80)
    print("AVALIAÇÃO PARA GOOGLE PLAY")
    print("=" * 80)
    
    if failed == 0 and warnings <= 1:
        print("🎉 SISTEMA PRONTO PARA VENDA!")
        print("✅ Modelo de negócio trial funcionando corretamente")
        print("✅ Usuários podem testar por 7 dias com 10 conversas/dia")
        print("✅ Limite diário implementado e funcionando")
        if warnings > 0:
            print("⚠️ Pequenos ajustes nas mensagens podem melhorar a experiência")
    elif failed <= 1:
        print("⚠️ SISTEMA QUASE PRONTO")
        print("🔧 Pequenos ajustes necessários antes da publicação")
    else:
        print("🚫 SISTEMA NÃO PRONTO")
        print("❌ Problemas críticos precisam ser corrigidos")
    
    print("=" * 80)
    
    return passed, warnings, failed

if __name__ == "__main__":
    passed, warnings, failed = test_trial_business_model()
    exit(0 if failed == 0 else 1)