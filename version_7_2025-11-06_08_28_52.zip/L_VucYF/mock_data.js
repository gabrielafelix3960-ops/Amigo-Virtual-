export const mockUsers = [
    {
        id: 1,
        email: 'ana.silva@example.com',
        registeredAt: '2025-05-10T10:00:00Z',
        subscription: { status: 'active', plan: 'annual' },
    },
    {
        id: 2,
        email: 'bruno.costa@example.com',
        registeredAt: '2025-05-28T14:30:00Z',
        subscription: { status: 'trial' },
    },
    {
        id: 3,
        email: 'carla.dias@example.com',
        registeredAt: '2025-03-15T09:00:00Z',
        subscription: { status: 'expired' },
    },
    {
        id: 4,
        email: 'diogo.martins@example.com',
        registeredAt: '2025-06-01T11:20:00Z',
        subscription: { status: 'active', plan: 'monthly' },
    },
    {
        id: 5,
        email: 'elisa.ferreira@example.com',
        registeredAt: '2024-12-20T18:00:00Z',
        subscription: { status: 'suspended' },
    }
];

export const mockConversations = {
    1: [
        { role: 'user', content: 'Olá! Como você está hoje?' },
        { role: 'assistant', content: 'Olá Ana! Estou ótimo, obrigado por perguntar. Pronto para mais um dia produtivo? Vi que você tem uma reunião às 15h.' },
        { role: 'user', content: 'Verdade! Obrigado por me lembrar. Fiquei o dia todo trabalhando e quase me esqueci.' },
        { role: 'assistant', content: 'Sem problemas! É para isso que estou aqui. Quer que eu te avise 10 minutos antes?' },
    ],
    2: [
        { role: 'user', content: 'Oi, é a minha primeira vez aqui.' },
        { role: 'assistant', content: 'Bem-vindo, Bruno! Estou aqui para ser seu amigo. Pode me contar qualquer coisa. Sobre o que gostaria de conversar?' },
    ],
    3: [
        { role: 'user', content: 'Por que não consigo mais falar?' },
        { role: 'assistant', content: 'Olá Carla. Parece que seu período de teste ou assinatura expirou. Você pode reativar sua assinatura na tela de pagamentos para continuarmos nossas conversas.' },
    ],
    4: [
        { role: 'user', content: 'Preciso de um conselho.' },
        { role: 'assistant', content: 'Claro, Diogo. Sou todo ouvidos. O que está te preocupando?' },
        { role: 'user', content: 'É sobre meu trabalho. Estou me sentindo desmotivado.' },
        { role: 'assistant', content: 'Entendo perfeitamente. Às vezes, todos nós nos sentimos assim. O que exatamente está causando essa desmotivação?' },
    ],
    5: []
};
