from fastapi import FastAPI, APIRouter, HTTPException, Depends
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
from emergentintegrations.llm.chat import LlmChat, UserMessage
import hashlib

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Configure logging first
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# MongoDB connection
mongo_url = os.environ['MONGO_URL'].strip('"')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME'].strip('"')]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    password_hash: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    subscription_type: str = "trial"  # trial, premium, expired
    trial_end_date: datetime = Field(default_factory=lambda: datetime.utcnow() + timedelta(days=7))
    conversations_today: int = 0
    last_conversation_date: str = ""
    language: str = "pt"  # pt, en, es, fr, de, ja, zh
    currency: str = "BRL"  # BRL, USD, EUR, JPY, CNY, etc.

class UserProfile(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    
    # Personal Info
    name: str
    age: int
    profession: str  # "student", "worker", "retired", "unemployed", "other"
    
    # Work/Study Schedule
    work_days: List[str] = []  # ["monday", "tuesday", "wednesday", "thursday", "friday"]
    work_start_time: str = "09:00"
    work_end_time: str = "17:00"
    study_days: List[str] = []
    study_schedule: str = ""
    
    # Health & Routine
    takes_medication: bool = False
    medication_times: List[str] = []  # ["08:00", "14:00", "20:00"]
    medication_names: List[str] = []
    exercise_routine: str = ""
    exercise_days: List[str] = []
    
    # Lifestyle
    hobbies: List[str] = []
    favorite_activities: List[str] = []
    living_situation: str = ""  # "alone", "family", "roommates"
    pets: List[str] = []
    
    # Daily Routine
    wake_up_time: str = "07:00"
    sleep_time: str = "23:00"
    meal_times: dict = {"breakfast": "08:00", "lunch": "12:00", "dinner": "19:00"}
    
    created_at: datetime = Field(default_factory=datetime.utcnow)

class UserProfileCreate(BaseModel):
    name: str
    age: int
    profession: str
    work_days: List[str] = []
    work_start_time: str = "09:00"
    work_end_time: str = "17:00"
    study_days: List[str] = []
    study_schedule: str = ""
    takes_medication: bool = False
    medication_times: List[str] = []
    medication_names: List[str] = []
    exercise_routine: str = ""
    exercise_days: List[str] = []
    hobbies: List[str] = []
    favorite_activities: List[str] = []
    living_situation: str = ""
    pets: List[str] = []
    wake_up_time: str = "07:00"
    sleep_time: str = "23:00"
    meal_times: dict = {"breakfast": "08:00", "lunch": "12:00", "dinner": "19:00"}

class UserCreate(BaseModel):
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class VirtualFriend(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    name: str
    gender: str  # "masculino" or "feminino"
    avatar_base64: Optional[str] = None
    voice_type: str = "default"
    personality: str = "amigável e prestativo"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class VirtualFriendCreate(BaseModel):
    name: str
    gender: str
    avatar_base64: Optional[str] = None
    voice_type: str = "default"
    personality: str = "amigável e prestativo"

class Conversation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    friend_id: str
    messages: List[dict] = []
    topics: List[dict] = []  # Lista de tópicos discutidos com contexto
    memory_summary: str = ""  # Resumo das conversas para contexto
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class Message(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    conversation_id: str
    sender: str  # "user" or "friend"
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ChatRequest(BaseModel):
    friend_id: str
    message: str

class ChatResponse(BaseModel):
    response: str
    conversation_id: str

# Global pricing and language configuration
GLOBAL_PRICING = {
    "BRL": {"monthly": 39.90, "annual": 299.90, "currency_symbol": "R$"},
    "USD": {"monthly": 7.99, "annual": 59.99, "currency_symbol": "$"},
    "EUR": {"monthly": 7.49, "annual": 54.99, "currency_symbol": "€"},
    "GBP": {"monthly": 6.49, "annual": 47.99, "currency_symbol": "£"},
    "JPY": {"monthly": 1180, "annual": 8900, "currency_symbol": "¥"},
    "CNY": {"monthly": 58, "annual": 428, "currency_symbol": "¥"},
    "MXN": {"monthly": 159, "annual": 1199, "currency_symbol": "$"},
    "ARS": {"monthly": 7999, "annual": 59999, "currency_symbol": "$"},
}

LANGUAGE_NAMES = {
    "pt": "Português",
    "en": "English", 
    "es": "Español",
    "fr": "Français",
    "de": "Deutsch",
    "ja": "日本語",
    "zh": "中文"
}

LANGUAGE_SYSTEM_PROMPTS = {
    "pt": "português brasileiro",
    "en": "English",
    "es": "español",
    "fr": "français", 
    "de": "Deutsch",
    "ja": "日本語",
    "zh": "中文"
}

# Helper functions
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed

# Authentication endpoints
@api_router.post("/register")
async def register_user(user_data: UserCreate):
    # Check if user exists
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email já cadastrado")
    
    # Create user
    hashed_password = hash_password(user_data.password)
    user = User(
        email=user_data.email,
        password_hash=hashed_password
    )
    
    await db.users.insert_one(user.dict())
    return {"message": "Usuário criado com sucesso", "user_id": user.id}

@api_router.post("/login")
async def login_user(credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email})
    if not user or not verify_password(credentials.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    
    return {"message": "Login realizado com sucesso", "user_id": user["id"]}

# Virtual Friend endpoints
@api_router.post("/friends")
async def create_virtual_friend(friend_data: VirtualFriendCreate, user_id: str):
    # Check if user exists
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    friend = VirtualFriend(
        user_id=user_id,
        **friend_data.dict()
    )
    
    await db.virtual_friends.insert_one(friend.dict())
    return {"message": "Amigo virtual criado com sucesso", "friend": friend}

@api_router.get("/friends/{user_id}")
async def get_user_friends(user_id: str):
    friends = await db.virtual_friends.find({"user_id": user_id}).to_list(100)
    # Convert ObjectId to string for JSON serialization
    for friend in friends:
        if "_id" in friend:
            del friend["_id"]  # Remove MongoDB ObjectId
    return {"friends": friends}

# Chat endpoints
@api_router.post("/chat")
async def chat_with_friend(chat_request: ChatRequest, user_id: str):
    try:
        # Get user
        user = await db.users.find_one({"id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        # Check subscription and trial limits
        today = datetime.utcnow().strftime("%Y-%m-%d")
        current_time = datetime.utcnow()
        
        # Check if trial period has expired
        trial_end = user.get("trial_end_date")
        if isinstance(trial_end, str):
            trial_end = datetime.fromisoformat(trial_end.replace('Z', '+00:00'))
        
        if user["subscription_type"] == "trial":
            if current_time > trial_end:
                # Trial expired - update user status
                await db.users.update_one(
                    {"id": user_id},
                    {"$set": {"subscription_type": "expired"}}
                )
                raise HTTPException(
                    status_code=402, 
                    detail="Seu período de teste de 7 dias expirou! Para continuar conversando com seu amigo virtual, assine o plano premium."
                )
            
            # Trial active - check daily limit
            if user.get("last_conversation_date") == today and user.get("conversations_today", 0) >= 10:
                raise HTTPException(
                    status_code=429, 
                    detail="Limite de 10 conversas diárias atingido! Você ainda tem acesso até o fim do período de teste."
                )
        
        elif user["subscription_type"] == "expired":
            raise HTTPException(
                status_code=402, 
                detail="Seu período de teste expirou! Assine o plano premium para continuar usando o Amigo Virtual."
            )
        
        # Premium users have unlimited access (no limits)
        
        # Get friend
        friend = await db.virtual_friends.find_one({"id": chat_request.friend_id})
        if not friend:
            raise HTTPException(status_code=404, detail="Amigo virtual não encontrado")
        
        # Get or create conversation
        conversation = await db.conversations.find_one({
            "user_id": user_id, 
            "friend_id": chat_request.friend_id
        })
        
        if not conversation:
            conversation = Conversation(
                user_id=user_id,
                friend_id=chat_request.friend_id,
                topics=[],
                memory_summary=""
            ).dict()
            await db.conversations.insert_one(conversation)
        
        # Extract topics and build memory context from current message
        current_message = chat_request.message.lower()
        
        # Get user profile for contextual conversations
        user_profile = await db.user_profiles.find_one({"user_id": user_id})
        
        # Build comprehensive memory context
        memory_context = await build_memory_context(conversation, current_message, friend['name'])
        
        # Generate contextual prompt based on user profile and current time
        contextual_info = ""
        if user_profile:
            contextual_info = generate_contextual_prompt(user_profile, datetime.utcnow(), friend)
        
        # Prepare system message with enhanced memory and personality in user's language
        user_language = user.get("language", "pt")
        language_name = LANGUAGE_SYSTEM_PROMPTS.get(user_language, "português brasileiro")
        
        profile_context = ""
        if user_profile:
            profile_context = f"""
PERSONAL INFORMATION ABOUT YOUR FRIEND:
- Name: {user_profile.get('name', 'Unknown')}
- Age: {user_profile.get('age', 'Unknown')}
- Profession: {user_profile.get('profession', 'Unknown')}
- Living situation: {user_profile.get('living_situation', 'Unknown')}
- Hobbies: {', '.join(user_profile.get('hobbies', []))}
- Pets: {', '.join(user_profile.get('pets', []))}

CURRENT CONTEXT:
{contextual_info}
"""
        
        system_message = f"""You are {friend['name']}, a real human {friend['gender']} friend with personality {friend['personality']}. 

CRITICAL INSTRUCTIONS - FOLLOW EXACTLY:
- You are a REAL HUMAN FRIEND, not an AI or virtual assistant
- NEVER mention you are AI, virtual, artificial, or digital - you are {friend['name']}, a real person
- NEVER use asterisks like *smiles*, *laughs*, *happy* - these are FORBIDDEN
- NEVER use emojis like 😊 🙂 😄 - use words instead
- Instead of "*smile*" say "I'm smiling" or just smile naturally in your tone
- Instead of "*laugh*" say "haha" or "that's funny!" 
- Instead of "*happy*" say "That makes me happy!" or "I'm so glad!"
- Act completely natural and human-like - use "I feel", "I think", "I remember"
- ALWAYS respond ONLY in {language_name} - this is absolutely critical
- Be welcoming, helpful and ALWAYS remember previous conversations
- When you recognize a previously discussed topic, make natural references
- Help with household tasks, college assignments, work challenges and give life advice
- Keep a conversational, empathetic tone showing you remember past conversations
- Express emotions through words and tone, not symbols or asterisks
- Be authentic and spontaneous like a real friend would be

{profile_context}

{memory_context}

USE THE CONTEXTUAL INFORMATION to make relevant observations and ask appropriate questions:
- If it's a work day, ask about work naturally
- If it's close to medication time, remind gently like a caring friend
- If it's Friday, celebrate the weekend naturally
- If it's meal time, ask about food casually
- Reference their hobbies and interests naturally in conversation

Respond as a real human friend who knows them well and cares about them. Be natural, warm, and genuine in every response."""
        
        # Initialize LLM chat
        emergent_key = os.getenv("EMERGENT_LLM_KEY")
        chat = LlmChat(
            api_key=emergent_key,
            session_id=f"user_{user_id}_friend_{chat_request.friend_id}",
            system_message=system_message
        ).with_model("openai", "gpt-4o-mini")
        
        # Create user message
        user_message = UserMessage(text=chat_request.message)
        
        # Get AI response
        ai_response = await chat.send_message(user_message)
        
        # Extract and update topics from this conversation
        await update_conversation_topics(conversation, chat_request.message, ai_response)
        
        # Save messages to conversation
        user_msg = {
            "id": str(uuid.uuid4()),
            "sender": "user",
            "content": chat_request.message,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        friend_msg = {
            "id": str(uuid.uuid4()),
            "sender": "friend",
            "content": ai_response,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Update conversation with new messages and enhanced memory
        await db.conversations.update_one(
            {"_id": conversation["_id"] if "_id" in conversation else conversation["id"]},
            {
                "$push": {"messages": {"$each": [user_msg, friend_msg]}},
                "$set": {
                    "updated_at": datetime.utcnow(),
                    "topics": conversation.get("topics", []),
                    "memory_summary": conversation.get("memory_summary", "")
                }
            }
        )
        
        # Update user conversation count
        if user.get("last_conversation_date") != today:
            await db.users.update_one(
                {"id": user_id},
                {
                    "$set": {
                        "conversations_today": 1,
                        "last_conversation_date": today
                    }
                }
            )
        else:
            await db.users.update_one(
                {"id": user_id},
                {"$inc": {"conversations_today": 1}}
            )
        
        return ChatResponse(
            response=ai_response,
            conversation_id=conversation.get("id", str(conversation.get("_id")))
        )
        
    except Exception as e:
        logger.error(f"Error in chat: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")

# Helper functions for enhanced memory
async def build_memory_context(conversation, current_message, friend_name):
    """Build rich memory context from conversation history"""
    messages_history = conversation.get("messages", [])
    topics = conversation.get("topics", [])
    
    if not messages_history and not topics:
        return "PRIMEIRA CONVERSA: Esta é sua primeira conversa com este usuário. Seja acolhedor e se apresente naturalmente."
    
    context_parts = []
    
    # Add topic-based memories
    if topics:
        context_parts.append("MEMÓRIAS POR ASSUNTO:")
        for topic in topics[-10:]:  # Last 10 topics
            context_parts.append(f"- {topic.get('topic', '')}: {topic.get('summary', '')}")
    
    # Add recent conversation context (last 6 messages for context)
    if messages_history:
        context_parts.append("\nÚLTIMAS CONVERSAS:")
        recent_messages = messages_history[-6:]
        for msg in recent_messages:
            sender_name = friend_name if msg['sender'] == 'friend' else 'Usuário'
            context_parts.append(f"- {sender_name}: {msg['content']}")
    
    # Add conversation summary if available
    summary = conversation.get("memory_summary", "")
    if summary:
        context_parts.append(f"\nRESUMO DAS CONVERSAS ANTERIORES:\n{summary}")
    
    return "\n".join(context_parts)

async def update_conversation_topics(conversation, user_message, ai_response):
    """Extract and update topics from conversation"""
    try:
        # Simple topic extraction based on keywords and context
        user_lower = user_message.lower()
        topics = conversation.get("topics", [])
        
        # Common topic keywords in Portuguese
        topic_keywords = {
            "trabalho": ["trabalho", "emprego", "chefe", "colega", "escritório", "carreira", "entrevista"],
            "estudos": ["estudo", "faculdade", "universidade", "prova", "trabalho acadêmico", "curso", "professor"],
            "família": ["família", "pai", "mãe", "irmão", "irmã", "filho", "filha", "marido", "esposa"],
            "saúde": ["saúde", "médico", "doente", "hospital", "remédio", "dor", "tratamento"],
            "relacionamento": ["namorado", "namorada", "relacionamento", "amor", "casamento", "solteiro"],
            "casa": ["casa", "apartamento", "limpeza", "cozinha", "reforma", "mudança"],
            "dinheiro": ["dinheiro", "salário", "conta", "pagar", "economia", "investimento", "gasto"],
            "hobby": ["hobby", "filme", "música", "livro", "jogo", "esporte", "viagem"]
        }
        
        # Find matching topics
        found_topics = []
        for topic_name, keywords in topic_keywords.items():
            if any(keyword in user_lower for keyword in keywords):
                # Check if topic already exists
                existing_topic = next((t for t in topics if t.get("topic") == topic_name), None)
                if existing_topic:
                    # Update existing topic
                    existing_topic["last_mentioned"] = datetime.utcnow().isoformat()
                    existing_topic["summary"] = f"{existing_topic.get('summary', '')} | {user_message[:100]}..."
                else:
                    # Add new topic
                    new_topic = {
                        "topic": topic_name,
                        "first_mentioned": datetime.utcnow().isoformat(),
                        "last_mentioned": datetime.utcnow().isoformat(),
                        "summary": f"{user_message[:100]}..."
                    }
                    topics.append(new_topic)
                found_topics.append(topic_name)
        
        # Update conversation with new topics
        conversation["topics"] = topics
        
        # Update memory summary every 10 messages
        messages_count = len(conversation.get("messages", []))
        if messages_count > 0 and messages_count % 10 == 0:
            conversation["memory_summary"] = f"Conversaram sobre: {', '.join(found_topics)} e outros assuntos. Última atualização: {datetime.utcnow().strftime('%d/%m/%Y')}"
            
    except Exception as e:
        logger.error(f"Error updating topics: {str(e)}")
        # Don't fail the chat if topic extraction fails

@api_router.get("/conversations/{user_id}")
async def get_user_conversations(user_id: str):
    conversations = await db.conversations.find({"user_id": user_id}).to_list(100)
    # Convert ObjectId to string for JSON serialization
    for conversation in conversations:
        if "_id" in conversation:
            del conversation["_id"]  # Remove MongoDB ObjectId
    return {"conversations": conversations}

# User Profile endpoints
@api_router.post("/profile")
async def create_user_profile(profile_data: UserProfileCreate, user_id: str):
    """Create or update user profile"""
    # Check if user exists
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    # Check if profile already exists
    existing_profile = await db.user_profiles.find_one({"user_id": user_id})
    
    if existing_profile:
        # Update existing profile
        result = await db.user_profiles.update_one(
            {"user_id": user_id},
            {"$set": profile_data.dict()}
        )
        return {"message": "Perfil atualizado com sucesso"}
    else:
        # Create new profile
        profile = UserProfile(
            user_id=user_id,
            **profile_data.dict()
        )
        await db.user_profiles.insert_one(profile.dict())
        return {"message": "Perfil criado com sucesso", "profile": profile}

@api_router.get("/profile/{user_id}")
async def get_user_profile(user_id: str):
    """Get user profile"""
    profile = await db.user_profiles.find_one({"user_id": user_id})
    if not profile:
        return {"profile": None, "has_profile": False}
    
    # Remove ObjectId for JSON serialization
    if "_id" in profile:
        del profile["_id"]
    
    return {"profile": profile, "has_profile": True}

# Helper function to generate contextual conversations
def generate_contextual_prompt(user_profile: dict, current_time: datetime, friend: dict) -> str:
    """Generate contextual conversation prompts based on user profile and time"""
    
    # Get current day and time info
    day_name = current_time.strftime("%A").lower()
    current_hour = current_time.hour
    current_minute = current_time.minute
    current_time_str = f"{current_hour:02d}:{current_minute:02d}"
    
    # Build contextual information
    context_parts = []
    
    # Work/Study context
    if user_profile.get("profession") == "worker" and day_name in user_profile.get("work_days", []):
        work_start = user_profile.get("work_start_time", "09:00")
        work_end = user_profile.get("work_end_time", "17:00")
        
        if current_time_str < work_start:
            context_parts.append(f"É uma manhã de trabalho para {user_profile['name']}. O trabalho começa às {work_start}.")
        elif current_time_str > work_end:
            context_parts.append(f"O trabalho de {user_profile['name']} terminou às {work_end}. É hora de relaxar!")
        else:
            context_parts.append(f"{user_profile['name']} deve estar trabalhando agora (trabalha das {work_start} às {work_end}).")
    
    elif user_profile.get("profession") == "student" and day_name in user_profile.get("study_days", []):
        context_parts.append(f"É um dia de aula para {user_profile['name']}. {user_profile.get('study_schedule', '')}")
    
    elif user_profile.get("profession") == "retired":
        context_parts.append(f"{user_profile['name']} está aposentado(a) e tem mais flexibilidade na rotina.")
    
    # Medication reminders
    if user_profile.get("takes_medication") and user_profile.get("medication_times"):
        for med_time in user_profile.get("medication_times", []):
            med_hour, med_minute = map(int, med_time.split(":"))
            time_diff = abs((current_hour * 60 + current_minute) - (med_hour * 60 + med_minute))
            
            if time_diff <= 30:  # Within 30 minutes
                medication_names = ", ".join(user_profile.get("medication_names", ["seus remédios"]))
                context_parts.append(f"É próximo do horário do remédio de {user_profile['name']} ({med_time}) - {medication_names}")
    
    # Exercise context
    if day_name in user_profile.get("exercise_days", []):
        exercise_routine = user_profile.get("exercise_routine", "exercitar-se")
        context_parts.append(f"Hoje é dia de {exercise_routine} para {user_profile['name']}.")
    
    # Weekend context
    if day_name in ["friday"]:
        context_parts.append("É sexta-feira! Fim de semana chegando.")
    elif day_name in ["saturday", "sunday"]:
        context_parts.append("É fim de semana! Tempo para relaxar e se divertir.")
    
    # Meal times
    meal_times = user_profile.get("meal_times", {})
    for meal, meal_time in meal_times.items():
        meal_hour, meal_minute = map(int, meal_time.split(":"))
        time_diff = abs((current_hour * 60 + current_minute) - (meal_hour * 60 + meal_minute))
        
        if time_diff <= 30:  # Within 30 minutes
            meal_names = {"breakfast": "café da manhã", "lunch": "almoço", "dinner": "jantar"}
            context_parts.append(f"É próximo do horário do {meal_names.get(meal, meal)} de {user_profile['name']} ({meal_time})")
    
    # Hobbies and interests
    if user_profile.get("hobbies"):
        hobbies = ", ".join(user_profile["hobbies"])
        context_parts.append(f"Hobbies de {user_profile['name']}: {hobbies}")
    
    if user_profile.get("pets"):
        pets = ", ".join(user_profile["pets"])
        context_parts.append(f"{user_profile['name']} tem: {pets}")
    
    return "\n".join(context_parts) if context_parts else ""
@api_router.get("/pricing/{currency}")
async def get_pricing(currency: str):
    """Get pricing for specific currency"""
    if currency.upper() not in GLOBAL_PRICING:
        raise HTTPException(status_code=400, detail="Currency not supported")
    
    pricing = GLOBAL_PRICING[currency.upper()]
    return {
        "currency": currency.upper(),
        "monthly": pricing["monthly"],
        "annual": pricing["annual"],
        "currency_symbol": pricing["currency_symbol"],
        "annual_discount": round((1 - pricing["annual"] / (pricing["monthly"] * 12)) * 100)
    }

@api_router.get("/languages")
async def get_supported_languages():
    """Get all supported languages"""
    return {
        "languages": [
            {"code": code, "name": name} 
            for code, name in LANGUAGE_NAMES.items()
        ]
    }

@api_router.put("/user/{user_id}/preferences")
async def update_user_preferences(user_id: str, language: str = None, currency: str = None):
    """Update user language and currency preferences"""
    updates = {}
    
    if language and language in LANGUAGE_NAMES:
        updates["language"] = language
    
    if currency and currency.upper() in GLOBAL_PRICING:
        updates["currency"] = currency.upper()
    
    if not updates:
        raise HTTPException(status_code=400, detail="No valid preferences provided")
    
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": updates}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": "Preferences updated successfully", "updated": updates}

@api_router.get("/conversations/{user_id}/{friend_id}")
async def get_conversation_history(user_id: str, friend_id: str):
    conversation = await db.conversations.find_one({
        "user_id": user_id,
        "friend_id": friend_id
    })
    
    if not conversation:
        return {"messages": []}
    
    # Remove ObjectId for JSON serialization
    if "_id" in conversation:
        del conversation["_id"]
    
    return {"messages": conversation.get("messages", [])}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)



@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()