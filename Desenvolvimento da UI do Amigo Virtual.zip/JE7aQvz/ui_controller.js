import { navigateTo } from './router.js';
import { api } from './api_service.js';
import { state, updateState } from './state.js';

function initializeUI() {
    initLoginScreen();
    initRegisterScreen();
    initQuestionnaireScreen();
    initFriendSelectionScreen();
    initChatScreen();
    initPaymentScreen();
}

function initLoginScreen() {
    document.getElementById('go-to-register').addEventListener('click', (e) => {
        e.preventDefault();
        navigateTo('register-screen');
    });

    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        try {
            const userData = await api.login(email, password);
            updateState({ currentUser: userData.user, authToken: userData.token });
            localStorage.setItem('amigo_virtual_session', JSON.stringify({ token: userData.token, user: userData.user }));

            navigateTo('chat-screen');
        } catch (error) {
            alert(`Login failed: ${error.message}`);
        }
    });
}

function initRegisterScreen() {
    document.getElementById('go-to-login').addEventListener('click', (e) => {
        e.preventDefault();
        navigateTo('login-screen');
    });

    document.getElementById('register-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const currency = document.getElementById('register-currency').value;
        const language = document.getElementById('register-language').value;

        try {
            const userData = await api.register(email, password, currency, language);
            updateState({ currentUser: userData.user, authToken: userData.token });
            localStorage.setItem('amigo_virtual_session', JSON.stringify({ token: userData.token, user: userData.user }));
            

            renderQuestionnaireStep(0);
            navigateTo('questionnaire-screen');
        } catch (error) {
            alert(`Registration failed: ${error.message}`);
        }
    });
}

const questionnaireSteps = [
    {
        title: "Conte-nos sobre você",
        fields: [
            { id: "hobbies", label: "Quais são seus hobbies?", type: "text", placeholder: "Ex: Ler, caminhar, jogar videogame" },
            { id: "maritalStatus", label: "Estado civil", type: "select", options: ["Solteiro(a)", "Em um relacionamento", "Casado(a)", "Divorciado(a)"] }
        ]
    },
    {
        title: "Família e Pets",
        fields: [
            { id: "pets", label: "Você tem animais de estimação? (Tipo e nome)", type: "text", placeholder: "Ex: Cachorro, Rex" },
            { id: "children", label: "Você tem filhos? (Nomes)", type: "text", placeholder: "Ex: Lucas, Ana" }
        ]
    },
    {
        title: "Sua Rotina",
        fields: [
            { id: "studies", label: "O que você estuda?", type: "text", placeholder: "Curso e ano" },
            { id: "medication", label: "Toma alguma medicação diária?", type: "text", placeholder: "Nome e horário" }
        ]
    }
];
let currentQuestionnaireStep = 0;
let questionnaireData = {};

function renderQuestionnaireStep(stepIndex) {
    const step = questionnaireSteps[stepIndex];
    const contentDiv = document.getElementById('questionnaire-content');
    
    let fieldsHtml = step.fields.map(field => {
        if (field.type === 'select') {
            return `
                <div class="mb-4">
                    <label for="${field.id}" class="block text-gray-600 mb-2">${field.label}</label>
                    <select id="${field.id}" class="form-input">
                        ${field.options.map(opt => `<option value="${opt}">${opt}</option>`).join('')}
                    </select>
                </div>
            `;
        }
        return `
            <div class="mb-4">
                <label for="${field.id}" class="block text-gray-600 mb-2">${field.label}</label>
                <input type="${field.type}" id="${field.id}" class="form-input" placeholder="${field.placeholder || ''}">
            </div>
        `;
    }).join('');

    contentDiv.innerHTML = `
        <h2 class="text-2xl font-bold text-gray-800 mb-2">${step.title}</h2>
        <p class="text-gray-500 mb-6">Isso nos ajuda a personalizar sua experiência.</p>
        ${fieldsHtml}
    `;

    document.getElementById('questionnaire-next').classList.toggle('hidden', stepIndex === questionnaireSteps.length - 1);
    document.getElementById('questionnaire-finish').classList.toggle('hidden', stepIndex < questionnaireSteps.length - 1);
}

function initQuestionnaireScreen() {
    document.getElementById('questionnaire-next').addEventListener('click', () => {
        const step = questionnaireSteps[currentQuestionnaireStep];
        step.fields.forEach(field => {
            questionnaireData[field.id] = document.getElementById(field.id).value;
        });

        currentQuestionnaireStep++;
        if (currentQuestionnaireStep < questionnaireSteps.length) {
            renderQuestionnaireStep(currentQuestionnaireStep);
        }
    });

    document.getElementById('questionnaire-finish').addEventListener('click', async () => {
        const step = questionnaireSteps[currentQuestionnaireStep];
        step.fields.forEach(field => {
            questionnaireData[field.id] = document.getElementById(field.id).value;
        });
        
        console.log('Final questionnaire data:', questionnaireData);
        try {

            console.log("Profile data saved (mocked).");
            navigateTo('friend-selection-screen');
        } catch (error) {
            alert('Could not save profile.');
        }
    });
}

const personalityTraits = ['Alegre', 'Divertido', 'Sério', 'Profissional', 'Leal', 'Carinhoso', 'Atencioso', 'Extrovertido'];
let selectedGender = null;
let selectedPersonalities = [];

function initFriendSelectionScreen() {
    const avatarSelections = document.querySelectorAll('.avatar-selection');
    const confirmButton = document.getElementById('confirm-friend-selection');
    
    avatarSelections.forEach(avatar => {
        avatar.addEventListener('click', () => {
            avatarSelections.forEach(a => a.classList.remove('selected'));
            avatar.classList.add('selected');
            selectedGender = avatar.dataset.gender;
            const avatarUrl = avatar.getAttribute('src');
            updateState({ friendProfile: { ...state.friendProfile, gender: selectedGender, avatar: avatarUrl }});
            checkFriendSelectionCompletion();
        });
    });

    const tagsContainer = document.getElementById('personality-tags');
    tagsContainer.innerHTML = personalityTraits.map(trait => `
        <div class="personality-tag" data-trait="${trait}">${trait}</div>
    `).join('');

    document.querySelectorAll('.personality-tag').forEach(tag => {
        tag.addEventListener('click', () => {
            tag.classList.toggle('selected');
            const trait = tag.dataset.trait;
            if (selectedPersonalities.includes(trait)) {
                selectedPersonalities = selectedPersonalities.filter(t => t !== trait);
            } else {
                selectedPersonalities.push(trait);
            }
             updateState({ friendProfile: { ...state.friendProfile, personalities: selectedPersonalities }});
            checkFriendSelectionCompletion();
        });
    });

    confirmButton.addEventListener('click', async () => {

        console.log("Friend profile saved (mocked):", state.friendProfile);
        document.getElementById('chat-avatar').src = state.friendProfile.avatar;
        

        const welcomeMessage = {
            sender: 'ai',
            text: 'Olá! Que bom te conhecer. Estou aqui para o que precisar. Sobre o que você gostaria de conversar?',
            timestamp: new Date()
        };
        addMessageToChat(welcomeMessage);
        updateState({ chatHistory: [welcomeMessage] });

        navigateTo('chat-screen');
    });
}

function checkFriendSelectionCompletion() {
    const confirmButton = document.getElementById('confirm-friend-selection');
    if (selectedGender && selectedPersonalities.length > 0) {
        confirmButton.disabled = false;
    } else {
        confirmButton.disabled = true;
    }
}

function initChatScreen() {
    document.getElementById('chat-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = document.getElementById('chat-input');
        const messageText = input.value.trim();
        if (!messageText) return;

        const userMessage = { sender: 'user', text: messageText, timestamp: new Date() };
        addMessageToChat(userMessage);
        
        let newHistory = [...state.chatHistory, userMessage];
        updateState({ chatHistory: newHistory });

        input.value = '';
        input.disabled = true;

        try {
            const aiResponseText = await api.sendMessageToAI(messageText, state.chatHistory, state.friendProfile);
            const aiMessage = { sender: 'ai', text: aiResponseText, timestamp: new Date() };
            addMessageToChat(aiMessage);
            updateState({ chatHistory: [...state.chatHistory, aiMessage] });
        } catch (error) {
            console.error('Error getting AI response:', error);
            const errorMessage = { sender: 'ai', text: 'Desculpe, estou com um pouco de dificuldade para me conectar agora. Podemos tentar de novo em um instante?', timestamp: new Date() };
            addMessageToChat(errorMessage);
        } finally {
            input.disabled = false;
            input.focus();
        }
    });
}

function addMessageToChat(message) {
    const messagesContainer = document.getElementById('chat-messages');
    const bubble = document.createElement('div');
    bubble.classList.add('chat-bubble', `chat-bubble-${message.sender}`);
    bubble.textContent = message.text;
    messagesContainer.appendChild(bubble);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function initPaymentScreen(){
    document.getElementById('go-to-payment').addEventListener('click', () => navigateTo('payment-screen'));
    document.getElementById('back-to-chat').addEventListener('click', () => navigateTo('chat-screen'));
}

export { initializeUI, addMessageToChat };
